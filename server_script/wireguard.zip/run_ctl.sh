#!/bin/bash
wp="/usr/local/wireguard"
. $wp/functions.sh

bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")
bash <(iptables -t nat -S | grep "${wp}" | sed "s|^..|iptables -t nat -D|g")
pgrep -f $wp/nginx | xargs kill
ip link delete dev wg

if [ "$1" = "start" ];then
	iptables -t nat -A POSTROUTING -s 10.2.0.0/24 ! -d 10.2.0.0/24 -m comment --comment "$wp" -j MASQUERADE
    iptables -I INPUT -p tcp --dport $(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*") -m comment --comment "${wp}" -j ACCEPT
	ports=$(cat $wp/port.ini)
	for dport in $ports;do
        iptables -I INPUT -p udp --dport $dport -m comment --comment "$wp" -j ACCEPT
    done
	
	var=0
	for port in $ports;do
        if [ "$var" = "0" ];then
			var=1
			original_port="$port"
			continue
		fi
		iptables -t nat -I PREROUTING -p udp --dport $port -m comment --comment "$wp" -j REDIRECT --to $original_port
    done
	
	WG_ENDPOINT_RESOLUTION_RETRIES=infinity
	WG_I_PREFER_BUGGY_USERSPACE_TO_POLISHED_KMOD=1
	$wp/wireguard wg
	LD_LIBRARY_PATH="$wp" $wp/wg setconf wg $wp/wg.conf
	ip -4 address add 10.2.0.1 dev wg
	ip link set mtu 1420 up dev wg
	for client_IP in $(awk '{print $2}' $wp/client.ini);do
		ip -4 route add $client_IP/32 dev wg
	done

    $wp/nginx -p /tmp -c $wp/nginx.conf
fi
