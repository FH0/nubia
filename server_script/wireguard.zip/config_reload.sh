#!/bin/bash
wp="/usr/local/wireguard"
. $wp/functions.sh

ports=$(cat $wp/port.ini)
clients=$(awk '{print $1}' $wp/client.ini)
client_passwords=$(awk '{print $3}' $wp/client.ini)
public_ip=$(ip_info get_ip)

server_publickey=$(cat $wp/server_publickey)
server_privatekey=$(cat $wp/server_privatekey)

echo -e "[Interface]\nPrivateKey = $server_privatekey\nListenPort = $(echo $ports | awk '{print $1}')" > $wp/wg.conf
for T in $client_passwords;do
	T_publickey=$(echo $T | LD_LIBRARY_PATH="$wp" $wp/wg pubkey)
	T_IP=$(grep "$T" $wp/client.ini | awk '{print $2}')
	echo -e "\n[Peer]\nPublicKey = $T_publickey\nAllowedIPs = $T_IP" >> $wp/wg.conf
done

rm -f $wp/client/*
for D in $ports;do
	for Y in $clients;do
		client_IP=$(grep "^$Y " $wp/client.ini | awk '{print $2}')
		client_privatekey=$(grep "^$Y " $wp/client.ini | awk '{print $3}')
		echo -e "[Interface]\nDNS = 8.8.8.8\nAddress = $client_IP\nPrivateKey = $client_privatekey\n\n[Peer]\nPublicKey = $server_publickey\nAllowedIPs = 0.0.0.0/0\nEndpoint = $public_ip:$D\nPersistentKeepalive = 25" > $wp/client/${Y}_${D}.conf
	done
done
