#!/bin/bash
wp="/usr/local/wireguard"
. $wp/functions.sh

install_wireguard(){
    chmod -R 777 $wp
	
    colorEcho $BLUE "正在安装wireguard控制面板..."
    ip_info init
	cp $wp/manage_panel.sh /bin/wd
    
    colorEcho $BLUE "正在初始化wireguard..."
    LD_LIBRARY_PATH="$wp" $wp/wg genkey | tee $wp/server_privatekey | LD_LIBRARY_PATH="$wp" $wp/wg pubkey > $wp/server_publickey
    
    colorEcho $BLUE "正在调整内核参数..."
    sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
	echo "net.ipv4.ip_forward = 1" >> /etc/sysctl.conf
	echo 1 > /proc/sys/net/ipv4/ip_forward
    
    colorEcho $BLUE "正在设置随机网址..."
    random=$(random_password 6)
    sed -i "s|listen.*|listen       $(random_port);|" $wp/nginx.conf
    nginx_path=($(grep -n "location" $wp/nginx.conf))
    sed -i "${nginx_path[0]%:}s|location.*|location /$random {|" $wp/nginx.conf

	grep -q "^nobody" /etc/group || groupadd nobody
}

main(){
    install_wireguard
    colorEcho $GREEN "wireguard安装完成！输入wd可进入控制面板！"
}

main
