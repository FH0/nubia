#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/wireguard"
. $wp/functions.sh

add_port() {
    colorRead ${YELLOW} '请输入端口[默认随机]' Port
    [ -z "$Port" ] && Port=$(random_port)
    echo "$Port" >> $wp/port.ini
	if [ ! -z "$clients" ];then
		$wp/config_reload.sh
		start_service
	fi
}

del_port() {
    var=1
    for D in $ports;do
        echo -e " $var. 删除${YELLOW}$D${BLANK}端口"
        ((var++))
    done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    if [ ! -z "$input_choice" ];then
		sed -i "${input_choice}d" $wp/port.ini
        if [ ! -z "$ports" ] && [ ! -z "$clients" ];then
            $wp/config_reload.sh
			start_service
        else
            stop_service
        fi
    fi
}

add_user(){
    colorRead ${YELLOW} '请输入用户名[默认随机]' client_name
	[ -z "$client_name" ] && client_name=$(random_password 4)
	for S in {2..255};do
		if ! grep -q "10.2.0.$S" $wp/client.ini;then
			IP=$(echo "10.2.0.$S")
			break
		fi
	done
	echo -n "$client_name $IP " >> $wp/client.ini
	LD_LIBRARY_PATH=$wp $wp/wg genkey >> $wp/client.ini 2>/dev/null
	if [ ! -z "$ports" ];then
		$wp/config_reload.sh
		start_service
	fi
}

del_user(){
    var=1
    for D in $clients;do
        IP=$(grep "^$D " $wp/client.ini | awk '{print $2}')
		echo -e " $var. 删除${YELLOW}$D $IP${BLANK}"
        ((var++))
	done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    if [ ! -z "$input_choice" ];then
        sed -i "${input_choice}d" $wp/client.ini
		if [ ! -z "$ports" ] && [ ! -z "$clients" ];then
			$wp/config_reload.sh
			start_service
		else
			stop_service
		fi
    fi
}

panel(){
	public_ip=$(ip_info get_ip)
	color_status $wp/wireguard
    ports=$(cat $wp/port.ini)
	clients=$(awk '{print $1}' $wp/client.ini | tr '\n' ' ')
    connections=""
    for Port in $ports;do
		connection=$(echo -e "[${YELLOW}$Port ${GREEN}$(get_connections $Port)${BLANK}]")
        connections+="$connection "
    done
    var=1

	Port=$(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*")
	Path=($(grep -n "location" $wp/nginx.conf))
	random_path=${Path[2]}
	echo
	echo -e "${BLUE}客户端配置文件下载地址: ${YELLOW}http://$public_ip:$Port$random_path${BLANK}"
    echo
    echo -e "${YELLOW}用户 ${GREEN}$clients${BLANK}"
	echo
	echo -e "[${YELLOW}端口 ${GREEN}连接数${BLANK}] $connections"
    echo
    echo -e "  $var. 开/关${wireguard_status}wireguard${BLANK}" && ((var++))
    echo "  $var. 卸载wireguard" && ((var++))
    echo "  $var. 添加一个用户" && ((var++))
    echo "  $var. 删除一个用户" && ((var++))
    echo "  $var. 添加一个端口" && ((var++))
    echo "  $var. 删除一个端口" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "$wireguard_status" = "$GREEN" ];then
                stop_service
            elif [ ! -z "$ports" ] && [ ! -z "$clients" ];then
                start_service
            fi
            clear && panel
            ;;
        $((var++)) )
            if warning_read;then
				bash $wp/uninstall.sh
				clear && echo "wireguard已卸载！"
			else
				clear && panel
			fi
            ;;
        $((var++)) )
            add_user
            clear && panel
            ;;
        $((var++)) )
            [ ! -z "$clients" ] && del_user
            clear && panel
            ;;
        $((var++)) )
            add_port
            clear && panel
            ;;
        $((var++)) )
			[ ! -z "$ports" ] && del_port
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
