#!/bin/bash
wp="/usr/local/l-stn"
. $wp/functions.sh

install-stn() {
    chmod -R 777 $wp

    colorEcho $BLUE "正在安装 stn 控制面板..."
    cp $wp/manage_panel.sh /bin/l-stn

    colorEcho $BLUE "正在设置日志文件路径..."
    sed -i "s|log_file\".*|log_file\": \"$wp/running.log\",|" $wp/config.json

    colorEcho $BLUE "正在设置域名分流文件路径..."
    sed -i "s|dns_domain\".*|dns_domain\": [\"file $wp/accelerated-domains.china.conf\"],|" $wp/config.json
}

main() {
    cmd_need "hexdump"
    install-stn
    colorEcho $GREEN "l-stn 安装完成！输入 l-stn 可进入控制面板！"
}

main
