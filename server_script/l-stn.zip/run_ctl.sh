#!/bin/bash
wp="/usr/local/l-stn"
. $wp/functions.sh

shopt -s expand_aliases >/dev/null 2>&1
alias iptables="iptables -w" # 重新定义 iptables，解决调用锁

stop() {
    kill_path $wp/stn

    ip rule | sed -n '/lookup 2000/{s|.*from|ip rule del from|g;p}' | sh
    ip route flush table 2000
    ip rule | sed -n '/lookup 4000/{s|.*from|ip rule del from|g;p}' | sh
    ip route flush table 4000

    iptables -t mangle -F SO
    iptables -t mangle -D OUTPUT -j SO
    iptables -t mangle -X SO
    iptables -t mangle -F SP
    iptables -t mangle -D PREROUTING -j SP
    iptables -t mangle -X SP
}

start() {
    # 添加路由
    ip -batch $wp/blacklist.txt
    ip rule add from all fwmark 0x200000 lookup 2000
    ip route replace local default dev lo table 4000 # DNS
    ip rule add from all fwmark 0x400000 lookup 4000 # DNS

    # 初始化 iptables 规则
    iptables -t mangle -N SO
    iptables -t mangle -I OUTPUT -j SO
    iptables -t mangle -N SP
    iptables -t mangle -I PREROUTING -j SP

    # 放行核心
    iptables -t mangle -A SO -m owner --gid-owner 2000 -j MARK --set-xmark 0 # 清除标记，保证数据不被路由
    iptables -t mangle -A SO -m owner --gid-owner 2000 -j ACCEPT

    # 设置 DNS
    iptables -t mangle -A SO -p udp --dport 53 -j MARK --set-xmark 0x400000
    iptables -t mangle -A SO -p udp --dport 53 -j ACCEPT

    # 放行不应该代理的流量
    iptables -t mangle -A SO -d 0.0.0.0/8,224.0.0.0/3,100.64.0.0/10,127.0.0.0/8,169.254.0.0/16,192.0.0.0/24,192.0.2.0/24,198.18.0.0/15,198.51.100.0/24,203.0.113.0/24,172.16.0.0/12,192.168.0.0/16,10.0.0.0/8 -j ACCEPT

    # 标记
    iptables -t mangle -A SO -p tcp -j MARK --set-xmark 0x200000
    iptables -t mangle -A SO -p udp -j MARK --set-xmark 0x200000

    # TPROXY 重定向
    iptables -t mangle -A SP -p udp -m mark --mark 0x400000 -j TPROXY --on-port 2000 --tproxy-mark 0x400000 # DNS
    iptables -t mangle -A SP -p tcp -m mark --mark 0x200000 -j TPROXY --on-port 2000 --tproxy-mark 0x200000
    iptables -t mangle -A SP -p udp -m mark --mark 0x200000 -j TPROXY --on-port 2000 --tproxy-mark 0x200000

    # 启动核心
    nohup $wp/stn -c $wp/config.json >$wp/running.log 2>&1 &
}

stop
[ "$1" = "start" ] && start
