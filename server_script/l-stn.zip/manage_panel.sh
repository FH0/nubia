#!/bin/bash
wp="/usr/local/l-stn"
. $wp/functions.sh

panel() {
    color_status stn_status $wp/stn
    version=$($wp/stn | sed -n '1p' | awk '{print $2}' | awk -F':' '{print $2}')
    var=1

    cat $wp/config.json
    echo
    echo -e "  $var. 开/关 ${stn_status}l-stn $version${BLANK}" && ((var++))
    echo "  $var. 卸载 l-stn" && ((var++))
    echo "  $var. 编辑配置文件" && ((var++))
    echo "  $var. 查看日志（按 q 退出）" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "$stn_status" = "$GREEN" ]; then
            stop_service
        else
            start_service
        fi
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            bash $wp/uninstall.sh
            clear && echo "l-stn 已卸载！"
        else
            clear && panel
        fi
        ;;
    $((var++)))
        vi $wp/config.json
        start_service
        clear && panel
        ;;
    $((var++)))
        less +G $wp/running.log
        clear && panel
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
