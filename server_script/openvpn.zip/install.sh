#!/bin/bash
wp="/usr/local/openvpn"
. $wp/functions.sh

init_key(){
	cd $wp/server
	chmod +x $wp/openvpn
	$wp/openvpn --genkey --secret ta.key
	cd $wp/EasyRSA
	chmod +x $wp/EasyRSA/easyrsa
	$wp/EasyRSA/easyrsa init-pki
	$wp/EasyRSA/easyrsa --batch build-ca nopass
	$wp/EasyRSA/easyrsa gen-dh
	$wp/EasyRSA/easyrsa build-server-full server nopass
	cp $wp/EasyRSA/pki/ca.crt \
		$wp/EasyRSA/pki/private/ca.key \
		$wp/EasyRSA/pki/dh.pem \
		$wp/EasyRSA/pki/issued/server.crt \
		$wp/EasyRSA/pki/private/server.key \
		$wp/server
} >/dev/null 2>&1

install_openvpn(){
    chmod -R 777 $wp
	
    colorEcho $BLUE "正在初始化openvpn证书..."
	init_key
	
    colorEcho $BLUE "正在安装openvpn控制面板..."
    ip_info init
	cp $wp/manage_panel.sh /bin/op
    
    colorEcho $BLUE "正在调整内核参数..."
    sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
	echo "net.ipv4.ip_forward = 1" >> /etc/sysctl.conf
	echo 1 > /proc/sys/net/ipv4/ip_forward
    
    colorEcho $BLUE "正在设置随机网址..."
    random=$(random_password 6)
    sed -i "s|listen.*|listen       $(random_port);|" $wp/nginx.conf
    nginx_path=($(grep -n "location" $wp/nginx.conf))
    sed -i "${nginx_path[0]%:}s|location.*|location /$random {|" $wp/nginx.conf

	grep -q "^nobody" /etc/group || groupadd nobody
    mkdir -p /tmp/logs # for nginx pid file
}

main(){
    install_openvpn
    colorEcho $GREEN "openvpn安装完成！输入op可进入控制面板！"
}

main
