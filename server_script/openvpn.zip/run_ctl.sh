#!/bin/bash
wp="/usr/local/openvpn"
. $wp/functions.sh

bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")
bash <(iptables -t nat -S | grep "${wp}" | sed "s|^..|iptables -t nat -D|g")
pgrep -f $wp/nginx | xargs kill
pgrep -f $wp/openvpn | xargs kill

if [ "$1" = "start" ];then
	iptables -t nat -A POSTROUTING -s 10.8.0.0/24 ! -d 10.8.0.0/24 -m comment --comment "$wp" -j MASQUERADE
    iptables -I INPUT -p tcp --dport $(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*") -m comment --comment "${wp}" -j ACCEPT
	for dport in $(awk '{print $2}' $wp/openvpn.ini);do
        iptables -I INPUT -p tcp --dport $dport -m comment --comment "$wp/openvpn" -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m comment --comment "$wp/openvpn" -j ACCEPT
    done
	Num=$(cat $wp/openvpn.ini | wc -l)
	for J in $(seq 1 $Num);do
		protocol=$(sed -n "${J}p" $wp/openvpn.ini | awk '{print $1}')
		port=$(sed -n "${J}p" $wp/openvpn.ini | awk '{print $2}')
		nohup $wp/openvpn --cd $wp/server --config $wp/server/${protocol}_${port}.conf >/dev/null 2>&1 &
	done
    $wp/nginx -p /tmp -c $wp/nginx.conf
fi
