#!/bin/bash
wp="/usr/local/openvpn"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/op
