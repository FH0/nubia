#!/bin/bash
wp="/usr/local/v2rayT"
. $wp/functions.sh

stop() {
    killall -q -KILL v2raY
    ip rule | sed -n '/0x1111/{s|.*from|ip rule del from |g;p}' | sh
    iptables -t nat -F VNO ; iptables -t nat -D OUTPUT -j VNO ; iptables -t nat -X VNO
    iptables -t nat -F VNP ; iptables -t nat -D PREROUTING -j VNP ; iptables -t nat -X VNP
    iptables -t mangle -F VMO ; iptables -t mangle -D OUTPUT -j VMO ; iptables -t mangle -X VMO
    iptables -t mangle -F VMP ; iptables -t mangle -D PREROUTING -j VMP ; iptables -t mangle -X VMP
} >/dev/null 2>&1

start() {
    $wp/chgid 1111 $wp/v2raY
	
	ip route replace local default dev lo table 1111
	ip rule add from all fwmark 0x1111 lookup 1111
    
    iptables -t nat -N VNO
    iptables -t nat -N VNP
    iptables -t nat -I OUTPUT -j VNO
    iptables -t nat -I PREROUTING -j VNP
    iptables -t mangle -N VMO
    iptables -t mangle -N VMP
    iptables -t mangle -I OUTPUT -j VMO
    iptables -t mangle -I PREROUTING -j VMP

	iptables --help | grep -q "xtable" && xtables="-w"
	add_iptables(){ iptables $xtables $@; }
	allow_ip="0.0.0.0/8,100.64.0.0/10,127.0.0.0/8,169.254.0.0/16,192.0.0.0/24,192.0.2.0/24,192.88.99.0/24,198.18.0.0/15,198.51.100.0/24,203.0.113.0/24,172.16.0.0/12,192.168.0.0/16,10.0.0.0/8,224.0.0.0/3"
	
	add_iptables -t nat -I VNO -p tcp -j REDIRECT --to 1111
	add_iptables -t mangle -I VMO -p udp -j MARK --set-xmark 0x1111
	
	add_iptables -t nat -I VNO -d $allow_ip -j ACCEPT
	add_iptables -t nat -I VNO -o lo -j ACCEPT
    add_iptables -t nat -I VNO -m owner --gid-owner 1111 -j ACCEPT

	add_iptables -t mangle -I VMO -d $allow_ip -j ACCEPT
	add_iptables -t mangle -I VMO -o lo -j ACCEPT
	add_iptables -t mangle -I VMO -p 17 --dport 53 -j MARK --set-xmark 0x1111
    add_iptables -t mangle -I VMO -m owner --gid-owner 1111 -j ACCEPT

    add_iptables -t mangle -I VMP -i lo -p 17 -j TPROXY --on-port 1111 --tproxy-mark 0x1111
    add_iptables -t mangle -I VMP -d $allow_ip -j ACCEPT
    add_iptables -t mangle -I VMP -i lo -p 17 --dport 53 -j TPROXY --on-port 1111 --tproxy-mark 0x1111
}

stop
[ "$1" = "start" ] && start
