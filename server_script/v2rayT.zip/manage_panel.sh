#!/bin/bash
wp="/usr/local/v2rayT"
. $wp/functions.sh

panel(){
	color_status vt_status $wp/v2raY
    var=1
	
    echo
    echo -e "  $((var++)). 开/关${vt_status} v2rayT${BLANK}"
    echo "  $((var++)). 卸载 v2rayT"
    echo "  $((var++)). 编辑 v2ray 配置文件"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "$vt_status" = "$GREEN" ];then
                stop_service
            else
                start_service
            fi
            clear && panel
            ;;
        $((var++)) )
			if warning_read;then
				bash $wp/uninstall.sh
				clear && echo " v2rayT 已卸载！"
			else
				clear && panel
			fi
            ;;
        $((var++)) )
            vi +79 $wp/config.json
			start_service
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
