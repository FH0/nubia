#!/bin/bash
wp="/usr/local/v2rayT"
. $wp/functions.sh

install_v2ray(){
    chmod -R 777 $wp
    
    colorEcho $BLUE "正在安装 v2rayT 控制面板..."
    cp $wp/manage_panel.sh /bin/vt
	
	grep -q 'v2raY' /etc/passwd || useradd v2raY
}

main(){
    install_v2ray
    colorEcho $GREEN "v2rayT 安装完成！输入 vt 可进入控制面板！"
}

main
