#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"
. $wp/functions.sh

add_port() {
    colorRead ${YELLOW} '请输入端口[默认随机]' Port
    [ -z "$Port" ] && Port=$(random_port)
    colorRead ${YELLOW} '请设置UUID[默认随机]' UUID
    [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
    echo " 1. tcp"
    echo " 2. ws"
    echo " 3. kcp"
    echo
    colorRead ${YELLOW} '请选择传输类型[默认ws]' network
    [ -z "$network" ] && network=2
    [ "$network" = "1" ] && network=tcp
    [ "$network" = "2" ] && network=ws
    [ "$network" = "3" ] && network=kcp
    echo "$Port $network $UUID" >> $wp/v2ray.ini
    $wp/config_reload.sh
    start_service
}

del_port() {
    grep -q "[0-9]" $wp/v2ray.ini || return
	var=1
    for Echo in $v2ray_ports;do
        echo -e " $((var++)). 删除${YELLOW}$Echo${BLANK}端口"
    done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    if [ ! -z "$input_choice" ];then
        sed -i "${input_choice}d" $wp/v2ray.ini
        $wp/config_reload.sh
        if grep -q "[0-9]" $wp/v2ray.ini;then
			start_service
        else
			stop_service
        fi
    fi
}

change_uuid() {
    var=1
    for Echo in $v2ray_ports;do
        echo -e " $((var++)). 更改${YELLOW}$Echo${BLANK}端口设置"
    done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    [ -z "$input_choice" ] && return
    echo " 1. 更改UUID"
    echo " 2. 更改传输方式"
    echo
    colorRead ${YELLOW} '请选择' port_choice
    [ -z "$port_choice" ] && return
    if [ "$port_choice" = "1" ];then
        colorRead ${YELLOW} '请设置UUID[默认随机]' UUID
        [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
        network=$(sed -n "${input_choice}p" $wp/v2ray.ini | awk '{print $2}')
    elif [ "$port_choice" = "2" ];then
        echo "  1. tcp"
        echo "  2. ws"
        echo "  3. kcp"
        echo
        colorRead ${YELLOW} '请选择传输类型[默认ws]' network
        [ -z "$network" ] && network=2
        [ "$network" = "1" ] && network=tcp
        [ "$network" = "2" ] && network=ws
        [ "$network" = "3" ] && network=kcp
        UUID=$(sed -n "${input_choice}p" $wp/v2ray.ini | awk '{print $3}')
    fi
    port=$(sed -n "${input_choice}p" $wp/v2ray.ini | awk '{print $1}')
    sed -i "${input_choice}d" $wp/v2ray.ini
    echo "$port $network $UUID" >> $wp/v2ray.ini
    $wp/config_reload.sh
    start_service
}

show_config() {
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${BLANK}"
    for K in ${v2ray_ports};do
        v2ray_uuid=$(grep "^$K " $wp/v2ray.ini | awk '{print $3}')
        network=$(grep "^$K " $wp/v2ray.ini | awk '{print $2}')
		country=$(ip_info get_country)
        v2rayNG=$(echo -n '{"add":"'$public_ip'","aid":"100","host":"k.youku.com","id":"'$v2ray_uuid'","net":"'$network'","path":"","port":"'$K'","ps":"'$country'","tls":"","type":"none","v":"2"}' | base64 | tr -d "\n|=" | sed 's|^|vmess://|')
        [ "$network" = "tcp" ] && v2rayNG=$(echo -n '{"add":"'$public_ip'","aid":"100","host":"k.youku.com","id":"'$v2ray_uuid'","net":"tcp","path":"","port":"'$K'","ps":"'$country'","tls":"","type":"http","v":"2"}' | base64 | tr -d "\n|=" | sed 's|^|vmess://|')
        printf "${BLUE}%11s ${YELLOW}%-20s${BLANK}\n" "服务IP:" "${public_ip}"
        printf "${BLUE}%13s ${YELLOW}%-20s${BLANK}\n" "服务端口:" "${K}"
        printf "${BLUE}%11s ${YELLOW}%-20s${BLANK}\n" "用户ID:" "${v2ray_uuid}"
        printf "${BLUE}%11s ${YELLOW}%-20s${BLANK}\n" "额外ID:" "100"
        printf "${BLUE}%13s ${YELLOW}%-20s${BLANK}\n" "加密方式:" "任意选择"
        printf "${BLUE}%13s ${YELLOW}%-20s${BLANK}\n" "传输协议:" "$network"
        [ "$network" = "tcp" ] && printf "${BLUE}%13s ${YELLOW}%-20s${BLANK}\n" "伪装类型:" "http"
        echo
        printf "${BLUE}%9s ${YELLOW}%-20s${BLANK}\n" "v2rayNG:" "${v2rayNG}"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    done
}

show_shadowrocket(){
    for K in ${v2ray_ports};do
        v2ray_uuid=$(grep "^$K " $wp/v2ray.ini | awk '{print $3}')
        network=$(grep "^$K " $wp/v2ray.ini | awk '{print $2}')
        Shadowrocket=$(echo -n 'aes-128-cfb:'$v2ray_uuid'@'$public_ip':'$K'' | base64 | tr -d "\n|=" | sed 's|^|vmess://|;s|$|?obfs=http|')
        echo -e "[${BLUE}$K${BLANK}] ${YELLOW}$Shadowrocket${BLANK}\n"
    done
}

panel(){
    public_ip=$(ip_info get_ip)
	color_status v2ray_status $wp/v2ray
    core_version=$($wp/v2ray -version | sed -n "1p" | awk '{print $2}')
    v2ray_ports=$(awk '{print $1}' $wp/v2ray.ini)
    connections=""
    for Port in $v2ray_ports;do
        connection=$(echo -e "[${YELLOW}$Port ${GREEN}$(get_connections $Port)${BLANK}]")
        connections="$connection $connections"
    done
    var=1

    show_config
    echo
    echo -e "[${YELLOW}端口 ${GREEN}连接数${BLANK}] $connections"
    echo
    echo -e "  $((var++)). 开/关${v2ray_status}V2Ray ${GREEN}$core_version${BLANK}"
    echo "  $((var++)). 卸载V2Ray"
    echo "  $((var++)). 添加一个端口"
    echo "  $((var++)). 删除一个端口"
    echo "  $((var++)). 更改端口设置"
    echo "  $((var++)). 查看Shadowrocket配置"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "$v2ray_status" = "$GREEN" ];then
                stop_service
            elif grep -q "[0-9]" $wp/v2ray.ini;then
                start_service
            fi
            clear && panel
            ;;
        $((var++)) )
			if warning_read;then
				bash $wp/uninstall.sh
				clear && echo "V2Ray已卸载！"
			else
				clear && panel
			fi
            ;;
        $((var++)) )
            add_port
            clear && panel
            ;;
        $((var++)) )
            del_port
            clear && panel
            ;;
        $((var++)) )
            change_uuid
            clear && panel
            ;;
        $((var++)) )
            show_shadowrocket
            exit 0
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
