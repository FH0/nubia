#!/bin/bash
wp="/usr/local/v2ray"
. $wp/functions.sh

install_v2ray() {
    latestVersion=$(curl -s https://github.com/v2ray/v2ray-core/releases/latest | sed 's|.*tag/\(.*\)".*|\1|')
    if [ ! -z "$(uname -m | grep -E 'amd64|x86_64')" ]; then
        ARCH="64"
    elif [ ! -z "$(uname -m | grep -E '86')" ]; then
        ARCH="32"
    elif [ ! -z "$(uname -m | grep -E 'armv8|aarch64')" ]; then
        ARCH="arm64-v8a"
    elif [ ! -z "$(uname -m | grep -E 'arm')" ]; then
        ARCH="arm32-v7a"
    elif [ ! -z "$(uname -m | grep -E 'mips64')" ]; then
        # check little/big endian 0->big 1->little
        if [ "$(echo -n I | hexdump -o | awk '{ print substr($2,6,1); exit}')" == "1" ]; then
            ARCH="mips64le"
        else
            ARCH="mips64"
        fi
    elif [ ! -z "$(uname -m | grep -E 'mips')" ]; then
        # check little/big endian 0->big 1->little
        if [ "$(echo -n I | hexdump -o | awk '{ print substr($2,6,1); exit}')" == "1" ]; then
            ARCH="mipsle"
        else
            ARCH="mips"
        fi
    else
        colorEcho $RED "不支持的系统架构！"
        bash $wp/uninstall.sh >/dev/null 2>&1
        exit 1
    fi
    colorEcho $BLUE "正在下载最新核心 $ARCH $latestVersion ..."
    curl -sOL https://github.com/v2ray/v2ray-core/releases/download/$latestVersion/v2ray-linux-$ARCH.zip
    unzip -q -o v2ray-linux-$ARCH.zip v2ray v2ctl -d $wp
    rm -f v2ray-linux-$ARCH.zip

    chmod -R 777 $wp

    colorEcho $BLUE "正在安装V2Ray控制面板 ..."
    ip_info init
    cp $wp/manage_panel.sh /bin/v2

    colorEcho $BLUE "正在设置 DNS ..."
    DNS=$(grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' /etc/resolv.conf | sed -n '1p')
    [ ! -z "$DNS" ] && sed -i "s|^DNS=.*|DNS=\"$DNS\"|" $wp/config_reload.sh

    colorEcho $BLUE "正在开启自动更新程序 ..."
    (
        crontab -l | sed '/v2ray_update\.sh/d'
        echo "00 03 * * * root $wp/v2ray_update.sh"
    ) | crontab -
}

main() {
    install_v2ray
    colorEcho $GREEN "V2Ray安装完成！输入v2可进入控制面板！"
}

main
