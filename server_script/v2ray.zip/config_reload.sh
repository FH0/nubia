#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

tcpConf="      \"streamSettings\": {\n        \"network\": \"tcp\",\n          \"tcpSettings\": {\n            \"header\": {\n              \"type\": \"http\",\n              \"response\": {\n                \"version\": \"1.1\",\n                \"status\": \"200\",\n                \"reason\": \"OK\",\n                \"headers\": {\n                  \"Content-Type\": [\n                    \"text/html\"\n                    ],\n                  \"Connection\": [\n                    \"keep-alive\"\n                  ]\n                }\n              }\n            }\n          }\n      }"
kcpConf="      \"streamSettings\": {\n        \"network\": \"kcp\",\n          \"kcpSettings\": {\n            \"mtu\": 1350,\n            \"tti\": 20,\n            \"uplinkCapacity\": 5,\n            \"downlinkCapacity\": 20,\n            \"congestion\": false,\n            \"readBufferSize\": 1,\n            \"writeBufferSize\": 1,\n            \"header\": {\n              \"type\": \"none\"\n            }\n          }\n      }"
wsConf="      \"streamSettings\": {\n        \"network\": \"ws\",\n          \"wsSettings\": {\n            \"path\": \"/\"\n          }\n      }"
echo -e "{  \n  \"inbounds\": [" > $wp/config.json
v2ray_ports=$(grep -Eo "^[0-9]{1,5}" $wp/v2ray.ini)
for N in ${v2ray_ports};do
    v2ray_uuid=$(grep "^$N " $wp/v2ray.ini | awk '{print $3}')
    if [ "$(grep "^$N " $wp/v2ray.ini | awk '{print $2}')" = "ws" ];then
        network=$wsConf
    elif [ "$(grep "^$N " $wp/v2ray.ini | awk '{print $2}')" = "tcp" ];then
        network=$tcpConf
    else
        network=$kcpConf
    fi
    echo -e "    {\n      \"port\": $N,\n      \"protocol\": \"vmess\",\n      \"settings\": {\n        \"clients\": [\n          {\n            \"id\": \"$v2ray_uuid\",\n            \"alterId\": 100\n          }\n        ]\n      },\n$network\n    }," >> $wp/config.json
done
echo -e "  ],\n  \"outbounds\": [\n    {\n      \"protocol\": \"freedom\",\n      \"settings\": {}\n    }\n  ]\n}" >> $wp/config.json
sed -i ':a;N;$!ba;s|,\n  \]|\n  \]|' $wp/config.json
