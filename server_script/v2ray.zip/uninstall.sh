#!/bin/bash
wp="/usr/local/v2ray"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/v2

crontab -l | sed '/v2ray_update\.sh/d' | crontab -
