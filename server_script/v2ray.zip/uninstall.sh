#!/bin/bash
wp="/usr/local/v2ray"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/v2

sed -i '/v2ray_update\.sh/d' /etc/crontab
