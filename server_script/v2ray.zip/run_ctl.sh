#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"
. $wp/functions.sh

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
pkill -f $wp/v2ray

if [ "$1" = "start" ];then
    enable_tcp_fastopen
    for dport in $(awk '{print $1}' $wp/v2ray.ini);do
        iptables -I INPUT -p tcp --dport $dport -m comment --comment "$wp" -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m comment --comment "$wp" -j ACCEPT
    done
	nohup $wp/v2ray -config $wp/config.json >/dev/null 2>&1 &
fi
