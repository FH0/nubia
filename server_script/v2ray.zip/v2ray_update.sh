#!/bin/bash
wp="/usr/local/v2ray"
. $wp/functions.sh

old_core=$($wp/v2ray -version | sed -n "1p" | awk '{print $2}' | sed "s|v||")
latest_core=$(curl -s https://github.com/v2fly/v2ray-core/releases/latest | sed 's|.*tag/v\(.*\)".*|\1|')

if pgrep -f $wp/v2ray && [ "$old_core" != "$latest_core" ]; then
    curl -sOL https://github.com/v2fly/v2ray-core/releases/download/v${latest_core}/v2ray-linux-64.zip
    unzip -q -o v2ray-linux-64.zip v2ray v2ctl -d $wp
    chmod -R 777 $wp
    rm -f v2ray-linux-64.zip
    start_service
fi
