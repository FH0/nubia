#!/bin/bash
wp="/usr/local/stn"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/stn
