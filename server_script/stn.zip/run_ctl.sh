#!/bin/bash
wp="/usr/local/stn"
. $wp/functions.sh

bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")
kill_path $wp/stn 

if [ "$1" = "start" ]; then
	address=$(grep "address" $wp/config.json | sed -n '1p' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')

	for port in $(grep "port" $wp/config.json | grep -Eo "[0-9]*"); do
		iptables -I INPUT -p tcp --dport $port -m comment --comment "${wp}" -j ACCEPT
	done

	$wp/stn -c $wp/config.json >$wp/running.log 2>&1
fi
