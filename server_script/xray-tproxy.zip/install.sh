#!/bin/bash
wp="/usr/local/xray-tproxy"
. $wp/functions.sh

install() {
    chmod -R 777 $wp

    colorEcho $BLUE "正在安装 xray-tproxy 控制面板..."
    cp $wp/manage_panel.sh /bin/xt
}

main() {
    install
    colorEcho $GREEN "xray-tproxy 安装完成！输入 xt 可进入控制面板！"
}

main
