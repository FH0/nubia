#!/bin/bash
wp="/usr/local/xray-tproxy"
. $wp/functions.sh

stop() {
    kill_path $wp/xray

    ip rule | sed -n '/ 30000$/{s|.*from|ip rule del from |g;p}' | sh
    ip route flush table 30000 iptables -t mangle -F PROXY_OUTPUT

    iptables -t mangle -F PROXY_OUTPUT
    iptables -t mangle -D OUTPUT -j PROXY_OUTPUT
    iptables -t mangle -X PROXY_OUTPUT
    iptables -t mangle -F PROXY_PREROUTING
    iptables -t mangle -D PREROUTING -j PROXY_PREROUTING
    iptables -t mangle -X PROXY_PREROUTING
} >/dev/null 2>&1

start() {
    nohup $wp/xray >/dev/null 2>&1 &

    interface=$(ip route get 8.8.8.8 | awk -F 'dev' '{print $2}' | awk '{print $1}')
    interface_address=$(ifconfig $interface | grep 'inet ' | awk -F 'inet ' '{print $2}' | awk '{print $1}')
    interface_netmask=$(ifconfig $interface | grep 'netmask ' | awk -F 'netmask ' '{print $2}' | awk '{print $1}')

    ip rule add fwmark 30000 table 30000
    ip route replace local default dev lo table 30000

    iptables -t mangle -N PROXY_OUTPUT
    iptables -t mangle -N PROXY_PREROUTING

    iptables -t mangle -I OUTPUT -j PROXY_OUTPUT
    iptables -t mangle -I PREROUTING -j PROXY_PREROUTING

    iptables -t mangle -A PROXY_OUTPUT -m mark --mark 30001 -j ACCEPT
    iptables -t mangle -A PROXY_OUTPUT ! -o $interface -j ACCEPT
    iptables -t mangle -A PROXY_OUTPUT -p udp --dport 53 -j MARK --set-mark 30000
    iptables -t mangle -A PROXY_OUTPUT -o $interface -d $interface_address/$interface_netmask -j ACCEPT
    iptables -t mangle -A PROXY_OUTPUT -p tcp -j MARK --set-mark 30000
    iptables -t mangle -A PROXY_OUTPUT -p udp -j MARK --set-mark 30000

    iptables -t mangle -A PROXY_PREROUTING -p tcp -m mark --mark 30000 -j TPROXY --on-ip 127.0.0.1 --on-port 30000 --tproxy-mark 30000
    iptables -t mangle -A PROXY_PREROUTING -p udp -m mark --mark 30000 -j TPROXY --on-ip 127.0.0.1 --on-port 30000 --tproxy-mark 30000
}

stop
[ "$1" = "start" ] && start
