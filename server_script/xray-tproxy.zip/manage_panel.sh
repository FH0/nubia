#!/bin/bash
wp="/usr/local/xray-tproxy"
. $wp/functions.sh

panel() {
    color_status xt_status $wp/xray
    var=1

    cat $wp/config.json
    echo
    echo -e "  $((var++)). 开/关${xt_status} xray-tproxy${BLANK}"
    echo "  $((var++)). 卸载 xray-tproxy"
    echo "  $((var++)). 编辑配置文件"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "$xt_status" = "$GREEN" ]; then
            stop_service
        else
            start_service
        fi
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            bash $wp/uninstall.sh
            clear && echo " xray-tproxy 已卸载！"
        else
            clear && panel
        fi
        ;;
    $((var++)))
        vi $wp/config.json
        start_service
        clear && panel
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
