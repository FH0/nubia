#!/bin/bash
wp="/usr/local/xray-tproxy"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/xt
