#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/BBR"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

systemd_init() {
    echo -e '#!/bin/bash\nexport PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"' > /bin/systemd_init
    echo -e "$1" >> /bin/systemd_init
    echo -e "systemctl disable systemd_init.service\nrm -f /etc/systemd/system/systemd_init.service /bin/systemd_init" >> /bin/systemd_init
    chmod +x /bin/systemd_init
    echo -e '[Unit]\nDescription=koolproxy Service\nAfter=network.target\n\n[Service]\nType=forking\nExecStart=/bin/systemd_init\n\n[Install]\nWantedBy=multi-user.target' > /etc/systemd/system/systemd_init.service
    systemctl daemon-reload
    systemctl enable systemd_init.service
} > /dev/null 2>&1

install_bbr() {
    if ! lsmod | grep -q "bbr";then
        if (($(uname -r | grep -Eo '^.')>4)) || (uname -r | grep -q "^4" && (($(uname -r | awk -F "." '{print $2}')>=9)));then
            sed -i '/^net.core.default_qdisc=fq$/d' /etc/sysctl.conf
            sed -i '/^net.ipv4.tcp_congestion_control=bbr$/d' /etc/sysctl.conf
            echo "net.core.default_qdisc=fq" >> /etc/sysctl.conf
            echo "net.ipv4.tcp_congestion_control=bbr" >> /etc/sysctl.conf
            sysctl -p >/dev/null 2>&1 && colorEcho $GREEN "BBR 启用成功！"
            exit 0
        elif [ -z "$(command -v yum)" ];then
            colorEcho $BLUE "正在下载 4.16 内核..."
            curl -sL -o 4.16.deb http://kernel.ubuntu.com/~kernel-ppa/mainline/v4.16/linux-image-4.16.0-041600-generic_4.16.0-041600.201804012230_amd64.deb
            colorEcho $BLUE "正在安装 4.16 内核..."
            dpkg -i 4.16.deb >/dev/null 2>&1
            rm -f 4.16.deb
        else
            colorEcho $BLUE "正在添加源支持..."
            rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org >/dev/null 2>&1
            rpm -Uvh http://www.elrepo.org/elrepo-release-7.0-3.el7.elrepo.noarch.rpm >/dev/null 2>&1
            colorEcho $BLUE "正在安装新内核..."
            yum --enablerepo=elrepo-kernel install kernel-ml -y >/dev/null 2>&1
            grub2-set-default 0
            grub2-mkconfig -o /boot/grub2/grub.cfg >/dev/null 2>&1
        fi
        colorEcho $GREEN "新内核安装完成！"
        colorEcho ${YELLOW} "重启系统后即可启用 BBR！"
		systemd_init "sed -i '/^net.core.default_qdisc=fq\$/d' /etc/sysctl.conf\nsed -i '/^net.ipv4.tcp_congestion_control=bbr\$/d' /etc/sysctl.conf\necho \"net.core.default_qdisc=fq\" >> /etc/sysctl.conf\necho \"net.ipv4.tcp_congestion_control=bbr\" >> /etc/sysctl.conf\nsysctl -p"
    fi
    colorEcho $GREEN "输入 bbr 可进入控制面板！"
}

main(){
    chmod -R 777 $wp
	
    colorEcho $BLUE "正在安装 BBR 控制面板..."
	cp $wp/manage_panel.sh /bin/bbr

    install_bbr
}

main
