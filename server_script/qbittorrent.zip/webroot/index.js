/**
 * modify "Last Modified" column
 */
function timeStrToNum() {
  var timeMap = new Map([
    ["Jan", "1"],
    ["Feb", "2"],
    ["Mar", "3"],
    ["Apr", "4"],
    ["May", "5"],
    ["Jun", "6"],
    ["Jul", "7"],
    ["Aug", "8"],
    ["Sep", "9"],
    ["Oct", "10"],
    ["Nov", "11"],
    ["Dec", "12"],
  ]);

  var timeStringList = document.querySelectorAll("td.m");

  timeStringList.forEach((timeString) => {
    timeMap.forEach((value, key) => {
      timeString.innerHTML = timeString.innerHTML.replace(" ", "&nbsp;&nbsp;"); // one space to two
      timeString.innerHTML = timeString.innerHTML.replace(key, value);
    });
  });
}

/**
 * remove "Type" column
 */
function removeType() {
  var types = document.querySelectorAll(".t");
  types.forEach((type) => {
    console.log(type);
    type.remove();
  });
}

timeStrToNum();
removeType();
