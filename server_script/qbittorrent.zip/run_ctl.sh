#!/bin/bash
wp="/usr/local/qbittorrent"
. $wp/functions.sh

kill_path $wp/qbittorrent-nox
$wp/nginx -p /tmp -c $wp/nginx.conf -s stop
bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")

if [ "$1" = "start" ]; then
    iptables -I INPUT -p tcp --dport $(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*") -m comment --comment "$wp" -j ACCEPT
    $wp/nginx -p /tmp -c $wp/nginx.conf
    $wp/qbittorrent-nox --webui-port=$(cat $wp/qbt_port) --profile=$wp -d
fi
