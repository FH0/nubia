#!/bin/bash
wp="/usr/local/qbittorrent"
. $wp/functions.sh

kill_path $wp/qbittorrent-nox
kill_path $wp/lighttpd
bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")

if [ "$1" = "start" ]; then
    iptables -I INPUT -p tcp --dport $(grep "server.port" $wp/lighttpd.conf | grep -Eo "[0-9]*") -m comment --comment "$wp" -j ACCEPT
    $wp/lighttpd -f $wp/lighttpd.conf
    $wp/qbittorrent-nox --webui-port=$(cat $wp/qbt_port) --profile=$wp -d
fi
