#!/bin/bash
wp="/usr/local/qbittorrent"
. $wp/functions.sh

panel() {
    var=1
    public_ip=$(ip_info get_ip)
    nginx_port=$(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*")
    qbt_port=$(cat $wp/qbt_port)
    download_path=$(grep "location" $wp/nginx.conf | awk '{print $2}')
    color_status qbt_status $wp/qbittorrent-nox $wp/nginx
    system_storage=$(df -h | grep "/$" | awk '{print $(NF-2)}')

    echo
    echo -e "       ${BLUE}剩余存储: ${YELLOW}${system_storage}${BLANK}"
    echo -e "${BLUE}qbittorrent地址: ${YELLOW}http://$public_ip:$qbt_port${BLANK}"
    echo -e "   ${BLUE}下载页面地址: ${YELLOW}http://$public_ip:$nginx_port$download_path${BLANK}"
    echo
    echo -e "  $((var++)). 开/关${qbt_status}qbittorrent${BLANK}"
    echo "  $((var++)). 设置nginx（下载）"
    echo "  $((var++)). 设置qbittorrent端口"
    echo "  $((var++)). 卸载qbittorrent"
    echo "  $((var++)). 清空已下载文件"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "${GREEN}" = "$qbt_status" ]; then
            stop_service
        else
            start_service
        fi
        clear && panel
        ;;
    $((var++)))
        vi $wp/nginx.conf
        start_service
        clear && panel
        ;;
    $((var++)))
        vi $wp/qbt_port
        start_service
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            bash $wp/uninstall.sh
            clear && echo "qbittorrent已卸载！" && exit 0
        else
            clear && panel
        fi
        ;;
    $((var++)))
        warning_read && rm -rf $wp/download/*
        clear && panel
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
