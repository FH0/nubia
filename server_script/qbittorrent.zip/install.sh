#!/bin/bash
wp="/usr/local/qbittorrent"
. $wp/functions.sh

install() {
    chmod -R 777 $wp

    colorEcho $BLUE "正在安装qbittorrent控制面板..."
    ip_info init
    cp $wp/manage_panel.sh /bin/qb

    colorEcho $BLUE "正在设置端口..."
    nginx_port=$(random_port)
    qbt_host=127.0.0.1
    qbt_port=$(random_port)
    while [ "$nginx_port" = "$qbt_port" ]; do
        qbt_port=$(random_port)
    done
    sed -i "s/\(listen *\)[0-9]*/\1$nginx_port/g" $wp/nginx.conf
    echo $qbt_port >$wp/qbt_port

    colorEcho $BLUE "正在设置随机路径..."
    random_download_location=$(random_password 6)
    sed -i "s|location.*|location /$random_download_location {|" $wp/nginx.conf

    grep -q "^nobody" /etc/group || groupadd nobody

    colorEcho $BLUE "正在启动qbittorrent..."
    start_service
}

main() {
    install
    colorEcho $YELLOW "初始用户：admin，初始密码：adminadmin。及时修改哦"
    colorEcho $GREEN "qbittorrent安装完成！输入qb可进入控制面板！"
}

main
