#!/bin/bash
wp="/usr/local/qbittorrent"
. $wp/functions.sh

install() {
    chmod -R 777 $wp

    colorEcho $BLUE "正在安装qbittorrent控制面板..."
    ip_info init
    cp $wp/manage_panel.sh /bin/qb

    colorEcho $BLUE "正在设置端口..."
    nginx_port=$(random_port)
    qbt_host=127.0.0.1
    qbt_port=$(random_port)
    while [ "$nginx_port" = "$qbt_port" ]; do
        qbt_port=$(random_port)
    done
    sed -i "s/\(listen *\)[0-9]*/\1$nginx_port/g" $wp/nginx.conf
    echo $qbt_port >$wp/qbt_port

    colorEcho $BLUE "正在设置随机路径..."
    random_download_location=$(random_password 6)
    sed -i "s|location.*|location /$random_download_location {|" $wp/nginx.conf

    grep -q "^nobody" /etc/group || groupadd nobody

    colorEcho $BLUE "正在启动qbittorrent..."
    start_service

    colorEcho $BLUE "正在设置qbittorrent..."
    sleep 1
    qbt_username=admin
    qbt_password=adminadmin
    qbt_cookie=$(curl --silent --fail --show-error \
        --cookie-jar - \
        --request GET "$qbt_host:$qbt_port/api/v2/auth/login?username=$qbt_username&password=$qbt_password")
    # password download_path share_limit language
    echo "$qbt_cookie" | curl "http://$qbt_host:$qbt_port/api/v2/app/setPreferences" \
        --cookie - \
        -H 'X-Requested-With: XMLHttpRequest' \
        -H 'Content-type: application/x-www-form-urlencoded; charset=UTF-8' \
        --data-urlencode 'json={"web_ui_password":"'$random_download_location'","save_path":"/usr/local/qbittorrent/download/","max_seeding_time_enabled":true,"max_seeding_time":1440,"max_ratio_enabled":true,"max_ratio":1,"locale":"zh"}'
}

main() {
    install
    colorEcho $YELLOW "初始用户：admin，初始随机密码：$random_download_location"
    colorEcho $GREEN "qbittorrent安装完成！输入qb可进入控制面板！"
}

main
