#!/bin/bash
wp="/usr/local/qbittorrent"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/qb
