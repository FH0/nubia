#!/bin/bash
wp="/usr/local/l_ygk"
. $wp/functions.sh

install_ygk() {
    chmod -R 777 $wp

    colorEcho $BLUE "正在安装ygk控制面板..."
    cp $wp/manage_panel.sh /bin/lk

    colorEcho $BLUE "正在调整内核参数..."
    sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
    echo "net.ipv4.ip_forward = 1" >>/etc/sysctl.conf
    echo 1 >/proc/sys/net/ipv4/ip_forward

    colorEcho $BLUE "正在设置日志文件路径..."
    sed -i "s|log_file\".*|log_file\": \"$wp/ygk.log\",|" $wp/ygk.json

    colorEcho $BLUE "正在设置 tun_post ..."
    sed -i "s|tun_post\".*|tun_post\": \"$wp/tun_post.sh\"|" $wp/ygk.json
}

main() {
    cmd_need "hexdump"
    install_ygk
    colorEcho $GREEN "l_ygk安装完成！输入lk可进入控制面板！"
}

main
