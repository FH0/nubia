#!/bin/bash
wp="/usr/local/l_ygk"
. $wp/functions.sh

allow_ip="0.0.0.0/8,100.64.0.0/10,127.0.0.0/8,169.254.0.0/16,192.0.0.0/24,192.0.2.0/24,192.88.99.0/24,198.18.0.0/15,198.51.100.0/24,203.0.113.0/24,172.16.0.0/12,192.168.0.0/16,10.0.0.0/8,224.0.0.0/3"

iptables() {
  /sbin/iptables -w $@
}

stop() {
  kill_path $wp/ygk
  ip rule | sed -n '/lookup 110000/{s|.*from|ip rule del from |g;p}' | sh
  ip rule | sed -n '/lookup 120000/{s|.*from|ip rule del from |g;p}' | sh
  ip route flush table 110000
  ip route flush table 120000
  iptables -t nat -F YNPO
  iptables -t nat -D POSTROUTING -j YNPO
  iptables -t nat -X YNPO
  iptables -t mangle -F YMO
  iptables -t mangle -D OUTPUT -j YMO
  iptables -t mangle -X YMO
}

vim_config() {
  # tun_post
  printf "ip route flush table 110000\n" >$wp/tun_post.sh
  printf "ip route replace default dev l_ygk table 120000 # DNS\n" >>$wp/tun_post.sh
  printf "ip -batch $wp/abroad_route.txt\n" >>$wp/tun_post.sh
  printf "%s\n" 'address=$(ip addr | grep "global l_ygk" | ip addr | grep global\ l_ygk  | grep -Eo "([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,2}")' >>$wp/tun_post.sh
  printf "%s\n" '[ ! -z "$address" ] && iptables -t mangle -I YMO -d $address -j MARK --set-mark 0x110000' >>$wp/tun_post.sh
  printf "exit 0\n" >>$wp/tun_post.sh
  chmod +x $wp/tun_post.sh
}

add_rules() {
  # 添加路由
  ip rule add from all fwmark 0x110000 lookup 110000
  ip rule add from all fwmark 0x120000 lookup 120000

  # 初始化 iptables 规则
  iptables -t nat -N YNPO
  iptables -t nat -I POSTROUTING -j YNPO
  iptables -t mangle -N YMO
  iptables -t mangle -I OUTPUT -j YMO

  # 自动设置 tun 地址
  iptables -t nat -A YNPO -o l_ygk -j MASQUERADE

  iptables -t mangle -A YMO -j MARK --set-xmark 0x110000
  iptables -t mangle -I YMO -d $allow_ip -j ACCEPT
  iptables -t mangle -I YMO -o lo -j ACCEPT
  iptables -t mangle -I YMO -p 17 --dport 53 -j MARK --set-xmark 0x120000
  iptables -t mangle -I YMO -m owner --gid-owner 110000 -j ACCEPT

  # 跳点控制
  iptables -t mangle -I YMO -m state --state INVALID -j DROP
}

bin_start() {
  echo -n >$wp/ygk.log
  $wp/ygk -c $wp/ygk.json
} >>$wp/ygk.log 2>&1

start() {
  vim_config
  add_rules
  bin_start &
}

stop
[ "$1" = "start" ] && start
