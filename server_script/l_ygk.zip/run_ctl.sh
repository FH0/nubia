#!/bin/bash
wp="/usr/local/l_ygk"
. $wp/functions.sh

shopt -s expand_aliases >/dev/null 2>&1
allow_ip="0.0.0.0/8,100.64.0.0/10,127.0.0.0/8,169.254.0.0/16,192.0.0.0/24,192.0.2.0/24,192.88.99.0/24,198.18.0.0/15,198.51.100.0/24,203.0.113.0/24,172.16.0.0/12,192.168.0.0/16,10.0.0.0/8,224.0.0.0/3"
if iptables --help | grep -q "xtable"; then
  alias iptables="iptables -w"
else
  iptables() {
    /system/bin/iptables $@
    tmp="$?"
    [ "$tmp" = "4" ] && iptables $@
    return $tmp
  }
fi

stop() {
  kill_path $wp/ygk
  kill_path $wp/dnsmasq
  ip rule | sed -n '/lookup 110000/{s|.*from|ip rule del from |g;p}' | sh
  ip route flush table 110000
  iptables -F YFF
  iptables -D FORWARD -j YFF
  iptables -X YFF
  iptables -t nat -F YNO
  iptables -t nat -D OUTPUT -j YNO
  iptables -t nat -X YNO
  iptables -t nat -F YNP
  iptables -t nat -D PREROUTING -j YNP
  iptables -t nat -X YNP
  iptables -t nat -F YNPO
  iptables -t nat -D POSTROUTING -j YNPO
  iptables -t nat -X YNPO
  iptables -t mangle -F YMO
  iptables -t mangle -D OUTPUT -j YMO
  iptables -t mangle -X YMO
  iptables -t mangle -F YMP
  iptables -t mangle -D PREROUTING -j YMP
  iptables -t mangle -X YMP
}

vim_config() {
  . $wp/dns.conf

  # tun_post
  printf "ip route flush table 110000\n" >$wp/tun_post.sh
  printf "ip -batch $wp/abroad_route.txt\n" >>$wp/tun_post.sh
  printf "%s\n" 'address=$(ip addr | grep "global l_ygk" | ip addr | grep global\ l_ygk  | grep -Eo "([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,2}")' >>$wp/tun_post.sh
  printf "%s\n" '[ ! -z "$address" ] && iptables -t mangle -I YMO -d $address -j MARK --set-mark 0x110000' >>$wp/tun_post.sh
  printf "exit 0\n" >>$wp/tun_post.sh
  chmod +x $wp/tun_post.sh

  # dnsmasq
  sed -i "s|server=.*|server=$DNS|" $wp/dnsmasq.conf
  sed -i "s|conf-file.*|conf-file=$wp/accelerated-domains.china.conf|" $wp/dnsmasq.conf
  sed -i "s|$(sed -n '1{s|.*/\(.*\)|\1|;p}' $wp/accelerated-domains.china.conf)|$ChinaDNS|g" $wp/accelerated-domains.china.conf
}

add_rules() {
  # 添加路由
  ip rule add from all fwmark 0x110000 lookup 110000

  # 初始化 iptables 规则
  iptables -N YFF
  iptables -I FORWARD -j YFF
  iptables -t nat -N YNO
  iptables -t nat -I OUTPUT -j YNO
  iptables -t nat -N YNP
  iptables -t nat -I PREROUTING -j YNP
  iptables -t nat -N YNPO
  iptables -t nat -I POSTROUTING -j YNPO
  iptables -t mangle -N YMO
  iptables -t mangle -I OUTPUT -j YMO
  iptables -t mangle -N YMP
  iptables -t mangle -I PREROUTING -j YMP

  # 自动设置 tun 地址
  iptables -t nat -A YNPO -o l_ygk -j MASQUERADE

  # 设置DNS
  iptables -t nat -A YNO -m owner --gid-owner 110000 -j ACCEPT
  iptables -t nat -A YNO -m owner --gid-owner 120000 -j ACCEPT
  iptables -t nat -A YNO -p 17 --dport 53 -j REDIRECT --to 10053

  iptables -t mangle -A YMO -j MARK --set-xmark 0x110000
  iptables -t mangle -I YMO -d $allow_ip -j ACCEPT
  iptables -t mangle -I YMO -o lo -j ACCEPT
  iptables -t mangle -I YMO -o tun+ -j ACCEPT
  iptables -t mangle -I YMO -o ap+ -j ACCEPT
  iptables -t mangle -I YMO -m owner --gid-owner 110000 -j ACCEPT

  # 跳点控制
  iptables -t mangle -I YMO -m state --state INVALID -j DROP
}

bin_start() {
  echo -n >$wp/ygk.log
  $wp/ygk -c $wp/ygk.json
  $wp/dnsmasq -C $wp/dnsmasq.conf
} >>$wp/ygk.log 2>&1

start() {
  vim_config
  add_rules
  bin_start &
}

stop
[ "$1" = "start" ] && start
