RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"
BLANK="\033[0m"

colorEcho() {
    COLOR=$1
    shift # delete first parameter
    echo -e "${COLOR}${@}${BLANK}"
    echo
}

colorRead() {
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT${BLANK}: "
    read $VARIABLE
    echo
}

get_connections() {
    port=$1
    if type ss >/dev/null 2>&1; then
        ss -tun state established sport = :$port | awk '{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l
    elif type netstat >/dev/null 2>&1; then
        netstat -tun | awk '$4~/:'$port'$/ && $6~/ESTABLISHED/{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l
    else
        colorEcho $RED "缺少 ss 或 netstat 命令"
        exit 1
    fi
}

ip_info() {
    if [ "$1" = "init" ]; then
        sed -i '/^##/d' $wp/manage_panel.sh
        tmp_data=$(curl -sL http://ip-api.com/json) ||
            tmp_data=$(curl -sL http://api.ipapi.com/check?access_key=d72b841ab430468491424731634bcbb2)
        echo -n "## " >>$wp/manage_panel.sh
        echo -n "$tmp_data" | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | tr '\n' ' ' >>$wp/manage_panel.sh
        echo "$tmp_data" | grep -Eo '"[A-Z][A-Z]"' | sed -n '$p' | awk -F '"' '{print $2}' >>$wp/manage_panel.sh
    elif [ "$1" = "get_ip" ]; then
        grep "^##" $wp/manage_panel.sh | awk '{print $2}'
    elif [ "$1" = "get_country" ]; then
        grep "^##" $wp/manage_panel.sh | awk '{print $3}'
    fi
}

stop_service() {
    $wp/run_ctl.sh stop
    if type systemctl >/dev/null 2>&1; then
        systemctl disable ${wp##*/}.service
        rm -f /etc/systemd/system/${wp##*/}.service
        systemctl daemon-reload
    elif [ -e "/etc/rc.local" ]; then
        tmp_echo=$(grep -v "$wp/run_ctl.sh" /etc/rc.local)
        echo "$tmp_echo" >/etc/rc.local
    fi
} >/dev/null 2>&1

start_service() {
    $wp/run_ctl.sh start
    if type systemctl >/dev/null 2>&1; then
        echo -e "[Unit]\nDescription=$wp\nAfter=network.target\n\n[Service]\nType=forking\nExecStart=$wp/run_ctl.sh start\nRestart=always\n\n[Install]\nWantedBy=multi-user.target" >/etc/systemd/system/${wp##*/}.service
        systemctl daemon-reload
        systemctl enable ${wp##*/}.service
    elif [ -e "/etc/rc.local" ]; then
        tmp_echo=$(grep -v "^exit" /etc/rc.local)
        echo "$tmp_echo" >/etc/rc.local
        echo "$wp/run_ctl.sh start" >>/etc/rc.local
        echo "exit 0" >>/etc/rc.local
    fi
} >/dev/null 2>&1

enable_tcp_fastopen() {
    if [ -e "/proc/sys/net/ipv4/tcp_fastopen" ]; then
        echo 3 >/proc/sys/net/ipv4/tcp_fastopen
    fi
}

cmd_need() {
    update_flag=0
    exit_flag=0

    for cmd in $1; do
        if type $cmd 2>&1 | grep -q ": not found"; then
            # check if auto install
            if type apt >/dev/null 2>&1; then
                # apt install package need update first
                if [ "update_flag" = "0" ]; then
                    apt update >/dev/null 2>&1
                    update_flag=1
                fi

                package=$(dpkg -S bin/$cmd 2>&1 | grep "bin/$cmd$" | awk -F':' '{print $1}')
                if [ ! -z "$package" ]; then
                    colorEcho $BLUE "正在安装 $cmd ..."
                    apt install $package -y >/dev/null 2>&1
                    continue
                fi
            elif type yum >/dev/null 2>&1; then
                package=$(yum whatprovides *bin/$cmd 2>&1 | grep " : " | awk -F' : ' '{print $1}' | sed -n '1p')
                if [ ! -z "$package" ]; then
                    colorEcho $BLUE "正在安装 $cmd ..."
                    yum install $package -y >/dev/null 2>&1
                    continue
                fi
            fi

            colorEcho $RED "找不到 $cmd 命令"
            exit_flag=1
        fi
    done

    if [ "$exit_flag" = "1" ]; then
        exit 1
    fi
}

random_password() {
    password_len=${1:-12}
    cat /dev/urandom | tr -dc a-zA-Z0-9 | head -c $password_len
}

random_port() {
    while true; do
        port=$(cat /dev/urandom | tr -dc 0-9 | head -c 5 | sed 's|^0*||g')

        ! [ "$port" -gt "1024" -a "$port" -lt "65536" ] && continue

        if type ss >/dev/null 2>&1; then
            if ss -ltun | awk '{print $5}' | grep -q ":$port\$"; then
                continue
            else
                printf "$port"
                break
            fi
        elif type netstat >/dev/null 2>&1; then
            if netstat -tun | awk '{print $4}' | grep -q ":$port\$"; then
                continue
            else
                printf "$port"
                break
            fi
        else
            colorEcho $RED "缺少 ss 或 netstat 命令"
            exit 1
        fi
    done
}

warning_read() {
    echo -e -n "请按下回车键以确认操作. . . "
    read -s -n1 input
    [ -z "$input" ] && return 0 || return 1
}

color_status() {
    eval $1="\\$RED"
    for check_cmd in ${@:2}; do
        pgrep -f $check_cmd || return 1
    done
    eval $1="\\$GREEN"
} &>/dev/null

kill_path() {
    kill -9 $(pgrep -f $1)
}