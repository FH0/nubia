#!/bin/bash
wp="/usr/local/swapfile"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

panel() {
    var=1
    swap_mem=$(swapon -v | grep 'eKzE1I' | awk '{print $3}')
    swap_used=$(swapon -v | grep 'eKzE1I' | awk '{print $4}')
    swap_status="" && swapon -v | grep 'eKzE1I' > /dev/null 2>&1 && swap_status="$GREEN"

    echo
    if [ ! -z "$swap_status" ];then
        echo -e "    \033[36mswap分区大小: \033[33m${swap_mem}\033[0m"
        echo -e "    \033[36m已使用: \033[33m${swap_used}\033[0m"
        echo
    fi
    echo -e "  $var. 开/关${swap_status}swap分区\033[0m" && ((var++))
    echo "  $var. 设置swap分区大小" && ((var++))
    echo "  $var. 卸载swap" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ ! -z "$swap_status" ];then
                swapoff $wp/eKzE1I
                sed -i "/eKzE1I swap/d" /etc/fstab
            else
                swapon $wp/eKzE1I
                echo '/root/eKzE1I swap swap defaults 0 0' >> /etc/fstab
            fi >/dev/null 2>&1
            clear && panel
            ;;
        $((var++)) )
            colorRead ${YELLOW} "请输入swap分区大小[默认为物理内存两倍]" input
            [ -z "$input" ] && input=$(($(grep 'MemTotal' /proc/meminfo | awk '{print $2}')/512))
            swapoff $wp/eKzE1I
            rm -f $wp/eKzE1I
            dd if=/dev/zero of=$wp/eKzE1I bs=1M count=$input > /dev/null 2>&1
            mkswap $wp/eKzE1I > /dev/null 2>&1
            chmod 600 $wp/eKzE1I
            swapon $wp/eKzE1I
            clear && panel
            ;;
        $((var++)) )
            read
            bash $wp/uninstall.sh
            clear && echo "swap已卸载！" && exit 0
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
