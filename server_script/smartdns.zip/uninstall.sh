#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/smartdns"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/sns
