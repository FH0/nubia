#!/bin/bash
wp="/usr/local/smartdns"
. $wp/functions.sh

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
pkill -f $wp/smartdns

if [ "$1" = "start" ];then
    enable_tcp_fastopen
	iptables -I INPUT -p udp --dport 53 -m comment --comment "$wp" -j ACCEPT
    nohup $wp/smartdns -c $wp/smartdns.conf -f &>/dev/null &
fi
