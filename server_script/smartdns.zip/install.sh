#!/bin/bash
wp="/usr/local/smartdns"
. $wp/functions.sh

install_smartdns(){
    chmod -R 777 $wp
    
    colorEcho $BLUE "正在安装 SmartDNS 控制面板..."
	ip_info init
    cp $wp/manage_panel.sh /bin/sns
	
    colorEcho $BLUE "正在启动 SmartDNS..."
	start_service
}

main(){
    install_smartdns
    colorEcho $GREEN "SmartDNS 安装完成！输入 sns 可进入控制面板！"
}

main
