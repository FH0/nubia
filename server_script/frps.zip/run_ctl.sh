#!/bin/bash
wp="/usr/local/frps"
. $wp/functions.sh

bash <(iptables -S | grep "$wp" | sed "s|-[AI] |-D |g;s|^|iptables |g")
pkill -f $wp/frps

if [ "$1" = "start" ];then
    iptables -I INPUT -p tcp --dport $(sed -n "2p" $wp/frps.ini | grep -Eo "[0-9]*") -m comment --comment "$wp" -j ACCEPT
    iptables -I INPUT -p udp --dport $(sed -n "2p" $wp/frps.ini | grep -Eo "[0-9]*") -m comment --comment "$wp" -j ACCEPT
	nohup $wp/frps -c $wp/frps.ini >/dev/null 2>&1 &
fi
