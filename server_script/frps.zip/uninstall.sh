#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/frps"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/frp
