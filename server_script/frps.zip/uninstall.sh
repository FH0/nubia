#!/bin/bash
wp="/usr/local/frps"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/frp
