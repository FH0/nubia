#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/frps"
. $wp/functions.sh

panel() {
    public_ip=$(ip_info get_ip)
	var=1
    frp_port=$(sed -n "2p" $wp/frps.ini | grep -Eo "[0-9]*")
    token=$(sed -n "3p" $wp/frps.ini | awk -F " = " '{print $2}')
    color_status frp_status $wp/frps

    echo
    echo -e "${BLUE}frp服务器: ${YELLOW}$public_ip:$frp_port${BLANK}"
    echo -e "    ${BLUE}token: ${YELLOW}$token${BLANK}"
    echo
    echo -e "  $((var++)). 开/关${frp_status}frp${BLANK}"
    echo "  $((var++)). 更改frp端口"
    echo "  $((var++)). 更改token"
    echo "  $((var++)). 卸载frp"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "${GREEN}" = "$frp_status" ];then
                stop_service
            else
                start_service
            fi
            clear && panel
            ;;
        $((var++)) )
            colorRead ${YELLOW} '请输入frp端口[默认随机]' Port
            [ -z "$Port" ] && Port=$(random_port)
            sed -i '2s|.*|bind_port = '$Port'|' $wp/frps.ini
            start_service
            clear && panel
            ;;
        $((var++)) )
            colorRead ${YELLOW} '请输入token[默认随机]' token
            [ -z "$token" ] && token=$(random_password 6)
            sed -i '3s|.*|token = '$token'|' $wp/frps.ini
            start_service
            clear && panel
            ;;
        $((var++)) )
            if warning_read;then
				bash $wp/uninstall.sh
				clear && echo "frp已卸载！" && exit 0
			else
				clear && panel
			fi
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
