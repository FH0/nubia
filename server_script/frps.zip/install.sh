#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/frps"
. $wp/functions.sh

install_frp(){
    chmod -R 777 $wp
	
    colorEcho $BLUE "正在安装frp控制面板..."
    ip_info init
	cp $wp/manage_panel.sh /bin/frp
    
    colorEcho $BLUE "正在初始化配置文件..."
    Port=$(random_port)
    token=$(random_password 6)
    echo -e "[common]\nbind_port = $Port\ntoken = $token" > $wp/frps.ini

    colorEcho $BLUE "正在启动frp..."
	start_service
}

main(){
    install_frp
    colorEcho $GREEN "frp安装完成！输入frp可进入控制面板！"
}

main
