#!/bin/bash
wp="/usr/local/oneindex"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/oi

sed -i "/oneindex/d" /etc/crontab
