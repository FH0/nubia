#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/oneindex"
. $wp/functions.sh

Upload(){
	colorRead ${YELLOW} '请输入oneindex路径[默认/]' oneindex_path
	[ -z "$oneindex_path" ] && oneindex_path="/"
		
	colorRead ${YELLOW} '请输入需上传的文件或文件夹路径' path
	[ -z "$path" -o ! -e "$path" ] && return
	clear
	if [ -d "$path" ];then
        $wp/php $wp/oneindex/one.php upload:folder $path $oneindex_path
        $wp/php $wp/oneindex/one.php cache:refresh
	else
        $wp/php $wp/oneindex/one.php upload:file $path $oneindex_path
        $wp/php $wp/oneindex/one.php cache:refresh
 	fi >> $wp/oneindex.log 2>&1 &
	echo -e "请查看${YELLOW}$wp/oneindex.log${BLANK}或${YELLOW}http://$public_ip:$Port${BLANK}了解上传情况"
}

panel(){
    public_ip=$(ip_info get_ip)
    color_status oneindex_status $wp/php
    Port=$(cat $wp/oneindex.ini)
    var=1

    echo
	echo -e "${BLUE}oneindex地址: ${YELLOW}http://$public_ip:$Port${BLANK}"
	echo -e "${YELLOW}绑定失败可以试试重启oneindex${BLANK}"
	echo
    echo -e "  $((var++)). 开/关${oneindex_status}oneindex${BLANK} ${GREEN}$core_version${BLANK}"
    echo "  $((var++)). 上传文件或文件夹"
    echo "  $((var++)). 卸载oneindex"
    echo "  $((var++)). 更改端口"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "$oneindex_status" = "$GREEN" ];then
                stop_service
            else
                start_service
            fi
            clear && panel
            ;;
        $((var++)) )
            Upload
            panel
            ;;
        $((var++)) )
            if warning_read;then
                bash $wp/uninstall.sh
                clear && echo "oneindex已卸载！"
            else
                clear && panel
            fi
            ;;
        $((var++)) )
			colorRead ${YELLOW} '请输入端口[默认随机]' Port
			[ -z "$Port" ] && Port=$(random_port)
			echo "$Port" > $wp/oneindex.ini
			start_service
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
