#!/bin/bash
wp="/usr/local/oneindex"
. $wp/functions.sh

Upload(){
	if [ -f "$wp/auth.json" ];then
		colorRead ${YELLOW} '请输入oneindex路径[默认/]' oneindex_path
		[ -z "$oneindex_path" ] && oneindex_path="/"

		colorRead ${YELLOW} '请输入需上传的文件或文件夹路径' path
		[ -z "$path" -o ! -e "$path" ] && clear && return
		clear
		{
			$wp/OneDriveUploader -c $wp/auth.json -s "$path" -r "$oneindex_path"
			$wp/php $wp/oneindex/one.php cache:refresh
		} >>$wp/OneDriveUploader.log 2>&1 &
		echo -e "请查看${YELLOW} $wp/OneDriveUploader.log ${BLANK}了解上传情况"
	else
		clear
		colorEcho ${YELLOW} "请先绑定 OneDriveUploader"
		colorEcho ${YELLOW} "访问 https://github.com/MoeClub/OneList/tree/master/OneDriveUploader#%E6%8E%88%E6%9D%83"
		colorRead ${YELLOW} "请输入返回的链接" url
		[ -z "$url" ] && clear && return
		echo "1. 国际版"
		echo "2. 个人版（家庭版）"
		echo "3. 中国版（世纪互联）"
		echo
		colorRead ${YELLOW} "请选择[默认国际版]" url_choice
		[ -z "$url_choice" ] && url_choice=1
		[ "$url_choice" = 1 ] && url_value=''
		[ "$url_choice" = 2 ] && url_value='-ms'
		[ "$url_choice" = 3 ] && url_value='-cn'
		$wp/OneDriveUploader -c $wp/auth.json $url_value -a "$url" >/dev/null 2>&1
		clear
	fi
}

panel(){
    public_ip=$(ip_info get_ip)
    color_status oneindex_status $wp/php
    Port=$(cat $wp/oneindex.ini)
    var=1

    echo
	echo -e "${BLUE}oneindex地址: ${YELLOW}http://$public_ip:$Port${BLANK}"
	[ ! -f "/usr/local/oneindex/oneindex/cache/cachedata.php" ] && echo -e "${YELLOW}绑定失败可以试试重启oneindex${BLANK}"
	echo
    echo -e "  $((var++)). 开/关${oneindex_status}oneindex${BLANK} ${GREEN}$core_version${BLANK}"
    echo "  $((var++)). 上传文件或文件夹"
    echo "  $((var++)). 卸载oneindex"
    echo "  $((var++)). 更改端口"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "$oneindex_status" = "$GREEN" ];then
                stop_service
            else
                start_service
            fi
            clear && panel
            ;;
        $((var++)) )
            Upload
            panel
            ;;
        $((var++)) )
            if warning_read;then
                bash $wp/uninstall.sh
                clear && echo "oneindex已卸载！"
            else
                clear && panel
            fi
            ;;
        $((var++)) )
			colorRead ${YELLOW} '请输入端口[默认随机]' Port
			[ -z "$Port" ] && Port=$(random_port)
			echo "$Port" > $wp/oneindex.ini
			start_service
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
