#!/bin/bash
wp="/usr/local/oneindex"
. $wp/functions.sh

install_oneindex() {
    chmod -R 777 $wp

    colorEcho $BLUE "正在安装oneindex控制面板..."
    ip_info init
    cp $wp/manage_panel.sh /bin/oi

    colorEcho $BLUE "正在开启oneindex自动刷新令牌..."
    colorEcho $BLUE "正在开启oneindex自动刷新缓存..."
    (
        crontab -l | sed '/oneindex/d'
        echo "0 * * * * $wp/php $wp/oneindex/one.php token:refresh"
        echo "*/10 * * * * $wp/php $wp/oneindex/one.php cache:refresh"
    ) | crontab -

    colorEcho $BLUE "正在启动oneindex..."
    echo "$(random_port)" >$wp/oneindex.ini
    start_service
}

main() {
    install_oneindex
    colorEcho $GREEN "oneindex安装完成！输入oi可进入控制面板！"
}

main
