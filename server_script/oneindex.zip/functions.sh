
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"
BLANK="\033[0m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}${BLANK}"
    echo
}

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT${BLANK}: "
    read $VARIABLE
    echo
}

get_connections(){
    port=$1
    if command -v ss >/dev/null;then
        ss -tun state established sport = :$port | awk '{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l
    elif command -v netstat >/dev/null;then
        netstat -tun | awk '$4~/:'$port'$/ && $6~/ESTABLISHED/{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l
    fi
}

ip_info(){
    if [ "$1" = "init" ];then
        sed -i '/^##/d' $wp/manage_panel.sh
        tmp_data=$(curl -sL http://ip-api.com/json) || \
            tmp_data=$(curl -sL http://api.ipapi.com/check?access_key=d72b841ab430468491424731634bcbb2)
        echo -n "## " >> $wp/manage_panel.sh
        echo -n "$tmp_data" | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | tr '\n' ' ' >> $wp/manage_panel.sh
        echo "$tmp_data" | grep -Eo '"[A-Z][A-Z]"' | sed -n '$p' | awk -F '"' '{print $2}' >> $wp/manage_panel.sh
    elif [ "$1" = "get_ip" ];then
        grep "^##" $wp/manage_panel.sh | awk '{print $2}'
    elif [ "$1" = "get_country" ];then
        grep "^##" $wp/manage_panel.sh | awk '{print $3}'
    fi
}

stop_service(){
    $wp/run_ctl.sh stop
    if command -v systemctl;then
        systemctl disable ${wp##*/}.service
        rm -f /etc/systemd/system/${wp##*/}.service
        systemctl daemon-reload
    elif [ -e "/etc/rc.local" ];then
        tmp_echo=$(grep -v "$wp/run_ctl.sh" /etc/rc.local)
        echo "$tmp_echo" > /etc/rc.local
    fi
} >/dev/null 2>&1

start_service(){
    $wp/run_ctl.sh start
    if command -v systemctl;then
        echo -e "[Unit]\nDescription=$wp\nAfter=network.target\n\n[Service]\nType=forking\nExecStart=$wp/run_ctl.sh start\nRestart=always\n\n[Install]\nWantedBy=multi-user.target" > /etc/systemd/system/${wp##*/}.service
        systemctl daemon-reload
        systemctl enable ${wp##*/}.service
    elif [ -e "/etc/rc.local" ];then
		tmp_echo=$(grep -v "^exit" /etc/rc.local)
		echo "$tmp_echo" > /etc/rc.local
		echo "$wp/run_ctl.sh start" >> /etc/rc.local
		echo "exit 0" >> /etc/rc.local
    fi
} >/dev/null 2>&1

enable_tcp_fastopen(){
	if [ -e "/proc/sys/net/ipv4/tcp_fastopen" ];then
		echo 3 > /proc/sys/net/ipv4/tcp_fastopen
	fi
}

cmd_need(){
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    for command in $1;do
        echo "$CHECK" | grep -q "$command" || CMD="$command $CMD"
    done
    if [ ! -z "$CMD" ];then
		colorEcho $BLUE "正在安装 $CMD ..."
		if [ -z "$(command -v yum)" ];then
			apt-get update
			apt-get install $CMD -y
		else
			yum install $CMD -y
		fi > /dev/null 2>&1
		clear
	fi
}

random_password(){
    password_len=${1:-12}
    cat /dev/urandom | tr -dc a-zA-Z0-9 | head -c $password_len
}

random_port(){
    port=$(awk -v min=1024 -v max=65535 'BEGIN{srand(); print int(min+rand()*(max-min+1))}')
    if command -v ss >/dev/null;then
        ss -ltun | awk '{print $5}' | grep -q ":$port\$" && random_port
		printf "$port"
    elif command -v netstat >/dev/null;then
        netstat -tun | awk '{print $4}' | grep -q ":$port\$" && random_port
		printf "$port"
    fi
}

warning_read(){
    echo -e -n "请按下回车键以确认操作. . . "
    read -s -n1 input
	[ -z "$input" ] && return 0 || return 1
}

color_status(){
    eval $1="\\$RED"
    for check_cmd in ${@:2};do
        pgrep -f $check_cmd || return 1
    done
    eval $1="\\$GREEN"
} &>/dev/null
