#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/ssr_jzdh"

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
python_ver=$(ls /usr/bin|grep -e "^python[23]\.[1-9]\+$"|tail -1)
$wp/setcap cap_net_bind_service=-ep /usr/bin/${python_ver}
kill $(ps -ef | grep "${python_ver} server\.py m" | grep -v "grep" | awk '{print $2}')

if [ "$1" = "start" ];then
    enable_tcp_fastopen
    for dport in $(cd $wp/shadowsocksr && python mujson_mgr.py -l | awk '{print $4}');do
        iptables -I INPUT -p tcp --dport $dport -m comment --comment "$wp" -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m comment --comment "$wp" -j ACCEPT
    done
    ulimit -n 512000
    cd $wp/shadowsocksr
	$wp/setcap cap_net_bind_service=+ep /usr/bin/${python_ver}
	su -s /bin/bash nobody -c "nohup ${python_ver} server.py m" >/dev/null 2>&1 &
fi
