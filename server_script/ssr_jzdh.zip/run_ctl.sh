#!/bin/bash
wp="/usr/local/ssr_jzdh"
. $wp/functions.sh

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
python_ver=$(ls /usr/bin|grep -e "^python[23]\.[1-9]\+$"|tail -1)
kill $(ps -ef | grep "${python_ver} server\.py m" | grep -v "grep" | awk '{print $2}')
kill_path $wp/gost 

if [ "$1" = "start" ];then
    enable_tcp_fastopen
    for dport in $(cd $wp/shadowsocksr && python mujson_mgr.py -l | awk '{print $4}');do
        iptables -I INPUT -p tcp --dport $dport -m comment --comment "$wp" -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m comment --comment "$wp" -j ACCEPT
    done
    ulimit -n 512000
    cd $wp/shadowsocksr
	nohup ${python_ver} server.py m >/dev/null 2>&1 &
	
	if [ -f "$wp/gost" ];then
		gost_port=$(cat $wp/gost.json | grep 'supppig' | cut -d':' -f4 | cut -d'"' -f1)
        iptables -I INPUT -p tcp --dport $gost_port -m comment --comment "$wp" -j ACCEPT
        iptables -I INPUT -p udp --dport $gost_port -m comment --comment "$wp" -j ACCEPT
		nohup $wp/gost -C $wp/gost.json >/dev/null 2>&1 &
	fi
fi
