#!/bin/bash
wp="/usr/local/ssr_jzdh"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/ssr
