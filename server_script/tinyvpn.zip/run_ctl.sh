#!/bin/bash
wp="/usr/local/tinyvpn"
. $wp/functions.sh

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
bash <(iptables -t nat -S | grep "$wp" | sed "s|^..|iptables -t nat -D|g")
pkill -f $wp/udp2raw
pkill -f $wp/tinyvpn
ip tuntap del tun100 mode tun

if [ "$1" = "start" ];then
	udp2raw_port=$(sed -n '1p' $wp/tu.ini | awk '{print $2}')
	udp2raw_key=$(sed -n '1p' $wp/tu.ini | awk '{print $3}')
	tinyvpn_port=$(sed -n '2p' $wp/tu.ini | awk '{print $2}')
	tinyvpn_key=$(sed -n '2p' $wp/tu.ini | awk '{print $3}')
	iptables -I INPUT -p tcp --dport $udp2raw_port -m comment --comment "$wp" -j ACCEPT
	iptables -I INPUT -p udp --dport $udp2raw_port -m comment --comment "$wp" -j ACCEPT
	iptables -t nat -I POSTROUTING -s 10.222.2.0/24 ! -d 10.222.2.0/24 -m comment --comment "$wp" -j MASQUERADE
	ip tuntap add tun100 mode tun
	ifconfig tun100 up
	setsid $wp/udp2raw -s -l 0.0.0.0:$udp2raw_port -r 127.0.0.1:$tinyvpn_port --raw-mode faketcp -a -k "$udp2raw_key" &>/dev/null &
	setsid $wp/tinyvpn -s -l 0.0.0.0:$tinyvpn_port --sub-net 10.222.2.0 --tun-dev tun100 -k "$tinyvpn_key" &>/dev/null &
fi
