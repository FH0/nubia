#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/tinyvpn"
. $wp/functions.sh

change_udp2raw_key() {
    colorRead ${YELLOW} '请输入密码[默认随机]' key
    [ -z "$key" ] && key=$(random_password 8)
    sed -i "1s|.*|$(sed -n '1p' $wp/tu.ini | awk '{print $1" "$2}') $key|" $wp/tu.ini
    start_service
}

change_tinyvpn_key() {
    colorRead ${YELLOW} '请输入密码[默认随机]' key
    [ -z "$key" ] && key=$(random_password 8)
    sed -i "2s|.*|$(sed -n '2p' $wp/tu.ini | awk '{print $1" "$2}') $key|" $wp/tu.ini
    start_service
}

panel(){
    public_ip=$(ip_info get_ip)
	color_status tu_status $wp/tinyvpn $wp/udp2raw
	udp2raw_port=$(sed -n '1p' $wp/tu.ini | awk '{print $2}')
	udp2raw_key=$(sed -n '1p' $wp/tu.ini | awk '{print $3}')
	tinyvpn_key=$(sed -n '2p' $wp/tu.ini | awk '{print $3}')
    var=1
	
	echo -e "udp2raw: ${YELLOW}$public_ip:$udp2raw_port${BLANK}"
    echo
    echo -e "  $((var++)). 开/关${tu_status} tinyvpn-udp2raw${BLANK}"
    echo "  $((var++)). 卸载 tinyvpn-udp2raw"
    echo -e "  $((var++)). 修改 udp2raw 密码 ${YELLOW}$udp2raw_key${BLANK}"
    echo -e "  $((var++)). 修改 tinyvpn 密码 ${YELLOW}$tinyvpn_key${BLANK}"
    echo -e "  $((var++)). 编辑启动参数（高级功能）"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "$tu_status" = "$GREEN" ];then
                stop_service
            else
                start_service
            fi
            clear && panel
            ;;
        $((var++)) )
			if warning_read;then
				bash $wp/uninstall.sh
				clear && echo " tinyvpn-udp2raw 已卸载！"
			else
				clear && panel
			fi
            ;;
        $((var++)) )
            change_udp2raw_key
            clear && panel
            ;;
        $((var++)) )
            change_tinyvpn_key
            clear && panel
            ;;
        $((var++)) )
            vi +22 $wp/run_ctl.sh
			start_service
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
