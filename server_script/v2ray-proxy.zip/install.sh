#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray-proxy"
. $wp/functions.sh

install_v2ray(){
    chmod -R 777 $wp
    
    colorEcho $BLUE "正在安装 v2ray 透明代理控制面板..."
    cp $wp/manage_panel.sh /bin/vp
	
	grep -q 'v2raY' /etc/passwd || useradd v2raY
}

main(){
    install_v2ray
    colorEcho $GREEN "v2ray 透明代理安装完成！输入 vp 可进入控制面板！"
}

main
