#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray-proxy"
. $wp/functions.sh

pkill -KILL -f $wp/v2raY
ip route flush table 1112
ip rule | grep "0x1112" | sed 's|.*from|ip rule del from |g' | sh
iptables -t nat -S | grep "$wp" | sed "s|^..|iptables -t nat -D|g" | sh
iptables -t mangle -S | grep "$wp" | sed "s|^..|iptables -t mangle -D|g" | sh

if [ "$1" = "start" ];then
	allow_ip="0.0.0.0/8,10.0.0.0/8,100.64.0.0/10,127.0.0.0/8,169.254.0.0/16,172.16.0.0/12,192.0.0.0/24,192.0.2.0/24,192.88.99.0/24,192.168.0.0/16,198.18.0.0/15,198.51.100.0/24,203.0.113.0/24,224.0.0.0/3"
	add_iptables(){ iptables -m comment --comment "$wp" $@; }
	add_iptables -t mangle -I OUTPUT -p udp -j MARK --set-xmark 0x1112/0xffffffff
	add_iptables -t mangle -I OUTPUT -d $allow_ip -j ACCEPT
	add_iptables -t mangle -I OUTPUT -p udp --dport 53 -j MARK --set-xmark 0x1112/0xffffffff
	add_iptables -t mangle -I OUTPUT -m owner --uid-owner v2raY -j ACCEPT
	add_iptables -t mangle -I PREROUTING -i lo -p udp -j TPROXY --on-port 1112 --tproxy-mark 0x1112
	add_iptables -t mangle -I PREROUTING -d $allow_ip -j ACCEPT
	add_iptables -t mangle -I PREROUTING -i lo -p udp -m udp --dport 53 -j TPROXY --on-port 1112 --tproxy-mark 0x1112
	add_iptables -t mangle -I PREROUTING -m owner --uid-owner v2raY -j ACCEPT
	add_iptables -t nat -I OUTPUT -p tcp -j REDIRECT --to 1112
	add_iptables -t nat -I OUTPUT -d $allow_ip -j ACCEPT
	add_iptables -t nat -I OUTPUT -m owner --uid-owner v2raY -j ACCEPT
    ip route add local default dev lo table 1112
    ip rule add fwmark 0x1112 lookup 1112
    su - v2raY -c "nohup $wp/v2raY" >/dev/null 2>&1 &
fi
