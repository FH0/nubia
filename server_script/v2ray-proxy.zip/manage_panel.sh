#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray-proxy"
. $wp/functions.sh

panel(){
	color_status vp_status $wp/v2raY
    var=1
	
    echo
    echo -e "  $((var++)). 开/关${vp_status} v2ray 透明代理${BLANK}"
    echo "  $((var++)). 卸载 v2ray 透明代理"
    echo "  $((var++)). 编辑 v2ray 配置文件"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "$vp_status" = "$GREEN" ];then
                stop_service
            else
                start_service
            fi
            clear && panel
            ;;
        $((var++)) )
			if warning_read;then
				bash $wp/uninstall.sh
				clear && echo " v2ray 透明代理已卸载！"
			else
				clear && panel
			fi
            ;;
        $((var++)) )
            vi +79 $wp/config.json
			start_service
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
