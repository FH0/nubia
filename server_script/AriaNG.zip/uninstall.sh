#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/AriaNG"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/ag

sed -i '/AriaNG_update\.sh/d' /etc/crontab
