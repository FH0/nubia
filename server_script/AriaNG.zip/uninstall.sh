#!/bin/bash
wp="/usr/local/AriaNG"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/ag

sed -i '/AriaNG_update\.sh/d' /etc/crontab
