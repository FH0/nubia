#!/bin/bash
wp="/usr/local/AriaNG"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/ag

crontab -l | sed '/AriaNG_update\.sh/d' | crontab -
