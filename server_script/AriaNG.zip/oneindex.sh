#!/bin/bash
wp="/usr/local/oneindex"

path=$3
downloadpath='/usr/local/AriaNG/Download'
folder=$(sed -n "1p" /usr/local/AriaNG/oneindex.ini)

[ "$2" -eq 0 ] && exit 0

while true;do
    filepath=$path
    path=${path%/*}
    if [ "$path" = "$downloadpath" ] && [ $2 -eq 1 ];then
		$wp/OneDriveUploader -c $wp/auth.json -s "$filepath" -r "$folder" >>$wp/OneDriveUploader.log 2>&1
        rm -f $filepath
        $wp/php $wp/oneindex/one.php cache:refresh
        exit 0
    elif [ "$path" = "$downloadpath" ];then
		$wp/OneDriveUploader -c $wp/auth.json -s "$filepath" -r "$folder" >>$wp/OneDriveUploader.log 2>&1
        rm -rf $filepath
        $wp/php $wp/oneindex/one.php cache:refresh
        exit 0
    fi
done
