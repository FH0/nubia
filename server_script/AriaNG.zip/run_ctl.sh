#!/bin/bash
wp="/usr/local/AriaNG"
. $wp/functions.sh

kill_path $wp/aria2c
$wp/nginx -p /tmp -c $wp/nginx.conf -s stop
bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")

if [ "$1" = "start" ];then
    iptables -I INPUT -p tcp --dport 6800 -m comment --comment "${wp}" -j ACCEPT
    iptables -I INPUT -p tcp --dport $(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*") -m comment --comment "${wp}" -j ACCEPT
    $wp/nginx -p /tmp -c $wp/nginx.conf
    LC_ALL=C nohup $wp/aria2c --conf-path=$wp/aria2.conf >$wp/aria2c.log 2>&1 &
fi
