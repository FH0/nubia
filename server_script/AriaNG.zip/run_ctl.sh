#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/AriaNG"
bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")
pkill -f $wp/nginx
pkill -f $wp/aria2c

if [ "$1" = "start" ];then
    iptables -I INPUT -p tcp --dport 6800 -m comment --comment "${wp}" -j ACCEPT
    iptables -I INPUT -p tcp --dport $(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*") -m comment --comment "${wp}" -j ACCEPT
    su -s /bin/bash nobody -c "$wp/aria2c -D --conf-path=$wp/aria2.conf"
    $wp/nginx -p /tmp -c $wp/nginx.conf
fi
