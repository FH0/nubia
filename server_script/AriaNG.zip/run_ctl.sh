#!/bin/bash
wp="/usr/local/AriaNG"
bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")
$wp/nginx -p /tmp -c $wp/nginx.conf -s stop
pkill -f $wp/aria2c

if [ "$1" = "start" ];then
    iptables -I INPUT -p tcp --dport 6800 -m comment --comment "${wp}" -j ACCEPT
    iptables -I INPUT -p tcp --dport $(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*") -m comment --comment "${wp}" -j ACCEPT
    setsid $wp/aria2c --conf-path=$wp/aria2.conf 2>&- &
    $wp/nginx -p /tmp -c $wp/nginx.conf
fi
