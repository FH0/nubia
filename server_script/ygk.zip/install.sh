#!/bin/bash
wp="/usr/local/ygk"
. $wp/functions.sh

install_ygk() {
    chmod -R 777 $wp

    colorEcho $BLUE "正在安装ygk控制面板..."
    ip_info init
    cp $wp/manage_panel.sh /bin/ygk

    latestVersion=$(curl -s https://github.com/FH0/ygk/releases/latest | sed 's|.*tag/\(.*\)".*|\1|')
    colorEcho $BLUE "正在下载最新核心 $latestVersion ..."
    curl -sL -o $wp/ygk "https://github.com/FH0/ygk/releases/download/$latestVersion/x64"

    colorEcho $BLUE "正在调整内核参数..."
    sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
    echo "net.ipv4.ip_forward = 1" >>/etc/sysctl.conf
    echo 1 >/proc/sys/net/ipv4/ip_forward

    colorEcho $BLUE "正在设置随机端口..."
    random=$(random_port)
    sed -i "s|port.*|port\": $random,|" $wp/ygk.json

    colorEcho $BLUE "正在设置随机密码..."
    random=$(random_password 6)
    sed -i "s|password.*|password\": \"$random\",|" $wp/ygk.json

    colorEcho $BLUE "正在设置日志文件路径..."
    sed -i "s|log_file.*|log_file\": \"$wp/ygk.log\"|" $wp/ygk.json

    colorEcho $BLUE "正在启动ygk..."
    start_service
}

main() {
    install_ygk
    colorEcho $GREEN "ygk安装完成！输入ygk可进入控制面板！"
}

main
