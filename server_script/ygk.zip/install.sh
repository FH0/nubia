#!/bin/bash
wp="/usr/local/ygk"
. $wp/functions.sh

install_ygk() {
    chmod -R 777 $wp

    colorEcho $BLUE "正在安装ygk控制面板..."
    ip_info init
    cp $wp/manage_panel.sh /bin/ygk

    colorEcho $BLUE "正在调整内核参数..."
    sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
    echo "net.ipv4.ip_forward = 1" >>/etc/sysctl.conf
    echo 1 >/proc/sys/net/ipv4/ip_forward

    colorEcho $BLUE "正在设置随机端口..."
    random=$(random_port)
    sed -i "14c\      \"port\": $random," $wp/ygk.json

    colorEcho $BLUE "正在设置随机密码..."
    random=$(random_password 6)
    sed -i "15c\      \"password\": \"$random\"," $wp/ygk.json

    colorEcho $BLUE "正在启动ygk..."
    start_service
}

main() {
    install_ygk
    colorEcho $GREEN "ygk安装完成！输入ygk可进入控制面板！"
}

main
