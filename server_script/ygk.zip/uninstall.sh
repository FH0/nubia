#!/bin/bash
wp="/usr/local/wireguard"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/ygk
