#!/bin/bash
wp="/usr/local/ygk"
. $wp/functions.sh

bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")
bash <(iptables -t nat -S | grep "${wp}" | sed "s|^..|iptables -t nat -D|g")
pgrep -f $wp/ygk | xargs kill

if [ "$1" = "start" ]; then
	address=$(grep "address" $wp/ygk.json | sed -n '1p' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
	cidr=$(grep "netmask" $wp/ygk.json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')

	iptables -t nat -A POSTROUTING -s $address/$cidr ! -d $address/$cidr -m comment --comment "$wp" -j MASQUERADE
	for port in $(grep "port" $wp/ygk.json | grep -Eo "[0-9]*"); do
		iptables -I INPUT -p tcp --dport $port -m comment --comment "${wp}" -j ACCEPT
	done

	echo -n >$wp/ygk.log
	$wp/ygk -c $wp/ygk.json >>$wp/ygk.log 2>&1
fi
