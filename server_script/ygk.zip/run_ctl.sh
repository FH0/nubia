#!/bin/bash
wp="/usr/local/wireguard"
. $wp/functions.sh

bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")
bash <(iptables -t nat -S | grep "${wp}" | sed "s|^..|iptables -t nat -D|g")
pkill -f $wp/ygk

if [ "$1" = "start" ]; then
	iptables -t nat -A POSTROUTING -m comment --comment "$wp" -j MASQUERADE
	iptables -I INPUT -p tcp --dport $(grep "port" $wp/ygk.json | grep -Eo "[0-9]*") -m comment --comment "${wp}" -j ACCEPT

	$wp/ygk -c $wp/ygk.json
fi
