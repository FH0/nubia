#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/tun2socks"
. $wp/functions.sh

pkill -f $wp/v2raY
pkill -f $wp/tun2sockS
ip rule | grep " 1112" | sed 's|.*from|ip rule del from |g' | sh
ip tuntap del mode tun v2tun || tunctl -d v2tun
iptables -S | grep "$wp" | sed "s|^..|iptables -D|g" | sh
iptables -t mangle -S | grep "$wp" | sed "s|^..|iptables -t mangle -D|g" | sh

if [ "$1" = "start" ];then
	add_iptables(){ iptables -t mangle -A OUTPUT -m comment --comment "$wp" $@; }
	add_iptables -o lo -j ACCEPT
	add_iptables -m owner --uid-owner v2raY -j ACCEPT
	add_iptables -p icmp -j ACCEPT
	add_iptables -p udp -m udp --dport 53 -j MARK --set-xmark 0x1112/0xffffffff
	add_iptables -p tcp -m tcp --dport 53 -j MARK --set-xmark 0x1112/0xffffffff
	add_iptables -d 224.0.0.0/3 -j ACCEPT
	add_iptables -d 203.0.113.0/24 -j ACCEPT
	add_iptables -d 198.51.100.0/24 -j ACCEPT
	add_iptables -d 198.18.0.0/15 -j ACCEPT
	add_iptables -d 192.168.0.0/16 -j ACCEPT
	add_iptables -d 192.88.99.0/24 -j ACCEPT
	add_iptables -d 192.0.2.0/24 -j ACCEPT
	add_iptables -d 192.0.0.0/24 -j ACCEPT
	add_iptables -d 172.16.0.0/12 -j ACCEPT
	add_iptables -d 169.254.0.0/16 -j ACCEPT
	add_iptables -d 127.0.0.0/8 -j ACCEPT
	add_iptables -d 100.64.0.0/10 -j ACCEPT
	add_iptables -d 10.0.0.0/8 -j ACCEPT
	add_iptables -d 0.0.0.0/8 -j ACCEPT
	add_iptables -j MARK --set-xmark 0x1112/0xffffffff
    su - v2raY -c "nohup $wp/v2raY" >/dev/null 2>&1 &
    echo 1 > /proc/sys/net/ipv4/ip_forward
    ip tuntap add mode tun v2tun || tunctl -n -t v2tun
    ip addr add 10.0.0.9 dev v2tun
    ip link set v2tun up
    ip route replace default dev v2tun table 1112
	ip rule add pref 11200 from all fwmark 0x1112 lookup 1112
    nohup $wp/tun2sockS --tundev v2tun --netif-ipaddr 10.0.0.10 --netif-netmask 255.255.255.0 --socks-server-addr 127.0.0.1:1112 --enable-udprelay --loglevel 1 >/dev/null 2>&1 &
fi
