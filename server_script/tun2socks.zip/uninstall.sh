#!/bin/bash
wp="/usr/local/tun2socks"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/tv
