#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/dnsmasq"
. $wp/functions.sh

if pgrep -f $wp/dnsmasq;then
	curl -sOL https://hosts.nfz.moe/127.0.0.1/full/hosts
	curl -sL https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/fakenews/hosts >> hosts
	sort -u hosts | sed "s|0.0.0.0|127.0.0.1|g;s|:: |::1 |g" > hosts.bak
	mv hosts.bak $wp/hosts
	start_service
fi
