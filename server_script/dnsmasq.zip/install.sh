#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/dnsmasq"
. $wp/functions.sh

install_dnsmasq(){
    chmod -R 777 $wp
	
    colorEcho $BLUE "正在安装dnsmasq控制面板..."
    cp $wp/manage_panel.sh /bin/dq
    chmod +x /bin/dq
    
    colorEcho $BLUE "正在安装去广告hosts..."
    curl -sOL https://hosts.nfz.moe/127.0.0.1/full/hosts
    curl -sL https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/fakenews/hosts >> hosts
    sort -u hosts | sed "s|0.0.0.0|127.0.0.1|g;s|:: |::1 |g" > hosts.bak
    mv hosts.bak $wp/hosts
    
    colorEcho $BLUE "正在安装hosts自动更新程序..."
    sed -i '/dnsmasq_update\.sh/d' /etc/crontab
    echo "00 03 * * * root $wp/dnsmasq_update.sh" >> /etc/crontab
    
    colorEcho $BLUE "正在启动dnsmasq..."
	start_service

    grep -q "^dnsmasq" /etc/passwd || useradd dnsmasq
}

main(){
    install_dnsmasq
    colorEcho $GREEN "dnsmasq安装完成！输入dq可进入控制面板！"
}

main
