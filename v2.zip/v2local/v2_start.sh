{
    #输入放行应用UID
    app_direct="10122 10069"
    #wifi代理开关[on/off]
    wifi_proxy=off
    #破版权[on/off]
    break_copyright=off
}




cd ${0%/*} && ./v2_stop.sh S && address=`cat config.json|grep address|grep ","|awk '{print $2}'|awk -F "\"" '{print $2}'`

iptables -t nat -N own;iptables -t nat -A own -p tcp -m owner --uid-owner 0 -j ACCEPT;iptables -t nat -A own -o lo -j ACCEPT;iptables -t nat -A own -p tcp -j REDIRECT --to 12345;iptables -t nat -I OUTPUT 1 -p tcp -j own;iptables -t nat -N hot;iptables -t nat -A hot -p tcp -j REDIRECT --to-ports 12345;iptables -t nat -A PREROUTING -p tcp -j hot;ip rule add fwmark 1 table 121;ip route add local 0.0.0.0/0 dev lo table 121;iptables -t mangle -N ownout;iptables -t mangle -A ownout -d 192.168.0.0/16 -j ACCEPT;iptables -t mangle -A ownout -p udp -j MARK --set-xmark 0x1;iptables -t mangle -I OUTPUT 1 -p udp -j ownout;iptables -t mangle -N hotpre;iptables -t mangle -A hotpre -d 0.0.0.0/8 -j ACCEPT;iptables -t mangle -A hotpre -d 10.0.0.0/8 -j ACCEPT;iptables -t mangle -A hotpre -d 127.0.0.0/8 -j ACCEPT;iptables -t mangle -A hotpre -d 169.254.0.0/16 -j ACCEPT;iptables -t mangle -A hotpre -d 172.16.0.0/12 -j ACCEPT;iptables -t mangle -A hotpre -d 192.168.0.0/16 -j ACCEPT;iptables -t mangle -A hotpre -d 224.0.0.0/4 -j ACCEPT;iptables -t mangle -A hotpre -d 240.0.0.0/4 -j ACCEPT;iptables -t mangle -A hotpre -p udp -j TPROXY --on-port 12345 --tproxy-mark 1;iptables -t mangle -I PREROUTING 1 -p udp -j hotpre

if [ "$wifi_proxy" = "off" ];then iptables -t nat -I own 1 -o wlan+ -j ACCEPT;iptables -t mangle -I ownout 1 -o wlan+ -j ACCEPT;fi
if [ "$app_direct" != "" ];then for F in $app_direct;do iptables -t nat -I own 1 -m owner --uid-owner $F -j ACCEPT;iptables -t mangle -I ownout 1 -m owner --uid-owner $F -j ACCEPT;iptables -t nat -I hot 1 -m owner --uid-owner $F -j ACCEPT;done;fi
if [ "$break_copyright" = "off" ];then sed -i 's#"outboundTag"\: ".*"#"outboundTag"\: "proxy"#g' config.json;else sed -i 's#"outboundTag"\: ".*"#"outboundTag"\: "direct"#g' config.json;fi

#./v2ctl config < config.json > config.pb && chmod 0777 config.pb
#su - 3004 -c "./v2ray -config=config.pb -format=pb" > /dev/null 2>&1 &
./v2ray -config=config.json > /dev/null 2>&1 &
sleep 0.15 && ./v2_check.sh
