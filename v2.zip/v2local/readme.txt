
1.

2.ip，端口，UUID，混淆仅需填在config.json

‌3.部分配置在v2_start.sh里面

4.服务器搭建脚本(不支持centos，请选择deb系)（默认开启80 8080端口且不能更改）:
apt-get install wget unzip -y;cd /root;wget --no-check-certificate https://github.com/FH0/nubia/raw/master/ssr_jzdh.zip;unzip -o ssr_jzdh.zip;bash ~/SSR-Bash-Python/jzdh.sh

5.安装过程中如果提示not found，请执行apt-get update -y

6.版权域名来自千影博客，v2ray&v2ctl来自https://www.v2ray.com，在此注明
