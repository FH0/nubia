address=47.240.1.77:1110
password=carzoo
http_header="GET / HTTP/1.1\r\nHost: qq.com\r\n\r\n"
tcp_timeout=300000
udp_timeout=60000
log_level=info
log_file_max=256

dns="8.8.8.8:53 1.1.1.1:53 208.67.222.222:53"
china_dns="system 223.5.5.5:53 114.114.114.114:53 221.7.128.69:53 119.29.29.29:53"
hot_proxy=off
app_direct=""
app_proxy="mark.via org.telegram.messenger com.google.android.apps.translate com.google.android.ims com.google.android.setupwizard android com.google.ar.core com.google.android.gms com.google.android.soundpicker pl.zdunex25.updater com.google.android.googlequicksearchbox com.google.ar.lens com.google.android.printservice.recommendation com.termux com.google.android.apps.restore com.google.android.apps.cloudprint com.google.android.syncadapters.calendar com.google.android.partnersetup com.google.android.tts com.android.providers.downloads com.android.vending com.android.chrome com.android.providers.downloads.ui com.google.android.syncadapters.contacts com.topjohnwu.magisk com.google.android.inputmethod.latin com.android.settings com.google.android.youtube com.google.android.feedback com.google.android.configupdater com.google.android.gsf"
wifi_proxy=on
auto_start=on
ipv6=disable

#================================================================
#
#    address 服务器的地址
#    password 服务器的密码
#    http_header 自定义的 HTTP 请求头
#    log_level 日志级别，可选debug info warning error fatal，留空则为fatal
#
#    当china_dns不为空时只代理国外流量，china_dns填入国内的DNS，dns填入国外的DNS
#    hot_proxy是热点代理开关，可选on off
#    app_proxy是代理应用，未选中的应用会被放行，此项不为空时app_direct失效，可选[应用包名] [应用uid]，多个应用之间用空格隔开
#    app_direct是放行应用，未被放行的应用会被代理，可选[应用包名] [应用uid]，多个应用之间用空格隔开
#    wifi_proxy是WiFi代理开关，可选on off
#    auto_start是利用magisk开机自启的开关，可选on off，magisk版本不能低于19
#    ipv6 是 ipv6 流量控制，direct 不代理，disable 禁用（可尝试开关飞行模式恢复 ipv6），proxy 代理（默认选项）
#
#    {常用应用的包名}
#    淘宝           com.taobao.taobao
#    支付宝         com.eg.android.AlipayGphone
#    王者荣耀       com.tencent.tmgp.sgame
#    和平精英       com.tencent.tmgp.pubgmhd
#    联通营业厅     com.sinovatech.unicom.ui
#    作业帮         com.baidu.homework
#    Tim            com.tencent.tim
#    ADM            com.dv.adm.pay
#    酷安           com.coolapk.market
#    电信营业厅     com.ct.client
#    京东           com.jingdong.app.mall
#    网易云音乐     com.netease.cloudmusic
#    JuiceSSH       com.sonelli.juicessh
#    微信           com.tencent.mm
#    腾讯视频       com.tencent.qqlive
#    微信读书       com.tencent.weread
#    转转           com.wuba.zhuanzhuan
#    闲鱼           com.taobao.idlefish
#    讯飞输入法     com.iflytek.inputmethod
#    哔哩哔哩       tv.danmaku.bili
#    YY             com.duowan.mobile
#    QQ音乐         com.tencent.qqmusic
#    Network Tools  net.he.networktools
#    阿里云         com.alibaba.aliyun
#    WPS            cn.wps.moffice_eng
#    网络信号大师   com.qtrun.QuickTest
#    Z直播          com.linroid.zlive
#    决战！平安京   com.netease.moba
#    翼支付         com.chinatelecom.bestpayclient
#    To-Do          com.microsoft.todos
#    微软桌面       com.microsoft.launcher
#    Via            mark.via.gp
#    Via            mark.via
#    火狐浏览器       org.mozilla.firefox
#
#    搭建脚本: curl -L https://raw.githubusercontent.com/FH0/nubia/master/Backstage.sh | bash
#
#===============================================================

wp=$(dirname $(readlink -f $0))

# 使用 busybox 提供的所有命令
shopt -s expand_aliases >/dev/null 2>&1
for cmd in $($wp/bin/busybox --list); do
    alias $cmd="$wp/bin/busybox $cmd"
done
alias iptables="/system/bin/iptables -w" # 重新定义 iptables，解决调用锁
alias ip6tables="/system/bin/ip6tables -w" # 重新定义 iptables，解决调用锁

cmd=start . $wp/bin/functions.sh
