#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/ssr_jzdh"

systemctl stop ssr.service
systemctl disable ssr.service >/dev/null 2>&1
rm -f /etc/systemd/system/ssr.service
systemctl daemon-reload ; systemctl reset-failed

rm -rf $wp
rm -f /bin/ssr