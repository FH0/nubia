#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/ssr_jzdh"

if command -v systemctl >/dev/null;then
	systemctl disable ssr.service
	rm -f /etc/systemd/system/ssr.service
	systemctl daemon-reload ; systemctl reset-failed
elif [ -e "/etc/rc.local" ];then
	tmp_echo=$(grep -v "$wp/systemctl_ctl.sh" /etc/rc.local)
	echo "$tmp_echo" > /etc/rc.local
fi >/dev/null 2>&1

rm -rf $wp
rm -f /bin/ssr
