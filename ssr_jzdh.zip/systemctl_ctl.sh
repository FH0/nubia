#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/ssr_jzdh"

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
python_ver=$(ls /usr/bin|grep -e "^python[23]\.[1-9]\+$"|tail -1)

if [ "$1" = "stop" ];then
    setcap cap_net_bind_service=-ep /usr/bin/${python_ver}
    kill -9 $(ps -ef | grep "${python_ver} server\\.py m" | grep -v "grep" | awk '{print $2}')
else
    for dport in $(cd $wp/shadowsocksr && python mujson_mgr.py -l | awk '{print $4}');do
        iptables -I INPUT -p tcp --dport $dport -m string ! --string "$wp" --algo bm -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m string ! --string "$wp" --algo bm -j ACCEPT
    done
    eval $(ps -ef | grep "[0-9] ${python_ver} server\\.py m" | awk '{print "kill "$2}')
    ulimit -n 512000
    cd $wp/shadowsocksr
    setcap cap_net_bind_service=+ep /usr/bin/${python_ver}
    su -s /bin/bash nobody -c "${python_ver} server.py m"
fi
