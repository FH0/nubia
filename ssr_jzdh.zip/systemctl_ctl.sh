#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/ssr_jzdh"

bash <(iptables -S | grep "$wp" | sed "s|-[AI] |-D |g;s|^|iptables |g")

if [ "$1" = "stop" ];then
    kill -9 $(ps -ef | grep "$wp" | sed -n "1p" | awk '{print $2}')
else
    for dport in $(cd $wp/shadowsocksr && python mujson_mgr.py -l | awk '{print $4}');do
        iptables -I INPUT -p tcp --dport $dport -m string ! --string "$wp" --algo bm -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m string ! --string "$wp" --algo bm -j ACCEPT
    done
    $wp/shadowsocksr/run.sh
fi
