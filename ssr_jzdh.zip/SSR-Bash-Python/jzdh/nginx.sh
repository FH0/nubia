#!/bin/bash
if [ -f /etc/redhat-release ];then
yum -y install gcc gcc-c++ make libtool zlib zlib-devel openssl openssl-devel pcre pcre-devel tar
wget http://nginx.org/download/nginx-1.10.1.tar.gz;tar -zxvf nginx-1.10.1.tar.gz;cd nginx-1.10.1
./configure --prefix=/usr/local/webserver/nginx --with-http_stub_status_module --with-http_ssl_module --with-pcre
make && make install;mkdir /accept;cp /usr/local/webserver/nginx/conf/nginx.conf /usr/local/webserver/nginx/conf/nginx.conf.bak
echo 'worker_processes  1;
events {
worker_connections  1024;
}
http {
include       mime.types;
default_type  application/octet-stream;
sendfile        on;
keepalive_timeout  65;
server {
listen       8082;        
server_name  localhost;   
root    /accept;  
autoindex on;             
autoindex_exact_size off;
}
}' > /usr/local/webserver/nginx/conf/nginx.conf
/usr/local/webserver/nginx/sbin/nginx
echo '[Unit]
Description=nginx
After=network.target
[Service]
Type=forking
ExecStart=/usr/local/webserver/nginx/sbin/nginx -c /usr/local/webserver/nginx/conf/nginx.conf
ExecReload=/usr/local/webserver/nginx/sbin/nginx -s reload
ExecStop=/usr/local/webserver/nginx/sbin/nginx -s quit
PrivateTmp=true
[Install]
WantedBy=multi-user.target' > /lib/systemd/system/nginx.service
systemctl start nginx.service;systemctl enable nginx.service


else
apt-get update -y;apt-get install nginx -y;mkdir /accept;cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak
echo 'worker_processes  1;
events {
worker_connections  1024;
}
http {
include       mime.types;
default_type  application/octet-stream;
sendfile        on;
keepalive_timeout  65;
server {
listen       8082;        
server_name  localhost;   
root    /accept;  
autoindex on;             
autoindex_exact_size off;
}
}' > /etc/nginx/nginx.conf
/etc/init.d/nginx start;/etc/init.d/nginx restart
fi
