#!/bin/bash

function check {
	if [ -f /etc/redhat-release ];then
		OS='CentOS' && yum install net-tools -y && boot && kernel
	elif [ ! -z "`cat /etc/issue | grep bian`" ];then
		OS='Debian' && boot && kernel && network && grub
	else
		echo "Not support OS, Please reinstall OS and retry!"
		exit 1
	fi
}

function boot {
	if [ -f /etc/redhat-release ];then
		cat > /etc/rc.d/init.d/sser << eof
wget -N --no-check-certificate https://github.com/91yun/serverspeeder/raw/master/serverspeeder-v.sh && bash serverspeeder-v.sh CentOS 7.2 3.10.0-327.el7.x86_64 x64 3.11.20.5 serverspeeder_72327
rm -f serverspeeder-v.sh
sed -i "/sser/d" /etc/rc.d/rc.local
rm -f "/etc/rc.d/init.d/sser"
eof
chmod +x  /etc/rc.d/init.d/sser
echo "/etc/rc.d/init.d/sser" >> /etc/rc.d/rc.local
chmod +x /etc/rc.d/rc.local


else
	cat <<EOF >/etc/rc.local
#!/bin/sh -e
#
# rc.local
#
# This script is executed at the end of each multiuser runlevel.
# Make sure that the script will "exit 0" on success or any other
# value on error.
#
# In order to enable or disable this script just change the execution
# bits.
#
# By default this script does nothing.
wget -N --no-check-certificate https://github.com/91yun/serverspeeder/raw/master/serverspeeder-v.sh && bash serverspeeder-v.sh Debian 8 3.16.0-4-amd64 x64 3.10.61.0 serverspeeder_31604 && rm -f serverspeeder-v.sh && sed -i "/91yun/d" /etc/rc.local
exit 0
EOF
chmod +x /etc/rc.local
systemctl start rc-local
fi
}

function kernel {
	if [[ ${OS} == Debian ]];then
		wget http://ftp.us.debian.org/debian/pool/main/l/linux/linux-image-3.16.0-4-amd64_3.16.51-3_amd64.deb
		dpkg -i linux-image-3.16.0-4-amd64_3.16.51-3_amd64.deb
		rm -f linux-image-3.16.0-4-amd64_3.16.51-3_amd64.deb
	else
		rpm -ivh https://buildlogs.cdn.centos.org/c7.1511.00/kernel/20151119220809/3.10.0-327.el7.x86_64/kernel-3.10.0-327.el7.x86_64.rpm --force
	fi
}

function network {
	echo 'auto lo     
	iface lo inet loopback

	auto eth0                          
	iface eth0 inet dhcp' > /etc/network/interfaces
}

function grub {
	if [[ ${OS} == Debian ]];then
		sed -i "s:^GRUB_DEFAULT=.*:GRUB_DEFAULT=\"Advanced options for Debian GNU/Linux>Debian GNU/Linux, with Linux 3.16.0-4-amd64\":g" /etc/default/grub
		sed -i "s:^GRUB_CMDLINE_LINUX=.*:GRUB_CMDLINE_LINUX=\"net.ifnames=0 biosdevname=0\":g" /etc/default/grub
		update-grub
	else
		echo
	fi
}

check
