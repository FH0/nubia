#!/bin/bash

function check {
	if [ -f /etc/redhat-release ];then
		OS='CentOS' && yum install net-tools -y
	elif [ ! -z "`cat /etc/issue | grep bian`" ];then
		OS='Debian' && apt-get install net-tools -y
	elif [ ! -z "`cat /etc/issue | grep Ubuntu`" ];then
		OS='Ubuntu' && apt-get install net-tools -y
	else
		echo "The OS is not supporting!"
		exit 1
	fi
}

function kernel {
	if [[ ${OS} == Debian ]];then
		wget --no-check-certificate -O 3.16.deb http://ftp.debian.org/debian/pool/main/l/linux/linux-image-3.16.0-4-amd64_3.16.51-3_amd64.deb
		dpkg -i 3.16.deb && update-grub && rm -f 3.16.deb
	elif [[ ${OS} == Ubuntu ]];then
		wget --no-check-certificate -O 3.16.deb http://security.ubuntu.com/ubuntu/pool/main/l/linux-lts-utopic/linux-image-3.16.0-43-generic_3.16.0-43.58~14.04.1_amd64.deb
		dpkg -i 3.16.deb && update-grub && rm -f 3.16.deb
	elif [[ ${OS} == CentOS ]];then
		rpm -ivh https://buildlogs.cdn.centos.org/c7.1511.00/kernel/20151119220809/3.10.0-327.el7.x86_64/kernel-3.10.0-327.el7.x86_64.rpm --force
	fi
}

function boot {
	if [[ ${OS} == CentOS ]];then
		cat > /etc/rc.d/init.d/s_rs << EOF
			wget --no-check-certificate -P /root https://github.com/91yun/serverspeeder/raw/master/serverspeeder-v.sh
			bash /root/serverspeeder-v.sh CentOS 7.2 3.10.0-327.el7.x86_64 x64 3.11.20.5 serverspeeder_72327
			rm -f serverspeeder-v.sh
			sed -i "/s_rs/d" /etc/rc.d/rc.local
			rm -f "/etc/rc.d/init.d/s_rs"
			EOF
			chmod +x  /etc/rc.d/init.d/s_rs
			echo "/etc/rc.d/init.d/s_rs" >> /etc/rc.d/rc.local
			chmod +x /etc/rc.d/rc.local
		elif [[ ${OS} == Debian ]];then
			cat > /etc/init.d/s_rs <<EOF
#!/bin/sh
### BEGIN INIT INFO
# Provides:          s_rs
# Required-Start: $local_fs $remote_fs
# Required-Stop: $local_fs $remote_fs
# Should-Start: $network
# Should-Stop: $network
# Default-Start:        2 3 4 5
# Default-Stop:         0 1 6
# Short-Description: s_rs
# Description: s_rs
### END INIT INFO
			wget --no-check-certificate https://raw.githubusercontent.com/91yun/serverspeeder/master/serverspeeder-all.sh
			bash serverspeeder-all.sh > /dev/null 2>&1 &
			wait && rm -f serverspeeder-all.sh
			cd /etc/init.d
			update-rc.d -f s_rs remove
			rm -f /etc/init.d/s_rs
			EOF
			chmod 777 /etc/init.d/s_rs
			cd /etc/init.d
			update-rc.d s_rs defaults 95
		elif  [[ ${OS} == Ubuntu ]];then
			cat > /etc/init.d/s_rs <<EOF
#!/bin/sh
### BEGIN INIT INFO
# Provides:          s_rs
# Required-Start: $local_fs $remote_fs
# Required-Stop: $local_fs $remote_fs
# Should-Start: $network
# Should-Stop: $network
# Default-Start:        2 3 4 5
# Default-Stop:         0 1 6
# Short-Description: s_rs
# Description: s_rs
### END INIT INFO
			wget -N --no-check-certificate https://github.com/91yun/serverspeeder/raw/master/serverspeeder-v.sh
			bash serverspeeder-v.sh Ubuntu 14.04 _3.16.0-43-generic x64 3.11.20.4 serverspeeder_3275
			rm -f serverspeeder-v.sh
			cd /etc/init.d
			update-rc.d -f s_rs remove
			rm -f /etc/init.d/s_rs
			EOF
			chmod 777 /etc/init.d/s_rs
			cd /etc/init.d
			update-rc.d s_rs defaults 95
		fi
	}

function grub {
	if [[ ${OS} == Debian ]];then
		chmod 777 /boot/grub/grub.cfg
			sed -i "s:	initrd.*:	initrd /boot/initrd.img-3.16.0-4-amd64:g" /boot/grub/grub.cfg
			sed -i "s:	linux.* root:	linux /boot/vmlinuz-3.16.0-4-amd64 root:g" /boot/grub/grub.cfg
		elif [[ ${OS} == Ubuntu ]];then
			chmod 777 /boot/grub/grub.cfg
			sed -i "s:	initrd.*:	initrd /boot/initrd.img-3.16.0-43-generic:g" /boot/grub/grub.cfg
			sed -i "s:	linux.* root:	linux /boot/vmlinuz-3.16.0-43-generic root:g" /boot/grub/grub.cfg
		fi
	}

check && kernel && boot && grub
