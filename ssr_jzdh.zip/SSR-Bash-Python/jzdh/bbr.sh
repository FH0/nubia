#!/bin/bash
OS=`bash /root/SSR-Bash-Python/jzdh/check_os.sh`
clear;echo;echo ' bbr我只在CentOS7,Debian8和Ubuntu14.04上测试过,其他的系统建议你现在关掉终端,按回车继续';read

if [[ ${OS} == CentOS ]];then
rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
rpm -Uvh http://www.elrepo.org/elrepo-release-7.0-2.el7.elrepo.noarch.rpm
yum --enablerepo=elrepo-kernel install kernel-ml -y
grub2-set-default 0
cat > /etc/rc.d/init.d/s_bbr << eof
sed -i /net.core.default_qdisc/d /etc/sysctl.conf
sed -i /net.ipv4.tcp_congestion_control/d /etc/sysctl.conf
echo 'net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr' >> /etc/sysctl.conf
sysctl -p
sed -i /s_bbr/d /etc/rc.d/rc.local
rm -f /etc/rc.d/init.d/s_bbr
eof
chmod +x  /etc/rc.d/init.d/s_bbr
echo "/etc/rc.d/init.d/s_bbr" >> /etc/rc.d/rc.local
chmod +x /etc/rc.d/rc.local
fi

if [[ ${OS} == Debian ]];then
echo
fi

if [[ ${OS} == Ubuntu ]];then
echo
fi
