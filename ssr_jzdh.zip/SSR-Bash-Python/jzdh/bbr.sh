#!/bin/bash
OS=`bash /root/SSR-Bash-Python/jzdh/check_os.sh`
if [[ ${OS} == CentOS ]];then
rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
rpm -Uvh http://www.elrepo.org/elrepo-release-7.0-2.el7.elrepo.noarch.rpm
yum --enablerepo=elrepo-kernel install kernel-ml -y
grub2-set-default 0
cat > /etc/rc.d/init.d/s_bbr << eof
sed -i /net.core.default_qdisc/d /etc/sysctl.conf
sed -i /net.ipv4.tcp_congestion_control/d /etc/sysctl.conf
echo 'net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr' >> /etc/sysctl.conf
sysctl -p
sed -i /s_bbr/d /etc/rc.d/rc.local
rm -f /etc/rc.d/init.d/s_bbr
eof
chmod +x  /etc/rc.d/init.d/s_bbr
echo "/etc/rc.d/init.d/s_bbr" >> /etc/rc.d/rc.local
chmod +x /etc/rc.d/rc.local
fi

if [[ ${OS} == Debian ]];then
wget http://kernel.ubuntu.com/~kernel-ppa/mainline/v4.9.6/linux-image-4.9.6-040906-generic_4.9.6-040906.201701260330_amd64.deb
dpkg -i linux-image-4.9.6-040906-generic_4.9.6-040906.201701260330_amd64.deb
update-grub
cat >/etc/init.d/s_bbr <<EOF
#!/bin/sh
### BEGIN INIT INFO
# Provides:          s_bbr
# Required-Start: $local_fs $remote_fs
# Required-Stop: $local_fs $remote_fs
# Should-Start: $network
# Should-Stop: $network
# Default-Start:        2 3 4 5
# Default-Stop:         0 1 6
# Short-Description: s_bbr
# Description: s_bbr
### END INIT INFO
sed -i /net.core.default_qdisc/d /etc/sysctl.conf
sed -i /net.ipv4.tcp_congestion_control/d /etc/sysctl.conf
echo 'net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr' >> /etc/sysctl.conf
sysctl -p
cd /etc/init.d
update-rc.d -f s_bbr remove
rm -f /etc/init.d/s_bbr
EOF
chmod 777 /etc/init.d/s_bbr
cd /etc/init.d
update-rc.d s_bbr defaults 95
fi

if [[ ${OS} == Ubuntu ]];then
wget http://kernel.ubuntu.com/~kernel-ppa/mainline/v4.9.6/linux-image-4.9.6-040906-generic_4.9.6-040906.201701260330_amd64.deb
dpkg -i linux-image-4.9.6-040906-generic_4.9.6-040906.201701260330_amd64.deb
update-grub
cat >/etc/init.d/s_bbr <<EOF
#!/bin/sh
### BEGIN INIT INFO
# Provides:          s_bbr
# Required-Start: $local_fs $remote_fs
# Required-Stop: $local_fs $remote_fs
# Should-Start: $network
# Should-Stop: $network
# Default-Start:        2 3 4 5
# Default-Stop:         0 1 6
# Short-Description: s_bbr
# Description: s_bbr
### END INIT INFO
sed -i /net.core.default_qdisc/d /etc/sysctl.conf
sed -i /net.ipv4.tcp_congestion_control/d /etc/sysctl.conf
echo 'net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr' >> /etc/sysctl.conf
sysctl -p
cd /etc/init.d
update-rc.d -f s_bbr remove
rm -f /etc/init.d/s_bbr
EOF
chmod 777 /etc/init.d/s_bbr
cd /etc/init.d
update-rc.d s_bbr defaults 95
fi
