#!/bin/bash
#安装官方最新版v2ray
yum install wget unzip -y > /dev/null 2>&1 || apt-get install wget unzip -y > /dev/null 2>&1
wget --no-check-certificate https://raw.githubusercontent.com/v2ray/v2ray-core/master/release/install-release.sh
bash install-release.sh

#配置v2ray
id=`cat /etc/v2ray/config.json|grep '"id"'|sed 's:.*"id"\(.*\):\1:g'|sed "s:.*\"\(.*\)\".*:\1:g"`
echo '{
  "log" : {
    "access": "/dev/null",
    "error": "/dev/null",
    "loglevel": "warning"
  },
  "inbound": {
    "port": 80, 
    "protocol": "vmess",
    "settings": {
      "clients": [
        {
          "id": "yourid",
          "level": 1,
          "alterId": 64
        }
      ]
    },
    "streamSettings": {
      "network": "tcp",
      "tcpSettings": {
        "header": { 
          "type": "http",
          "response": {
            "version": "1.1",
            "status": "200",
            "reason": "OK",
            "headers": {
              "Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],
              "Transfer-Encoding": ["chunked"],
              "Connection": ["keep-alive"],
              "Pragma": "no-cache"
            }
          }
        }
      }
    }
  },
    "inbound": {
    "port": 8080, 
    "protocol": "vmess",
    "settings": {
      "clients": [
        {
          "id": "yourid",
          "level": 1,
          "alterId": 64
        }
      ]
    },
    "streamSettings": {
      "network": "tcp",
      "tcpSettings": {
        "header": { 
          "type": "http",
          "response": {
            "version": "1.1",
            "status": "200",
            "reason": "OK",
            "headers": {
              "Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],
              "Transfer-Encoding": ["chunked"],
              "Connection": ["keep-alive"],
              "Pragma": "no-cache"
            }
          }
        }
      }
    }
  },
    "inbound": {
    "port": 53, 
    "protocol": "vmess",
    "settings": {
      "clients": [
        {
          "id": "yourid",
          "level": 1,
          "alterId": 64
        }
      ]
    },
    "streamSettings": {
      "network": "tcp",
      "tcpSettings": {
        "header": { 
          "type": "http",
          "response": {
            "version": "1.1",
            "status": "200",
            "reason": "OK",
            "headers": {
              "Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],
              "Transfer-Encoding": ["chunked"],
              "Connection": ["keep-alive"],
              "Pragma": "no-cache"
            }
          }
        }
      }
    }
  },
  "outbound": {
    "protocol": "freedom",
    "settings": {}
  }
}' > /etc/v2ray/config.json
sed -i "s:yourid:${id}:g" /etc/v2ray/config.json
systemctl restart v2ray
