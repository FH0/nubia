#!/bin/bash
#安装官方最新版v2ray
systemctl stop v2ray&&rm -rf /etc/v2ray&&rm -rf /usr/bin/v2ray
yum install wget unzip -y > /dev/null 2>&1 || apt-get install wget unzip -y > /dev/null 2>&1
wget --no-check-certificate https://raw.githubusercontent.com/v2ray/v2ray-core/master/release/install-release.sh
bash install-release.sh && rm -f install-release.sh

#配置v2ray
echo '{
"log": {
"access": "/dev/null",
"error": "/dev/null",
"loglevel": "warning"
	},
	"inbound": {
	"port": 80,
	"protocol": "vmess",
	"settings": {
	"clients": [
	{
		"id": "f80a70a1-9d36-18f9-56a8-79e4d6fc8019",
		"level": 1,
		"alterId": 32
	}
	]
},
"streamSettings": {
"network": "tcp",
"tcpSettings": {
"header": { 
"type": "http",
"response": {
"version": "1.1",
"status": "200",
"reason": "OK",
"headers": {
"Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],
"Transfer-Encoding": ["chunked"],
"Connection": ["keep-alive"],
"Pragma": "no-cache"
						}
					}
				}
			}
		}
	},
	"outbound": {
	"protocol": "freedom",
	"settings": {}
},
"inboundDetour": [
{
	"port": 8080,
	"protocol": "vmess",
	"settings": {
	"clients": [
	{
		"id": "f80a70a1-9d36-18f9-56a8-79e4d6fc8019",
		"level": 1,
		"alterId": 32
	}
	]
},
"streamSettings": {
"network": "tcp",
"tcpSettings": {
"header": { 
"type": "http",
"response": {
"version": "1.1",
"status": "200",
"reason": "OK",
"headers": {
"Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],
"Transfer-Encoding": ["chunked"],
"Connection": ["keep-alive"],
"Pragma": "no-cache"
							}
						}
					}
				}
			}
		},
		{
			"port": 53,
			"protocol": "vmess",
			"settings": {
			"clients": [
			{
				"id": "f80a70a1-9d36-18f9-56a8-79e4d6fc8019",
				"level": 1,
				"alterId": 32
			}
			]
		},
		"streamSettings": {
		"network": "tcp",
		"tcpSettings": {
		"header": { 
		"type": "http",
		"response": {
		"version": "1.1",
		"status": "200",
		"reason": "OK",
		"headers": {
		"Content-Type": ["application/octet-stream", "application/x-msdownload", "text/html", "application/x-shockwave-flash"],
		"Transfer-Encoding": ["chunked"],
		"Connection": ["keep-alive"],
		"Pragma": "no-cache"
	}
}
					}
				}
			}
		}
		]
	}' > /etc/v2ray/config.json

#启动v2ray
systemctl start v2ray

#友情提示
clear;echo ' 默认打开80 8080 53端口'
echo ' uuid为 f80a70a1-9d36-18f9-56a8-79e4d6fc8019 '
echo ' uuid就是密码，更改请到控制面板,输入v2即可进入'

#生成控制面板
echo '#!/bin/bash
clear;echo " 1.更改所有端口的uuid"
echo " 2.添加端口(暂时不可用)"
echo " 3.删除端口(暂时不可用)"
echo " 4.查看端口情况"
echo 
read -p "请选择: " choice

if [[ $choice == 1 ]];then
echo;read -p "输入uuid: " uuid;if [ -z $uuid ];then exit 0;else
sed -i "s:id\"\:.*:id\"\: \"${uuid}\",:g" /etc/v2ray/config.json
systemctl restart v2ray && echo "uuid已更改,v2ray已重启，输入systemctl status v2ray查看状态"
fi;fi

if [[ $choice == 2 ]];then
echo "后续开发，不要急"
fi

if [[ $choice == 3 ]];then
echo "后续开发，不要急"
fi

if [[ $choice == 4 ]];then
clear;echo ' 已开端口:'
grep "port" /etc/v2ray/config.json|sed "s/.*port\": \(.*\),/ \1/g"
echo "uuid:"
grep "id" /etc/v2ray/config.json|sed "s:.*id\"\: \"\(.*\)\",: \1:g"|sed "s:^[ \t]*::g"|sort -u
fi' > /bin/v2
chmod +x /bin/v2
