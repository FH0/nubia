#!/bin/bash

github=raw.githubusercontent.com/chiakge/Linux-NetSpeed/master

installlot(){
	if [[ "${release}" == "centos" ]]; then
		rpm --import http://${github}/lotserver/${release}/RPM-GPG-KEY-elrepo.org
		yum remove -y kernel-firmware
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-firmware-${kernel_version}.rpm
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-${kernel_version}.rpm
		yum remove -y kernel-headers
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-headers-${kernel_version}.rpm
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-devel-${kernel_version}.rpm
	elif [[ "${release}" == "ubuntu" ]]; then
		mkdir bbr && cd bbr
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-headers-${kernel_version}-all.deb
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-headers-${kernel_version}.deb
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-image-${kernel_version}.deb
	
		dpkg -i linux-headers-${kernel_version}-all.deb
		dpkg -i linux-headers-${kernel_version}.deb
		dpkg -i linux-image-${kernel_version}.deb
		cd .. && rm -rf bbr
	elif [[ "${release}" == "debian" ]]; then
		mkdir bbr && cd bbr
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-image-${kernel_version}.deb
	
		dpkg -i linux-image-${kernel_version}.deb
		cd .. && rm -rf bbr
	fi
}

check_sys_Lotsever(){
	check_version
	kbb=`uname -r`
	if [[ "${release}" == "centos" ]]; then
		if [[ ${version} == "6" ]]; then
			kernel_version="2.6.32-504"
			installlot
		elif [[ ${version} == "7" ]]; then
			yum -y install net-tools
			kernel_version="3.10.0-327"
			installlot
		else
			echo -e " Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
		fi
	elif [[ "${release}" == "debian" ]]; then
		if [[ ${version} -ge "7" ]]; then
			if [[ ${bit} == "x64" ]]; then
				kernel_version="3.16.0-4"
				installlot
				chmod 777 /boot/grub/grub.cfg;sed -i "s/vmlinuz-${kbb}/vmlinuz-3.16.0-4-amd64/g" /boot/grub/grub.cfg
				sed -i "s/initrd.img-${kbb}/initrd.img-3.16.0-4-amd64/g" /boot/grub/grub.cfg
			elif [[ ${bit} == "x32" ]]; then
				kernel_version="3.2.0-4"
				installlot
		 	chmod 777 /boot/grub/grub.cfg;sed -i "s/vmlinuz-${kbb}/vmlinuz-3.2.0-4-amd64/g" /boot/grub/grub.cfg
				sed -i "s/initrd.img-${kbb}/initrd.img-3.2.0-4-amd64/g" /boot/grub/grub.cfg
			fi
		else
			echo -e " Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
		fi
	elif [[ "${release}" == "ubuntu" ]]; then
		if [[ ${version} -ge "12" ]]; then
			if [[ ${bit} == "x64" ]]; then
				kernel_version="4.4.0-47"
				installlot
				chmod 777 /boot/grub/grub.cfg;sed -i "s/vmlinuz-${kbb}/vmlinuz-4.4.0-47-amd64/g" /boot/grub/grub.cfg
				sed -i "s/initrd.img-${kbb}/initrd.img-4.4.0-47-amd64/g" /boot/grub/grub.cfg
			elif [[ ${bit} == "x32" ]]; then
				kernel_version="3.13.0-29"
				installlot
				chmod 777 /boot/grub/grub.cfg;sed -i "s/vmlinuz-${kbb}/vmlinuz-3.13.0-29-amd64/g" /boot/grub/grub.cfg
				sed -i "s/initrd.img-${kbb}/initrd.img-3.13.0-29-amd64/g" /boot/grub/grub.cfg
			fi
		else
			echo -e " Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
		fi
	else
		echo -e " Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
	fi
}

check_sys(){
	if [[ -f /etc/redhat-release ]]; then
		release="centos"
	elif cat /etc/issue | grep -q -E -i "debian"; then
		release="debian"
	elif cat /etc/issue | grep -q -E -i "ubuntu"; then
		release="ubuntu"
	elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat"; then
		release="centos"
	elif cat /proc/version | grep -q -E -i "debian"; then
		release="debian"
	elif cat /proc/version | grep -q -E -i "ubuntu"; then
		release="ubuntu"
	elif cat /proc/version | grep -q -E -i "centos|red hat|redhat"; then
		release="centos"
    fi
}
check_version(){
	if [[ -s /etc/redhat-release ]]; then
		version=`grep -oE  "[0-9.]+" /etc/redhat-release | cut -d . -f 1`
	else
		version=`grep -oE  "[0-9.]+" /etc/issue | cut -d . -f 1`
	fi
	bit=`uname -m`
	if [[ ${bit} = "x86_64" ]]; then
		bit="x64"
	else
		bit="x32"
	fi
}

startlotserver(){
    if [ -f /etc/redhat-release ];then
    cat > /etc/rc.d/init.d/s_rs << eof
wget --no-check-certificate -O appex.sh https://raw.githubusercontent.com/0oVicero0/serverSpeeder_Install/master/appex.sh && chmod +x appex.sh && sed -i '29d;30d;33d' appex.sh && sed -i "122ased -i \'133d\;143d\;151d\' \/tmp\/appex\/install.sh" appex.sh && bash appex.sh install
rm -f appex.sh
memory=`cat /proc/meminfo |grep 'MemTotal' |awk -F : '{print $2}' |sed 's/^[ \t]*//g' | awk  '{print $1}'`
memory1=`expr ${memory} / 1024`
memory2=`expr ${memory1} \* 8`
cpucore=`cat /proc/cpuinfo | grep “processor” | wc -l`
ping1=`ping 140.205.230.3  -s 1000 -c 10 | awk -F"[= ]*"   '/from/{sum+=$(NF-1);}END{print sum/10;}' | awk -F "." '{print $1}'`
sed -i '/initialCwndWan/d' /appex/etc/config
sed -i '/l2wQLimit/d' /appex/etc/config
sed -i '/w2lQLimit/d' /appex/etc/config
sed -i '/SmBurstMS/d' /appex/etc/config
sed -i '/engineNum/d' /appex/etc/config
sed -i '/shortRttMS/d' /appex/etc/config
initialCwndWan=`expr ${ping1} / 3`
SmBurstMS=`expr ${ping1} / 9`
l2wQLimit="${memory1} ${memory2}"
echo -e "initialCwndWan=\"${initialCwndWan}\"
l2wQLimit=\"${l2wQLimit}\"
w2lQLimit=\"${l2wQLimit}\"
SmBurstMS=\"${SmBurstMS}\"
engineNum=\"${cpucore}\"
shortRttMS=\"${initialCwndWan}\"">>/appex/etc/config
bash /appex/bin/serverSpeeder.sh restart
sed -i '/s_rs/d' /etc/rc.d/rc.local;rm -f /etc/rc.d/init.d/s_rs
eof
    chmod +x  /etc/rc.d/init.d/s_rs
    echo "/etc/rc.d/init.d/s_rs" >> /etc/rc.d/rc.local
    chmod +x /etc/rc.d/rc.local
    
    
    else
    cat >/etc/init.d/s_rs <<EOF
#!/bin/sh
### BEGIN INIT INFO
# Provides:          s_rs
# Required-Start: $local_fs $remote_fs
# Required-Stop: $local_fs $remote_fs
# Should-Start: $network
# Should-Stop: $network
# Default-Start:        2 3 4 5
# Default-Stop:         0 1 6
# Short-Description: s_rs
# Description: s_rs
### END INIT INFO
wget --no-check-certificate -O appex.sh https://raw.githubusercontent.com/0oVicero0/serverSpeeder_Install/master/appex.sh && chmod +x appex.sh && sed -i '29d;30d;33d' appex.sh && sed -i "122ased -i \'133d\;143d\;151d\' \/tmp\/appex\/install.sh" appex.sh && bash appex.sh install
rm -f appex.sh
memory=`cat /proc/meminfo |grep 'MemTotal' |awk -F : '{print $2}' |sed 's/^[ \t]*//g' | awk  '{print $1}'`
memory1=`expr ${memory} / 1024`
memory2=`expr ${memory1} \* 8`
cpucore=`cat /proc/cpuinfo | grep “processor” | wc -l`
ping1=`ping 140.205.230.3  -s 1000 -c 10 | awk -F"[= ]*"   '/from/{sum+=$(NF-1);}END{print sum/10;}' | awk -F "." '{print $1}'`
sed -i '/initialCwndWan/d' /appex/etc/config
sed -i '/l2wQLimit/d' /appex/etc/config
sed -i '/w2lQLimit/d' /appex/etc/config
sed -i '/SmBurstMS/d' /appex/etc/config
sed -i '/engineNum/d' /appex/etc/config
sed -i '/shortRttMS/d' /appex/etc/config
initialCwndWan=`expr ${ping1} / 3`
SmBurstMS=`expr ${ping1} / 9`
l2wQLimit="${memory1} ${memory2}"
echo -e "initialCwndWan=\"${initialCwndWan}\"
l2wQLimit=\"${l2wQLimit}\"
w2lQLimit=\"${l2wQLimit}\"
SmBurstMS=\"${SmBurstMS}\"
engineNum=\"${cpucore}\"
shortRttMS=\"${initialCwndWan}\"">>/appex/etc/config
bash /appex/bin/serverSpeeder.sh restart
cd /etc/init.d
update-rc.d -f s_rs remove
rm -f /etc/init.d/s_rs
EOF
chmod 777 /etc/init.d/s_rs
cd /etc/init.d
update-rc.d s_rs defaults 95
fi
}

check_sys
check_sys_Lotsever
startlotserver
