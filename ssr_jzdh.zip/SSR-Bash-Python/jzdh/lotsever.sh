#!/bin/bash

function azrs {
		if [[ "${release}" == "centos" ]]; then
		rpm --import http://${github}/lotserver/${release}/RPM-GPG-KEY-elrepo.org
		yum remove -y kernel-firmware
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-firmware-${kernel_version}.rpm
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-${kernel_version}.rpm
		yum remove -y kernel-headers
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-headers-${kernel_version}.rpm
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-devel-${kernel_version}.rpm
	elif [[ "${release}" == "ubuntu" ]]; then
		mkdir bbr && cd bbr
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-headers-${kernel_version}-all.deb
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-headers-${kernel_version}.deb
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-image-${kernel_version}.deb
		dpkg -i linux-headers-${kernel_version}-all.deb
		dpkg -i linux-headers-${kernel_version}.deb
		dpkg -i linux-image-${kernel_version}.deb
		cd .. && rm -rf bbr
	elif [[ "${release}" == "debian" ]]; then
		mkdir bbr && cd bbr
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-image-${kernel_version}.deb
		dpkg -i linux-image-${kernel_version}.deb
		cd .. && rm -rf bbr
	fi
}
function jrs {
cd /boot/grub/
chmod 777 /boot/grub/grub.cfg
raw=$(grep -n "Advanced" grub.cfg|sed "s/\(.*\):.*/\1/")
initrd=$(grep "initrd.img-${kernel_version}" grub.cfg|sort -u)
vmlinuz=$(grep "initrd.img-${kernel_version}" grub.cfg|sort -u|sed "s/.*initrd.img-\(.*\)/\1/")
sed -i "s/^[ \t]*//g;1,${raw}s:^initrd.*:${initrd}:;1,${raw}s:vmlinuz-.* root:vmlinuz-${vmlinuz} root:" grub.cfg
}

#安装锐速内核
kbb=`uname -r`
github=raw.githubusercontent.com/chiakge/Linux-NetSpeed/master
	if [[ -s /etc/redhat-release ]]; then
		version=`grep -oE  "[0-9.]+" /etc/redhat-release | cut -d . -f 1`
	else
		version=`grep -oE  "[0-9.]+" /etc/issue | cut -d . -f 1`
	fi
	bit=`uname -m`
	if [[ ${bit} = "x86_64" ]]; then
		bit="x64"
	else
		bit="x32"
	fi
	if [[ -f /etc/redhat-release ]]; then
		release="centos"
	elif cat /etc/issue | grep -q -E -i "debian"; then
		release="debian"
	elif cat /etc/issue | grep -q -E -i "ubuntu"; then
		release="ubuntu"
	elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat"; then
		release="centos"
	elif cat /proc/version | grep -q -E -i "debian"; then
		release="debian"
	elif cat /proc/version | grep -q -E -i "ubuntu"; then
		release="ubuntu"
	elif cat /proc/version | grep -q -E -i "centos|red hat|redhat"; then
		release="centos"
    fi
	if [[ "${release}" == "centos" ]]; then
		if [[ ${version} == "6" ]]; then
			kernel_version="2.6.32-504"
			azrs
		elif [[ ${version} == "7" ]]; then
			yum -y install net-tools
			kernel_version="3.10.0-327"
			azrs
		else
			echo -e "${Error} Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
		fi
	elif [[ "${release}" == "debian" ]]; then
		if [[ ${version} -ge "7" ]]; then
			if [[ ${bit} == "x64" ]]; then
				kernel_version="3.16.0-4"
				azrs
    update-grub && jrs
			elif [[ ${bit} == "x32" ]]; then
				kernel_version="3.2.0-4"
				azrs
				update-grub && jrs
 			fi
		else
			echo -e "${Error} Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
		fi
	elif [[ "${release}" == "ubuntu" ]]; then
		if [[ ${version} -ge "12" ]]; then
			if [[ ${bit} == "x64" ]]; then
				kernel_version="4.4.0-47"
				azrs
    update-grub && jrs
			elif [[ ${bit} == "x32" ]]; then
				kernel_version="3.13.0-29"
				azrs
    update-grub && jrs
			fi
		else
			echo -e "${Error} Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
		fi
	else
		echo -e "${Error} Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
	fi

#配置登陆任务
cd /root/
cat > profile.sh << jzdh
#!/bin/bash
clear;echo
echo ' 检测到有未完成的任务'
echo
echo ' 正在玩命执行中，请稍等'
echo
wget --no-check-certificate https://raw.githubusercontent.com/FH0/nubia/master/appex.sh > /dev/null 2>&1
bash appex.sh install
bash /appex/bin/serverSpeeder.sh status
chmod 777 /etc/profile
sed -i '/profile.sh/d' /etc/profile
chmod 600 /etc/profile
rm -f /root/profile.sh
jzdh
echo 'sh /root/profile.sh' >> /etc/profile
