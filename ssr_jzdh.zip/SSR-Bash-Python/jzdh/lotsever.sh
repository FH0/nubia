#!/bin/bash

function azrs {
		if [[ "${release}" == "centos" ]]; then
		rpm --import http://${github}/lotserver/${release}/RPM-GPG-KEY-elrepo.org
		yum remove -y kernel-firmware
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-firmware-${kernel_version}.rpm
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-${kernel_version}.rpm
		yum remove -y kernel-headers
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-headers-${kernel_version}.rpm
		yum install -y http://${github}/lotserver/${release}/${version}/${bit}/kernel-devel-${kernel_version}.rpm
	elif [[ "${release}" == "ubuntu" ]]; then
		mkdir bbr && cd bbr
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-headers-${kernel_version}-all.deb
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-headers-${kernel_version}.deb
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-image-${kernel_version}.deb
		dpkg -i linux-headers-${kernel_version}-all.deb
		dpkg -i linux-headers-${kernel_version}.deb
		dpkg -i linux-image-${kernel_version}.deb
		cd .. && rm -rf bbr
	elif [[ "${release}" == "debian" ]]; then
		mkdir bbr && cd bbr
		wget -N --no-check-certificate http://${github}/lotserver/${release}/${bit}/linux-image-${kernel_version}.deb
		dpkg -i linux-image-${kernel_version}.deb
		cd .. && rm -rf bbr
	fi
}
function jrs {
rs1=`grep "${kernel_version}" /boot/grub/grub.cfg | grep 'linux' | grep -v "recovery" | grep -v "menuentry"`
rs2=`grep "${kernel_version}" /boot/grub/grub.cfg | grep 'initrd.img' | grep -v "recovery" | grep -v "menuentry"|sort -u`
chmod 777 /boot/grub/grub.cfg && sed -i "s:.*vmlinuz.*:${rs1}:g" /boot/grub/grub.cfg && sed -i "s:.*initrd.*:${rs2}:g" /boot/grub/grub.cfg
}

#配置开机文件
if [ -f /etc/redhat-release ];then
cat > /etc/rc.d/init.d/s_rs << eof
wget https://raw.githubusercontent.com/FH0/nubia/master/appex.sh && bash appex.sh install && rm -f appex.sh
sed -i "/s_rs/d" /etc/rc.d/rc.local
rm -f "/etc/rc.d/init.d/s_rs"
eof
chmod +x  /etc/rc.d/init.d/s_rs
echo "/etc/rc.d/init.d/s_rs" >> /etc/rc.d/rc.local
chmod +x /etc/rc.d/rc.local


else
cat >/etc/init.d/s_rs <<EOF
#!/bin/sh
### BEGIN INIT INFO
# Provides:          s_rs
# Required-Start: $local_fs $remote_fs
# Required-Stop: $local_fs $remote_fs
# Should-Start: $network
# Should-Stop: $network
# Default-Start:        2 3 4 5
# Default-Stop:         0 1 6
# Short-Description: s_rs
# Description: s_rs
### END INIT INFO
wget https://raw.githubusercontent.com/FH0/nubia/master/appex.sh && bash appex.sh install && rm -f appex.sh
cd /etc/init.d
update-rc.d -f s_rs remove
rm -f /etc/init.d/s_rs
EOF
chmod 777 /etc/init.d/s_rs
cd /etc/init.d
update-rc.d s_rs defaults 95
fi

#安装锐速内核
kbb=`uname -r`
github=raw.githubusercontent.com/chiakge/Linux-NetSpeed/master
	if [[ -s /etc/redhat-release ]]; then
		version=`grep -oE  "[0-9.]+" /etc/redhat-release | cut -d . -f 1`
	else
		version=`grep -oE  "[0-9.]+" /etc/issue | cut -d . -f 1`
	fi
	bit=`uname -m`
	if [[ ${bit} = "x86_64" ]]; then
		bit="x64"
	else
		bit="x32"
	fi
	if [[ -f /etc/redhat-release ]]; then
		release="centos"
	elif cat /etc/issue | grep -q -E -i "debian"; then
		release="debian"
	elif cat /etc/issue | grep -q -E -i "ubuntu"; then
		release="ubuntu"
	elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat"; then
		release="centos"
	elif cat /proc/version | grep -q -E -i "debian"; then
		release="debian"
	elif cat /proc/version | grep -q -E -i "ubuntu"; then
		release="ubuntu"
	elif cat /proc/version | grep -q -E -i "centos|red hat|redhat"; then
		release="centos"
    fi
	if [[ "${release}" == "centos" ]]; then
		if [[ ${version} == "6" ]]; then
			kernel_version="2.6.32-504"
			azrs
		elif [[ ${version} == "7" ]]; then
			yum -y install net-tools
			kernel_version="3.10.0-327"
			azrs
		else
			echo -e "${Error} Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
		fi
	elif [[ "${release}" == "debian" ]]; then
		if [[ ${version} -ge "7" ]]; then
			if [[ ${bit} == "x64" ]]; then
				kernel_version="3.16.0-4"
				azrs
    update-grub && jrs
			elif [[ ${bit} == "x32" ]]; then
				kernel_version="3.2.0-4"
				azrs
				update-grub && jrs
 			fi
		else
			echo -e "${Error} Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
		fi
	elif [[ "${release}" == "ubuntu" ]]; then
		if [[ ${version} -ge "12" ]]; then
			if [[ ${bit} == "x64" ]]; then
				kernel_version="4.4.0-47"
				azrs
    update-grub && jrs
			elif [[ ${bit} == "x32" ]]; then
				kernel_version="3.13.0-29"
				azrs
    update-grub && jrs
			fi
		else
			echo -e "${Error} Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
		fi
	else
		echo -e "${Error} Lotsever不支持当前系统 ${release} ${version} ${bit} !" && exit 1
	fi

