#!/bin/bash

cp /root/SSR-Bash-Python/jzdh/jzdh /bin;chmod +x /bin/jzdh;gwip=`curl ipinfo.io/ip`;sed -i s/yourip/${gwip}/g /bin/jzdh;rm -f /root/SSR-Bash-Python/jzdh/jzdh
clear
echo 'SSR支持CentOS Debian Ubuntu';echo '请选择将要执行的操作:'
echo;echo '1.安装ssr';echo '2.安装bbr';echo '3.安装ssr nginx bbr';echo
read -p 输入选择: choice

if [ $choice -eq 1 ];then
clear;echo;ssr=`unzip /root/SSR-Bash-Python/shadowsocksr.zip > /dev/null 2>&1;cd /root/SSR-Bash-Python/shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p'`;echo;echo '80端口的配置:';echo $ssr;echo
echo ' 安装完成后输入jzdh可获取本脚本的帮助,按下回车继续';echo;read
bash /root/SSR-Bash-Python/install.sh
fi
if [ $choice -eq 2 ];then
bash /root/SSR-Bash-Python/jzdh/bbr.sh
fi
if [ $choice -eq 3 ];then
ssr=`cd /root/SSR-Bash-Python;unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p'`;echo;echo '80端口的配置:';echo $ssr;echo;sleep 4
bash /root/SSR-Bash-Python/jzdh/bbr.sh
bash /root/SSR-Bash-Python/install.sh
bash /root/SSR-Bash-Python/jzdh/nginx.sh
reboot
fi
