#!/bin/bash
wp=/root/SSR-Bash-Python/
yum install curl -y || apt-get install curl -y
cp ${wp}jzdh/jzdh /bin;chmod +x /bin/jzdh;gwip=`curl ipinfo.io/ip`;sed -i s/yourip/${gwip}/g /bin/jzdh;rm -f ${wp}jzdh/jzdh
clear
optimizing_system
echo 'SSR支持CentOS Debian Ubuntu';echo '请选择将要执行的操作:'
echo;echo '1.安装ssr';echo '2.安装bbr';echo '3.安装锐速';echo '4.安装ssr nginx bbr';echo '5.安装ssr nginx 锐速';echo '6.查看脚本相关'
read -p 输入选择: choice
ssr=`echo '80端口的配置:';cd ${wp};unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p';rm -rf ${wp}shadowsocksr`

if [ $choice -eq 1 ];then
clear;echo ${ssr};echo;echo ' 安装完成后输入jzdh可获取本脚本的帮助,按下回车继续';echo;read
bash ${wp}install.sh
fi
if [ $choice -eq 2 ];then
bash ${wp}jzdh/bbr.sh;reboot
fi
if [ $choice -eq 3 ];then
bash ${wp}jzdh/lotsever.sh;reboot
fi
if [ $choice -eq 4 ];then
clear;echo ${ssr};echo
bash ${wp}jzdh/bbr.sh > /dev/null 2>&1 &
bash ${wp}jzdh/nginx.sh > /dev/null 2>&1 &
bash ${wp}install.sh
wait;rm -rf /root/nginx*;rm -f /root/uuio;reboot
fi
if [ $choice -eq 5 ];then
clear;echo ${ssr};echo
bash ${wp}jzdh/nginx.sh > /dev/null 2>&1 &
bash ${wp}jzdh/lotsever.sh > /dev/null 2>&1 &
bash ${wp}install.sh
wait;rm -rf /root/nginx*;rm -f /root/uuio;reboot
fi
if [ $choice -eq 6 ];then
echo 'ssr脚本是马老师的,锐速&bbr脚本是千影的,nginx脚本是根据网上教程写的'
read -p '返回'
clear
bash jzdh.sh
fi

function optimizing_system {
	sed -i '/fs.file-max/d' /etc/sysctl.conf
	sed -i '/net.core.rmem_max/d' /etc/sysctl.conf
	sed -i '/net.core.wmem_max/d' /etc/sysctl.conf
	sed -i '/net.core.rmem_default/d' /etc/sysctl.conf
	sed -i '/net.core.wmem_default/d' /etc/sysctl.conf
	sed -i '/net.core.netdev_max_backlog/d' /etc/sysctl.conf
	sed -i '/net.core.somaxconn/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_syncookies/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_tw_reuse/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_tw_recycle/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_fin_timeout/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_keepalive_time/d' /etc/sysctl.conf
	sed -i '/net.ipv4.ip_local_port_range/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_max_syn_backlog/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_max_tw_buckets/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_rmem/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_wmem/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_mtu_probing/d' /etc/sysctl.conf
	sed -i '/net.ipv4.ip_forward/d' /etc/sysctl.conf
	echo "# max open files
fs.file-max = 1024000
# max read buffer
net.core.rmem_max = 67108864
# max write buffer
net.core.wmem_max = 67108864
# default read buffer
net.core.rmem_default = 65536
# default write buffer
net.core.wmem_default = 65536
# max processor input queue
net.core.netdev_max_backlog = 4096
# max backlog
net.core.somaxconn = 4096

# resist SYN flood attacks
net.ipv4.tcp_syncookies = 1
# reuse timewait sockets when safe
net.ipv4.tcp_tw_reuse = 1
# turn off fast timewait sockets recycling
net.ipv4.tcp_tw_recycle = 0
# short FIN timeout
net.ipv4.tcp_fin_timeout = 30
# short keepalive time
net.ipv4.tcp_keepalive_time = 1200
# outbound port range
net.ipv4.ip_local_port_range = 10000 65000
# max SYN backlog
net.ipv4.tcp_max_syn_backlog = 4096
# max timewait sockets held by system simultaneously
net.ipv4.tcp_max_tw_buckets = 5000
# TCP receive buffer
net.ipv4.tcp_rmem = 4096 87380 67108864
# TCP write buffer
net.ipv4.tcp_wmem = 4096 65536 67108864
# turn on path MTU discovery
net.ipv4.tcp_mtu_probing = 1

# forward ipv4
net.ipv4.ip_forward = 1">>/etc/sysctl.conf
	sysctl -p
	echo "*               soft    nofile           512000
*               hard    nofile          1024000">/etc/security/limits.conf
	echo "session required pam_limits.so">>/etc/pam.d/common-session
	echo "ulimit -SHn 1024000">>/etc/profile
}
