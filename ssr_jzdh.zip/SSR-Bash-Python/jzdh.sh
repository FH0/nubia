#!/bin/bash
wp=/root/SSR-Bash-Python/
yum install curl -y || apt-get install curl -y

function yh {
 sed -i '/fs.file-max/d' /etc/sysctl.conf
	sed -i '/net.core.rmem_max/d' /etc/sysctl.conf
	sed -i '/net.core.wmem_max/d' /etc/sysctl.conf
	sed -i '/net.core.rmem_default/d' /etc/sysctl.conf
	sed -i '/net.core.wmem_default/d' /etc/sysctl.conf
	sed -i '/net.core.netdev_max_backlog/d' /etc/sysctl.conf
	sed -i '/net.core.somaxconn/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_syncookies/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_tw_reuse/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_tw_recycle/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_fin_timeout/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_keepalive_time/d' /etc/sysctl.conf
	sed -i '/net.ipv4.ip_local_port_range/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_max_syn_backlog/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_max_tw_buckets/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_rmem/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_wmem/d' /etc/sysctl.conf
	sed -i '/net.ipv4.tcp_mtu_probing/d' /etc/sysctl.conf
	sed -i '/net.ipv4.ip_forward/d' /etc/sysctl.conf
	echo "# max open files
fs.file-max = 1024000
# max read buffer
net.core.rmem_max = 67108864
# max write buffer
net.core.wmem_max = 67108864
# default read buffer
net.core.rmem_default = 65536
# default write buffer
net.core.wmem_default = 65536
# max processor input queue
net.core.netdev_max_backlog = 4096
# max backlog
net.core.somaxconn = 4096

# resist SYN flood attacks
net.ipv4.tcp_syncookies = 1
# reuse timewait sockets when safe
net.ipv4.tcp_tw_reuse = 1
# turn off fast timewait sockets recycling
net.ipv4.tcp_tw_recycle = 0
# short FIN timeout
net.ipv4.tcp_fin_timeout = 30
# short keepalive time
net.ipv4.tcp_keepalive_time = 1200
# outbound port range
net.ipv4.ip_local_port_range = 10000 65000
# max SYN backlog
net.ipv4.tcp_max_syn_backlog = 4096
# max timewait sockets held by system simultaneously
net.ipv4.tcp_max_tw_buckets = 5000
# TCP receive buffer
net.ipv4.tcp_rmem = 4096 87380 67108864
# TCP write buffer
net.ipv4.tcp_wmem = 4096 65536 67108864
# turn on path MTU discovery
net.ipv4.tcp_mtu_probing = 1

# forward ipv4
net.ipv4.ip_forward = 1">>/etc/sysctl.conf
	sysctl -p
	echo "*               soft    nofile           512000
*               hard    nofile          1024000">/etc/security/limits.conf
	echo "session required pam_limits.so">>/etc/pam.d/common-session
	echo "ulimit -SHn 1024000">>/etc/profile
}

function getaddip {
python << jzdh
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.connect(('119.29.29.29', 80))
print(s.getsockname()[0])
s.close()
jzdh
}
gwip=$(getaddip)


cp ${wp}jzdh/jzdh /bin;chmod +x /bin/jzdh;sed -i s/yourip/${gwip}/g ${wp}ssr;rm -f ${wp}jzdh/jzdh
clear
echo
echo ' 安装完成后输入jzdh即可获取帮助'
echo
echo ' 1.安装   ssr'
echo ' 2.安装   bbr(会重启)'
echo ' 3.安装   锐速(会重启)'
echo ' 4.安装   ssr bbr'
echo ' 5.安装   ssr 锐速(自用)'
echo ' 6.安装   v2ray'
echo
read -p '输入序号:' choice
ssr=`echo '80端口的配置:';cd ${wp};unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p';rm -rf ${wp}shadowsocksr`
yh > /dev/null 2>&1
if [ $choice -eq 1 ];then
clear;echo ${ssr};echo;echo ' 安装完成后输入jzdh可获取本脚本的帮助,按下回车继续';echo;read
bash ${wp}install.sh
fi
if [ $choice -eq 2 ];then
bash ${wp}jzdh/bbr.sh;reboot
fi
if [ $choice -eq 3 ];then
bash ${wp}jzdh/serverspeeder.sh;reboot
fi
if [ $choice -eq 4 ];then
clear;echo ${ssr};echo
bash ${wp}install.sh
bash ${wp}jzdh/bbr.sh
rm -f /root/uuio;reboot
fi
if [ $choice -eq 5 ];then
clear;echo ${ssr};echo
bash ${wp}install.sh
bash ${wp}jzdh/serverspeeder.sh
rm -f /root/uuio;reboot
fi
if [ $choice -eq 6 ];then
bash ${wp}jzdh/v2ray.sh
clear;echo ' 默认打开80 8080 53端口'
echo ' uuid为 f80a70a1-9d36-18f9-56a8-79e4d6fc8019 '
echo ' uuid就是密码，需要更改的话请编辑/etc/v2ray/config.json'
fi
