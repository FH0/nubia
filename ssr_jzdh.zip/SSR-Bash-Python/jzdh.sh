#!/bin/bash
wp=/root/SSR-Bash-Python/
cp ${wp}jzdh/jzdh /bin;chmod +x /bin/jzdh;gwip=`curl ipinfo.io/ip`;sed -i s/yourip/${gwip}/g /bin/jzdh;rm -f ${wp}jzdh/jzdh
clear
echo 'SSR支持CentOS Debian Ubuntu';echo '请选择将要执行的操作:'
echo;echo '1.安装ssr';echo '2.安装bbr';echo '3.安装ssr nginx bbr';echo
read -p 输入选择: choice
ssr=`echo '80端口的配置:';cd ${wp};unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p';rm -rf ${wp}shadowsocksr;echo`

if [ $choice -eq 1 ];then
clear;echo ${ssr};echo ' 安装完成后输入jzdh可获取本脚本的帮助,下次执行脚本请输入jzdh,按下回车继续';echo;read
bash ${wp}install.sh
fi
if [ $choice -eq 2 ];then
bash ${wp}jzdh/bbr.sh
fi
if [ $choice -eq 3 ];then
clear;echo ${ssr}
bash ${wp}install.sh
bash ${wp}jzdh/nginx.sh
bash ${wp}jzdh/bbr.sh
reboot
fi
