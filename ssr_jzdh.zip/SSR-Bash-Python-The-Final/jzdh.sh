echo '本脚本支持Debian和Centos'
echo '请选择将要执行的操作:'
echo 
echo '1.安装ssr'
echo '2.安装ssr加锐速'
echo '3.安装ssr加nginx'
echo '4.安装ssr加锐速加nginx'
echo
read -p 输入选择: choice
if [ $choice -eq 1 ];then
echo '安装完成后可以输入jzdh来获取本脚本的帮助'
ssr=`unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p'`;echo;echo '80端口的配置:';echo $ssr;echo;rm -rf shadowsocksr;sleep 5
echo 开始安装;bash install.sh
fi
if [ $choice -eq 2 ];then
echo '安装完成后可以输入jzdh来获取本脚本的帮助'
ssr=`unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p'`;echo;echo '80端口的配置:';echo $ssr;echo;rm -rf shadowsocksr;sleep 5

fi
if [ $choice -eq 3 ];then
echo '安装完成后可以输入jzdh来获取本脚本的帮助'
ssr=`unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p'`;echo;echo '80端口的配置:';echo $ssr;echo;rm -rf shadowsocksr;sleep 5

fi
if [ $choice -eq 4 ];then
echo '安装完成后可以输入jzdh来获取本脚本的帮助'
ssr=`unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p'`;echo;echo '80端口的配置:';echo $ssr;echo;rm -rf shadowsocksr;sleep 5

fi
