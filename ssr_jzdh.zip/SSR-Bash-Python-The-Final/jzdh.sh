#!/bin/bash

function check_OS {
if [ -n "$(grep 'Aliyun Linux release' /etc/issue)" -o -e /etc/redhat-release ];then
    OS=CentOS
    [ -n "$(grep ' 7\.' /etc/redhat-release)" ] && CentOS_RHEL_version=7
    [ -n "$(grep ' 6\.' /etc/redhat-release)" -o -n "$(grep 'Aliyun Linux release6 15' /etc/issue)" ] && CentOS_RHEL_version=6
    [ -n "$(grep ' 5\.' /etc/redhat-release)" -o -n "$(grep 'Aliyun Linux release5' /etc/issue)" ] && CentOS_RHEL_version=5
elif [ -n "$(grep 'Amazon Linux AMI release' /etc/issue)" -o -e /etc/system-release ];then
    OS=CentOS
    CentOS_RHEL_version=6
elif [ -n "$(grep bian /etc/issue)" -o "$(lsb_release -is 2>/dev/null)" == 'Debian' ];then
    OS=Debian
    [ ! -e "$(which lsb_release)" ] && { apt-get -y update; apt-get -y install lsb-release; clear; }
    Debian_version=$(lsb_release -sr | awk -F. '{print $1}')
elif [ -n "$(grep Deepin /etc/issue)" -o "$(lsb_release -is 2>/dev/null)" == 'Deepin' ];then
    OS=Debian
    [ ! -e "$(which lsb_release)" ] && { apt-get -y update; apt-get -y install lsb-release; clear; }
    Debian_version=$(lsb_release -sr | awk -F. '{print $1}')
elif [ -n "$(grep Ubuntu /etc/issue)" -o "$(lsb_release -is 2>/dev/null)" == 'Ubuntu' -o -n "$(grep 'Linux Mint' /etc/issue)" ];then
    OS=Ubuntu
    [ ! -e "$(which lsb_release)" ] && { apt-get -y update; apt-get -y install lsb-release; clear; }
    Ubuntu_version=$(lsb_release -sr | awk -F. '{print $1}')
    [ -n "$(grep 'Linux Mint 18' /etc/issue)" ] && Ubuntu_version=16
else
    echo "Does not support this OS, Please contact the author! "
    kill -9 $$
fi
}
function echo_80 {
echo ' 安装完成后输入jzdh可获取本脚本的帮助'
ssr=`unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p'`;echo;echo '80端口的配置:';echo $ssr;echo;rm -rf shadowsocksr;read
}
function install_nginx {
if [[ ${OS} == Ubuntu ]];then
apt-get update -y;apt-get install nginx -y;mkdir /accept;cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak
echo 'worker_processes  1;
events {
    worker_connections  1024;
}
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    keepalive_timeout  65;
        server {
        listen       8082;        
        server_name  localhost;   
        root    /accept;  
        autoindex on;             
        autoindex_exact_size off;
        }
}' > /etc/nginx/nginx.conf
/etc/init.d/nginx start;/etc/init.d/nginx restart
fi
if [[ ${OS} == Debian ]];then
apt-get update -y;apt-get install nginx -y;mkdir /accept;cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak
echo 'worker_processes  1;
events {
    worker_connections  1024;
}
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    keepalive_timeout  65;
        server {
        listen       8082;        
        server_name  localhost;   
        root    /accept;  
        autoindex on;             
        autoindex_exact_size off;
        }
}' > /etc/nginx/nginx.conf
/etc/init.d/nginx start;/etc/init.d/nginx restart
fi
if [[ ${OS} == CentOS ]];then
yum -y install gcc gcc-c++ make libtool zlib zlib-devel openssl openssl-devel pcre pcre-devel tar
wget http://nginx.org/download/nginx-1.10.1.tar.gz;tar -zxvf nginx-1.10.1.tar.gz;cd nginx-1.10.1
./configure --prefix=/usr/local/webserver/nginx --with-http_stub_status_module --with-http_ssl_module --with-pcre
make && make install;mkdir /accept;cp /usr/local/webserver/nginx/conf/nginx.conf /usr/local/webserver/nginx/conf/nginx.conf.bak
echo 'worker_processes  1;
events {
    worker_connections  1024;
}
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    keepalive_timeout  65;
        server {
        listen       8082;        
        server_name  localhost;   
        root    /accept;  
        autoindex on;             
        autoindex_exact_size off;
        }
}' > /usr/local/webserver/nginx/conf/nginx.conf
/usr/local/webserver/nginx/sbin/nginx
fi
}
function install_rs {
if [[ ${OS} == Ubuntu ]];then
echo 'Ubuntu is not supporting.Please did it by yourself'
fi
if [[ ${OS} == Debian ]];then
clear;echo;echo ' 安装时请依次选择ok no';echo;echo '重启完成后可以通过/serverspeeder/bin/serverSpeeder.sh status来查看锐速状态';read
img_total=`dpkg -l|grep linux-image | sed 's/.*\(linux-image.*-amd64\).*/\1/g' | wc -l`
img_list=`dpkg -l|grep linux-image | sed 's/.*\(linux-image.*-amd64\).*/\1/g'`
var=1;while [ "$var" -le ${img_total} ]
do
img=`echo ${img_list} | sed -n "${var}p" `
apt-get purge ${img} -y;let var+=1
done
apt-get install linux-image-3.16.0-4-amd64 -y
update-grub
cat > /root/install_rs << eof
wget -N --no-check-certificate https://raw.githubusercontent.com/91yun/serverspeeder/master/serverspeeder-all.sh && bash serverspeeder-all.sh
sed -i 's/bash \/root\/install_rs//g' /etc/rc.local;rm -f /root/SSR*/install_rs
eof
sed -i 's/exit 0//g' /etc/rc.local;echo 'bash /root/install_rs' >> /etc/rc.local;echo 'exit 0' >> /etc/rc.local
reboot
fi
if [[ ${OS} == CentOS ]];then
clear;echo;echo '仅仅支持CentOS7,其他版本在安装后会开不了机';echo;echo '重启完成后可以通过/serverspeeder/bin/serverSpeeder.sh status来查看锐速状态';read
rpm -ivh https://buildlogs.centos.org/c7.01.u/kernel/20150327030147/3.10.0-229.1.2.el7.x86_64/kernel-3.10.0-229.1.2.el7.x86_64.rpm --force
echo 'wget -N --no-check-certificate https://github.com/91yun/serverspeeder/raw/master/serverspeeder-v.sh && bash serverspeeder-v.sh CentOS 7.1 3.10.0-229.1.2.el7.x86_64 x64 3.10.61.12 serverspeeder_2727;sed -i '/install_rs/d' /etc/rc.d/rc.local;rm -f /root/install_rs' > /root/install_rs
echo 'bash /root/install_rs' >> /etc/rc.d/rc.local;chmod +x /etc/rc.d/rc.local;reboot
fi
}
function start {
clear;echo 'SSR支持CentOS Debian Ubuntu,锐速仅支持CentOS7 Debian8';echo '请选择将要执行的操作:'
echo ;echo '1.安装ssr';echo '2.安装锐速';echo '3.安装ssr加nginx';echo
read -p 输入选择: choice
if [ $choice -eq 1 ];then
echo_80;bash install.sh
fi
if [ $choice -eq 2 ];then
install_rs
fi
if [ $choice -eq 3 ];then
echo_80;bash install.sh;install_nginx
fi
cp jzdh /bin;chmod +x /bin/jzdh;gwip=`curl ipinfo.io/ip`;sed -i 's/yourip/${gwip}/g' /bin/jzdh
}
check_OS;start
