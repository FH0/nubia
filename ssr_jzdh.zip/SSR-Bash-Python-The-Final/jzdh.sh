#!/bin/bash
function check_os{
cen=`cat /etc/redhat-release | grep CentOS`
if [ -z $cen ];then
 echo
 echo ' 不支持的系统,可能仅支持安装ssr'
 echo 
else
 cen7=`cat /etc/redhat-release | grep CentOS Linux release 7`
 if [ -z $cen7 ];then
 os=CentOS6
 else
 os=CentOS7
 fi
fi
}
function install_rs{
if [ $os -ep CentOS6 ];then
rpm -ivh http://soft.91yun.org/ISO/Linux/CentOS/kernel/kernel-firmware-2.6.32-504.3.3.el6.noarch.rpm;rpm -ivh http://soft.91yun.org/ISO/Linux/CentOS/kernel/kernel-2.6.32-504.3.3.el6.x86_64.rpm --force
wget -N --no-check-certificate https://github.com/91yun/serverspeeder/raw/master/serverspeeder.sh && bash serverspeeder.sh
fi
if [ $os -ep CentOS7 ];then
rpm -ivh http://soft.91yun.org/ISO/Linux/CentOS/kernel/kernel-3.10.0-229.1.2.el7.x86_64.rpm --force
wget -N --no-check-certificate https://github.com/91yun/serverspeeder/raw/master/serverspeeder.sh && bash serverspeeder.sh
fi
reboot
}
function echo_80 {
echo '安装完成后可以输入jzdh来获取本脚本的帮助'
ssr=`unzip shadowsocksr.zip > /dev/null 2>&1;cd shadowsocksr;python mujson_mgr.py -a -u 1 -p 80 -k 239 -m chacha20 -O auth_sha1_v4 -o http_simple -t 700 -G 10 | sed -n '$p'`;echo;echo '80端口的配置:';echo $ssr;echo;rm -rf shadowsocksr;sleep 5
}
function install_nginx {
yum install nginx -y;mkdir /accept;cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak
cat > /etc/nginx/nginx.conf << eof
worker_processes  1;
events {
    worker_connections  1024;
}
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    keepalive_timeout  65;
        server {
        listen       8082;        
        server_name  localhost;   
        root    /accept;  
        autoindex on;             
        autoindex_exact_size off;
        }
}
eof
service nginx start
}
function start {
echo '本脚本支持Centos6,7'
echo '请选择将要执行的操作:'
echo 
echo '1.安装ssr'
echo '2.安装ssr加锐速'
echo '3.安装ssr加nginx'
echo '4.安装ssr加nginx加锐速'
echo
read -p 输入选择: choice
if [ $choice -eq 1 ];then
echo_80;bash install.sh
fi
if [ $choice -eq 2 ];then
echo_80;bash install.sh;install_rs
fi
if [ $choice -eq 3 ];then
echo_80;bash install.sh;install_nginx
fi
if [ $choice -eq 4 ];then
echo_80;bash install.sh;install_nginx;install_rs
fi
cat > /bin/jzdh << eof
ip=`curl ipecho.net/plain`
echo '#mmmmmmmmmmmmmmmm
ssr默认开启 80 8080 53端口 
三个端口的默认密码是239 相关配置是chacha20 auth_shra1_v4 http_simple
80端口默认限制10个连接数量 8080是3个 53是3个
80端口默认限制700g流量 8080限制150g 53限制150g

一键更改 80 8080 53 端口的密码可以使用下面的命令
csp 80密码 8080密码 53密码 
举例 csp mm80 mm8080 mm53 是把80端口密码改成mm80 8080端口改成mm8080 53端口改成mm53
#mmmmmmmmmmmmmmmm


#mmmmmmmmmmmmmmmm
nginx的默认工作目录是/accept  默认端口是8082 
登陆http://${ip}:8082即可看到你的网站
#mmmmmmmmmmmmmmmm'
eof
}
check_os;start
