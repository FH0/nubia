#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/ssr_jzdh"

RED="\033[31m"      # Error message
GREEN="\033[32m"    # Success message
YELLOW="\033[33m"   # Warning message
BLUE="\033[36m"     # Info message

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    [ -z "$(command -v yum)" ] && Installer="apt-get" || Installer="yum"
    var="0"
    for command in $1;do
        echo "$CHECK" | grep -q "$command"
        if [ "$?" != "0" ];then
            [ "$var" = "0" ] && apt-get update && var="1"
            $Installer install $command -y
        fi > /dev/null 2>&1
    [ "$?" != "0" ] && colorEcho $RED "相关命令安装失败！" && exit 1
    done
}

install_ssr(){
    colorEcho $BLUE "正在安装ssr..."
    cd $wp/shadowsocksr
    bash setup_cymysql.sh >/dev/null 2>&1
    bash initcfg.sh
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i "s|SERVER_PUB_ADDR = .*|SERVER_PUB_ADDR = '$public_ip'|" $wp/shadowsocksr/userapiconfig.py
    command -v python >/dev/null 2>&1 || cp $(ls /usr/bin/python* | grep "[0-9]\$" | tail -n 1) /usr/bin/python

    colorEcho $BLUE "正在开启ssr自启程序..."
    cat $wp/ssr.service > /etc/systemd/system/ssr.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装ssr控制面板..."
    cat $wp/manage_pannel.sh > /bin/ssr
    chmod +x /bin/ssr

    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1
}

install_libsodium() {
    colorEcho $BLUE "正在安装libsodium..."
    lib_path=$(cat /etc/ld.so.conf.d/* | grep '^/' | head -n 1)
    if [ ! -f "${lib_path}/libsodium.so.23" ];then
        cp $wp/libsodium.so.23 $lib_path
        ldconfig
    fi
}

add_one_port(){
    read -p $'\033[33m请添加一个端口[默认随机]: \033[0m' Port
    [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
    echo
    read -p $'\033[33m请设置密码[默认随机]: \033[0m' Passport
    [ -z "$Passport" ] && Passport=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
    echo
    read -p $'\033[33m请设置流量[单位G][默认999]: \033[0m' Trafic
    [ -z "$Trafic" ] && Trafic=999
    echo

    cd $wp/shadowsocksr
    python mujson_mgr.py -a -u $Port -p $Port -k $Passport -m chacha20 -O auth_sha1_v4 -o http_simple -t $Trafic >/dev/null 2>&1
}

main(){
    cmd_need "unzip wget curl net-tools git python"
    install_ssr
    install_libsodium
    add_one_port
    systemctl enable ssr.service >/dev/null 2>&1 ; systemctl start ssr.service
    colorEcho $GREEN "ssr安装完成！输入ssr可进入控制面板！"
}

main
