#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/ssr_jzdh"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    if [ -z "$(command -v yum)" ];then
        apt-get update
        apt-get install $1 -y
    else
        yum install $1 -y
    fi >/dev/null 2>&1
}

install_ssr(){
    if ! apt-get install libcap2-bin -y >/dev/null 2>&1;then
        yum install libcap -y
    fi >/dev/null 2>&1

    colorEcho $BLUE "正在安装ssr..."
    cd $wp/shadowsocksr
    bash setup_cymysql.sh >/dev/null 2>&1
    bash initcfg.sh
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i "s|SERVER_PUB_ADDR = .*|SERVER_PUB_ADDR = '$public_ip'|" $wp/shadowsocksr/userapiconfig.py
    command -v python >/dev/null 2>&1 || cp $(ls /usr/bin/python* | grep "[0-9]\$" | tail -n 1) /usr/bin/python

    colorEcho $BLUE "正在开启ssr自启程序..."
    cat $wp/ssr.service > /etc/systemd/system/ssr.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装ssr控制面板..."
    cat $wp/manage_panel.sh > /bin/ssr
    chmod +x /bin/ssr

    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1
}

install_libsodium() {
    colorEcho $BLUE "正在安装libsodium..."
    lib_path=$(cat /etc/ld.so.conf.d/* | grep '^/' | head -n 1)
    if [ ! -f "${lib_path}/libsodium.so.23" ];then
        cp $wp/libsodium.so.23 $lib_path
        ldconfig
    fi
}

main(){
    cmd_need "unzip wget curl iproute git python"
    install_ssr
    install_libsodium
    colorEcho $GREEN "ssr安装完成！输入ssr可进入控制面板！"
    colorEcho $GREEN "如需自定义添加端口的设置，参考这样进入控制面板: method=chacha20 obfs=http_simple protocol=auth_sha1_v4 ssr"
}

main
