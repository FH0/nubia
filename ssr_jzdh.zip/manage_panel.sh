#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/ssr_jzdh"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

add_port() {
    colorRead ${YELLOW} "请设置端口[默认随机]" Port
    [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
    colorRead ${YELLOW} "请设置密码[默认随机]" Passport
    [ -z "$Passport" ] && Passport=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
    colorRead ${YELLOW} "请设置流量[单位G][默认999]" Trafic
    [ -z "$Trafic" ] && Trafic=999

    cd $wp/shadowsocksr
    python mujson_mgr.py -a -u $Port -p $Port -k $Passport -m chacha20 -O auth_sha1_v4 -o http_simple -t $Trafic >/dev/null 2>&1
    systemctl restart ssr.service
}

del_port() {
    var=1
    for Echo in $ssr_ports;do
        echo -e " $var. 删除\033[33m$Echo\033[0m端口"
        ((var++))
    done
    echo
    colorRead ${YELLOW} "请选择" input_choice
    if [ ! -z "$input_choice" ];then
        cd $wp/shadowsocksr && python mujson_mgr.py -d -u $(echo "$ssr_ports" | tr "\n" " " | awk '{print $'$input_choice'}') >/dev/null 2>&1
        if grep -q "transfer_enable" mudb.json;then
            systemctl restart ssr.service
        else
            systemctl stop ssr.service
        fi
    fi
}

change_passport() {
    var=1
    for Echo in $ssr_ports;do
        echo -e " $var. 更改\033[33m$Echo\033[0m端口密码"
        ((var++))
    done
    echo
    colorRead ${YELLOW} "请选择" input_choice
    if [ ! -z "$input_choice" ];then
            colorRead ${YELLOW} "请设置密码[默认随机]" Passport
        [ -z "$Passport" ] && Passport=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)

        cd $wp/shadowsocksr
        python mujson_mgr.py -e -u $(echo "$ssr_ports" | tr "\n" " " | awk '{print $'$input_choice'}') -k $Passport >/dev/null 2>&1
        systemctl restart ssr.service
    fi
}

show_config() {
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    for K in ${ssr_ports};do
        SSR=$(cd $wp/shadowsocksr && python mujson_mgr.py -l -u $K | sed -n '$p' | sed 's|^[ \t]*||')
        Passport=$(cd $wp/shadowsocksr && python mujson_mgr.py -l -u $K | sed -n "5p" | awk '{print $3}')
        printf "\033[36m%11s \033[33m%-s\033[0m\n" "服务IP:" "$public_ip"
        printf "\033[36m%13s \033[33m%-s\033[0m\n" "服务端口:" "$K"
        printf "\033[36m%11s \033[33m%-s\033[0m\n" "密码:" "$Passport"
        printf "\033[36m%13s \033[33m%-s\033[0m\n" "加密方法:" "chacha20"
        printf "\033[36m%11s \033[33m%-s\033[0m\n" "协议:" "auth_sha1_v4"
        printf "\033[36m%13s \033[33m%-s\033[0m\n" "混淆方式:" "http_simple"
        echo
        printf "\033[36m%9s \033[33m%-s\033[0m\n" "SSR:" "$SSR"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    done
}

panel(){
    ssr_status="" && systemctl is-active -q ssr.service && ssr_status="$GREEN"
    ssr_ports=$(cd $wp/shadowsocksr && python mujson_mgr.py -l | awk '{print $4}')
    connections=""
    for Port in $ssr_ports;do
        connection=$(echo -e "[\033[33m$Port\033[0m ${GREEN}$(ss -o state established sport = :$Port | awk '{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l)\033[0m]")
        connections="$connection $connections"
    done
    var=1

    show_config
    echo
    echo -e "[\033[33m端口\033[0m ${GREEN}连接数\033[0m] $connections"
    echo
    if [ -z "$ssr_status" ];then
        echo -e "  $var. 开/关${RED}ssr\033[0m" && ((var++))
    else
        echo -e "  $var. 开/关${ssr_status}ssr\033[0m" && ((var++))
    fi
    echo "  $var. 卸载ssr" && ((var++))
    echo "  $var. 添加一个端口" && ((var++))
    echo "  $var. 删除一个端口" && ((var++))
    echo "  $var. 更改端口密码" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "$ssr_status" = "$GREEN" ];then
                systemctl stop ssr.service
                systemctl disable ssr.service
            elif grep -q "transfer_enable" $wp/shadowsocksr/mudb.json;then
                systemctl start ssr.service
                systemctl enable ssr.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        2)
            read
            bash $wp/uninstall.sh
            clear && echo "ssr已卸载！"
            ;;
        3)
            add_port
            clear && panel
            ;;
        4)
            del_port
            clear && panel
            ;;
        5)
            change_passport
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -q "^##" $0;then
    public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
else
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i '$a##'$public_ip'' $0
fi

clear && panel
