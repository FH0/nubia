#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/ssr_jzdh"
. $wp/functions.sh

method=${method:-chacha20}
obfs=${obfs:-http_simple}
protocol=${protocol:-auth_sha1_v4}

add_port() {
    colorRead ${YELLOW} "请设置端口[默认随机]" Port
    [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
    colorRead ${YELLOW} "请设置密码[默认随机]" Passport
    [ -z "$Passport" ] && Passport=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
    colorRead ${YELLOW} "请设置流量[单位G][默认999]" Trafic
    [ -z "$Trafic" ] && Trafic=999

    cd $wp/shadowsocksr
    python mujson_mgr.py -a -u $Port -p $Port -k $Passport -m $method -O $protocol -o $obfs -t $Trafic >/dev/null 2>&1
    start_service start ssr
}

del_port() {
    grep -q "transfer_enable" $wp/shadowsocksr/mudb.json || return
	var=1
    for Echo in $ssr_ports;do
        echo -e " $var. 删除${YELLOW}$Echo${BLANK}端口"
        ((var++))
    done
    echo
    colorRead ${YELLOW} "请选择" input_choice
    if [ ! -z "$input_choice" ];then
        cd $wp/shadowsocksr && python mujson_mgr.py -d -u $(echo "$ssr_ports" | tr "\n" " " | awk '{print $'$input_choice'}') >/dev/null 2>&1
        if grep -q "transfer_enable" mudb.json;then
            start_service start ssr
        else
            stop_service stop ssr
        fi
    fi
}

change_passport() {
    var=1
    for Echo in $ssr_ports;do
        echo -e " $var. 更改${YELLOW}$Echo${BLANK}端口密码"
        ((var++))
    done
    echo
    colorRead ${YELLOW} "请选择" input_choice
    if [ ! -z "$input_choice" ];then
		colorRead ${YELLOW} "请设置密码[默认随机]" Passport
        [ -z "$Passport" ] && Passport=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)

        cd $wp/shadowsocksr
        python mujson_mgr.py -e -u $(echo "$ssr_ports" | tr "\n" " " | awk '{print $'$input_choice'}') -k $Passport >/dev/null 2>&1
        start_service start ssr
    fi
}

show_config() {
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${BLANK}"
    for K in ${ssr_ports};do
        SSR=$(cd $wp/shadowsocksr && python mujson_mgr.py -l -u $K | sed -n '$p' | sed 's|^[ \t]*||')
        Passport=$(cd $wp/shadowsocksr && python mujson_mgr.py -l -u $K 2>&1 | sed -n "5p" | awk '{print $3}')
        Method=$(cd $wp/shadowsocksr && python mujson_mgr.py -l -u $K 2>&1 | grep 'method ' | awk '{print $3}')
        Protocol=$(cd $wp/shadowsocksr && python mujson_mgr.py -l -u $K 2>&1 | grep 'protocol ' | awk '{print $3}')
        Obfs=$(cd $wp/shadowsocksr && python mujson_mgr.py -l -u $K 2>&1 | grep 'obfs ' | awk '{print $3}')
        printf "${BLUE}%11s ${YELLOW}%-s${BLANK}\n" "服务IP:" "$public_ip"
        printf "${BLUE}%13s ${YELLOW}%-s${BLANK}\n" "服务端口:" "$K"
        printf "${BLUE}%11s ${YELLOW}%-s${BLANK}\n" "密码:" "$Passport"
        printf "${BLUE}%13s ${YELLOW}%-s${BLANK}\n" "加密方法:" "$Method"
        printf "${BLUE}%11s ${YELLOW}%-s${BLANK}\n" "协议:" "$Protocol"
        printf "${BLUE}%13s ${YELLOW}%-s${BLANK}\n" "混淆方式:" "$Obfs"
        echo
        printf "${BLUE}%9s ${YELLOW}%-s${BLANK}\n" "SSR:" "$SSR"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    done
}

catLL(){
    printf "%-13s %-13s %-14s %-13s\n" "端口" "总计" "已使用" "剩余"
    for K in ${ssr_ports};do
	    selectLine=$(grep -n '"user": "'$K'"' $wp/shadowsocksr/mudb.json | awk -F ':' '{print $1}')
        totalLL=$(sed -n "$(($selectLine-2))p" $wp/shadowsocksr/mudb.json | awk '{print $2}' | awk -F ',' '{print $1}')
        totalLL=$(($totalLL/1024/1024/1024))
        upLL=$(sed -n "$(($selectLine-1))p" $wp/shadowsocksr/mudb.json | awk '{print $2}' | awk -F ',' '{print $1}')
        downLL=$(sed -n "$(($selectLine-9))p" $wp/shadowsocksr/mudb.json | awk '{print $2}' | awk -F ',' '{print $1}')
        usedLL=$(($upLL+$downLL))
        usedLL=$(($usedLL/1024/1024/1024))
        leftLL=$(($totalLL-$usedLL))
        printf "%-11s %-11s %-11s %-11s\n\n" "$K" "${totalLL}G" "${usedLL}G" "${leftLL}G"
    done
}

panel(){
    public_ip=$(ip_info get_ip)
    ssr_status="${RED}" && ps -ef | grep -q " server\.py m" && ssr_status="$GREEN"
    ssr_ports=$(cd $wp/shadowsocksr && python mujson_mgr.py -l | awk '{print $4}')
    connections=""
    for Port in $ssr_ports;do
        connection=$(echo -e "[${YELLOW}$Port ${GREEN}$(get_connections $Port)${BLANK}]")
        connections="$connection $connections"
    done
    var=1

    show_config
    echo
    echo -e "[${YELLOW}端口 ${GREEN}连接数${BLANK}] $connections"
    echo
    echo -e "  $var. 开/关${ssr_status}ssr${BLANK}" && ((var++))
    echo "  $var. 卸载ssr" && ((var++))
    echo "  $var. 添加一个端口" && ((var++))
    echo "  $var. 删除一个端口" && ((var++))
    echo "  $var. 更改端口密码" && ((var++))
    echo "  $var. 查看流量使用情况" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "$ssr_status" = "$GREEN" ];then
                stop_service stop ssr
            elif grep -q "transfer_enable" $wp/shadowsocksr/mudb.json;then
                start_service start ssr
            fi
            clear && panel
            ;;
        2)
            read
            bash $wp/uninstall.sh
            clear && echo "ssr已卸载！"
            ;;
        3)
            add_port
            clear && panel
            ;;
        4)
            del_port
            clear && panel
            ;;
        5)
            change_passport
            clear && panel
            ;;
        6)
            catLL
            panel
            ;;
		*)
            clear && exit 0
            ;;
    esac
}

clear && panel
