#!/bin/bash
wp="/usr/local/frps"
. $wp/functions.sh

install_frp() {
    chmod -R 777 $wp

    color_println "cyan" "正在安装 frp 控制面板..."
    ip_info init
    cp $wp/manage_panel.sh /bin/frp

    color_println "cyan" "正在初始化配置文件..."
    Port=$(random_port)
    token=$(random_password 6)
    echo -e "[common]\nbind_port = $Port\ntoken = $token" >$wp/frps.ini

    color_println "cyan" "正在启动 frp..."
    start_service
}

main() {
    install_frp
    color_println "green" "frp 安装完成！输入 frp 可进入控制面板！"
}

main
