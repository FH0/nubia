#!/bin/bash
wp="/usr/local/trojan-server"
. $wp/functions.sh

install() {
    color_println "cyan" "正在下载最新核心 ..."
    suffix=$(curl -L 'https://github.com/trojan-gfw/trojan/releases/latest' | grep -m1 -Eo '[^"]+\-linux-amd64.tar.xz')
    curl -L "https://github.com$suffix" | tar xJ -C $wp trojan/trojan --strip-components=1

    chmod -R 777 $wp

    color_println "cyan" "正在安装 trojan 控制面板 ..."
    ip_info init
    cp $wp/manage_panel.sh /bin/trojan
}

main() {
    package_need iproute2 net-tools
    install
    color_println "green" "trojan 安装完成！输入 trojan 进入控制面板！"
}

main
