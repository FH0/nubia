#!/bin/bash
wp="/usr/local/xray"
. $wp/functions.sh

install_xray() {
    latest_version=$(curl 'https://github.com/XTLS/Xray-core/releases/latest' | grep -Eo 'v[0-9]+(\.[0-9]+)+')
    colorEcho $BLUE "正在下载最新核心 $ARCH $latest_version ..."
    curl -OL "https://github.com/XTLS/Xray-core/releases/download/$latest_version/Xray-linux-64.zip"
    unzip -q -o Xray-linux-64.zip xray -d $wp
    rm -f Xray-linux-64.zip

    chmod -R 777 $wp

    colorEcho $BLUE "正在安装 xray 控制面板 ..."
    ip_info init
    cp $wp/manage_panel.sh /bin/xray

    colorEcho $BLUE "正在生成证书 ..."
    colorRead $YELLOW "请输入域名" domain
    # 检查是否和本机公网 IP 匹配
    if [ "$(dig $domain @8.8.8.8 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sed -n '2p')" != "$(ip_info get_ip)" ]; then
        colorEcho $RED "域名解析的地址与本机公网地址不匹配"
        exit 1
    fi
    # 安装 acme.sh
    uuid=$($wp/xray uuid)
    curl https://get.acme.sh | sh -s email=$uuid@example.com
    # 颁发证书
    $HOME/.acme.sh/acme.sh --issue -d $domain --webroot $(pwd) --standalone
    # 更新证书后重启 xray
    $HOME/.acme.sh/acme.sh --install-cert -d $domain --key-file $wp/$domain.key --fullchainpath $wp/$domain.cer --reloadcmd "$wp/run_ctl.sh start"

    colorEcho $BLUE "正在设置 xray ..."
    # 修改 UUID
    sed -i 's|"id".*|"id": "'$uuid'",|g' $wp/config.json
    # 修改证书路径
    sed -i 's|"certificateFile".*|"certificateFile": "'$wp/$domain.cer'",|g' $wp/config.json
    sed -i 's|"keyFile".*|"keyFile": "'$wp/$domain.key'"|g' $wp/config.json

    colorEcho $BLUE "正在启动 xray ..."
    start_service
}

main() {
    install_xray
    colorEcho $GREEN "xray 安装完成！输入 xray 进入控制面板！"
}

main
