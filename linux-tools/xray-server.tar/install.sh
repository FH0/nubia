#!/bin/bash
wp="/usr/local/xray-server"
. $wp/functions.sh

install_xray() {
    latest_version=$(curl -L 'https://github.com/XTLS/Xray-core/releases/latest' | grep -Eo 'v[0-9]+(\.[0-9]+)+' -m1)
    color_println "cyan" "正在下载最新核心 $ARCH $latest_version ..."
    curl -OL "https://github.com/XTLS/Xray-core/releases/download/$latest_version/Xray-linux-64.zip"
    unzip -q -o Xray-linux-64.zip xray -d $wp
    rm -f Xray-linux-64.zip

    chmod -R 777 $wp

    color_println "cyan" "正在安装 xray 控制面板 ..."
    ip_info init
    cp $wp/manage_panel.sh /bin/xray
}

main() {
    package_need iproute2 net-tools
    install_xray
    color_println "green" "xray 安装完成！输入 xray 进入控制面板！"
}

main
