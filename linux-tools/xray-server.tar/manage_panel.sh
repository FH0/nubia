#!/bin/bash
wp="/usr/local/xray-server"
. $wp/functions.sh

panel() {
    public_ip=$(ip_info get_ip)
    color_status xray_status $wp/xray
    core_version=$($wp/xray version | sed -n "1p" | awk '{print $2}')
    ports=$(grep '"port"' $wp/config.json | grep -Eo '[0-9]+')
    connections=""
    for port in $ports; do
        connection=$(color_println "no_color" "[" "yellow" "$port " "green" "$(get_connections $port)]")
        connections="$connection $connections"
    done
    var=1

    cat $wp/config.json
    echo
    color_println "no_color" "公网地址: " "yellow" "$public_ip"
    color_println "no_color" "[" "yellow" "端口 " "green" "连接数] $connections"
    echo
    color_println "no_color" "  $((var++)). 开/关" "${xray_status}" " xray " "green" "$core_version"
    echo "  $((var++)). 卸载"
    echo "  $((var++)). 生成 UUID"
    echo "  $((var++)). 修改配置文件"
    echo "  $((var++)). 将 xtls 模板设置为配置文件"
    echo "  $((var++)). 将 http 模板设置为配置文件"
    echo "  $((var++)). 安装 acme.sh"
    echo "  $((var++)). 升级 acme.sh"
    echo "  $((var++)). 通过 acme.sh 签发证书然后复制到 xtls 模板指定的路径"
    echo "  $((var++)). 卸载 acme.sh"
    echo
    color_read "yellow" "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "$xray_status" = "green" ]; then
            stop_service
        else
            start_service
        fi
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            bash $wp/uninstall.sh
            clear && echo "xray 已卸载！"
        else
            clear && panel
        fi
        ;;
    $((var++)))
        $wp/xray uuid
        panel
        ;;
    $((var++)))
        vi $wp/config.json
        start_service
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            cat $wp/xtls.json >$wp/config.json
            panel
        else
            clear && panel
        fi
        ;;
    $((var++)))
        if warning_read; then
            cat $wp/http.json >$wp/config.json
            panel
        else
            clear && panel
        fi
        ;;
    $((var++)))
        color_read "yellow" "请输入邮箱（绑定以后签发的证书，方便找回等）" email
        curl https://get.acme.sh | sh -s email=$email
        panel
        ;;
    $((var++)))
        $HOME/.acme.sh/acme.sh --upgrade
        panel
        ;;
    $((var++)))
        color_read "yellow" "请输入域名（域名必须解析为本机的公网地址）" domain
        $HOME/.acme.sh/acme.sh --issue --standalone -d $domain --server letsencrypt
        $HOME/.acme.sh/acme.sh --install-cert -d $domain \
            --key-file $wp/private.key \
            --fullchain-file $wp/fullchain.crt
        panel
        ;;
    $((var++)))
        if warning_read; then
            $HOME/.acme.sh/acme.sh --uninstall
            panel
        else
            clear && panel
        fi
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
