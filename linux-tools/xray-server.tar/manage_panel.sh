#!/bin/bash
wp="/usr/local/xray-server"
. $wp/functions.sh

panel() {
    public_ip=$(ip_info get_ip)
    color_status xray_status $wp/xray
    core_version=$($wp/xray version | sed -n "1p" | awk '{print $2}')
    ports=$(grep '"port"' $wp/config.json | grep -Eo '[0-9]+')
    connections=""
    for port in $ports; do
        connection=$(color_println "no_color" "[" "yellow" "$port " "green" "$(get_connections $port)]")
        connections="$connection $connections"
    done
    var=1

    cat $wp/config.json
    echo
    color_println "no_color" "公网地址: " "yellow" "$public_ip"
    color_println "no_color" "[" "yellow" "端口 " "green" "连接数] $connections"
    echo
    color_println "no_color" "  $((var++)). 开/关" "${xray_status}" " xray " "green" "$core_version"
    echo "  $((var++)). 卸载"
    echo "  $((var++)). 修改配置文件"
    echo
    color_read "yellow" "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "$xray_status" = "green" ]; then
            stop_service
        else
            start_service
        fi
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            bash $wp/uninstall.sh
            clear && echo "xray 已卸载！"
        else
            clear && panel
        fi
        ;;
    $((var++)))
        vi $wp/config.json
        start_service
        clear && panel
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
