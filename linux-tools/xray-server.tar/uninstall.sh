#!/bin/bash
wp="/usr/local/xray-server"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/xray
