#!/bin/bash
wp="/usr/local/xray"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/xray
