#!/bin/bash
wp="/usr/local/xray"
. $wp/functions.sh

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
kill_path $wp/xray

if [ "$1" = "start" ]; then
    enable_tcp_fastopen
    for dport in $(grep '"port"' $wp/config.json | grep -Eo '[0-9]+'); do
        iptables -I INPUT -p tcp --dport $dport -m comment --comment "$wp" -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m comment --comment "$wp" -j ACCEPT
    done
    nohup $wp/xray >/dev/null 2>&1 &
fi
