#!/bin/bash
wp="/usr/local/smartdns"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/sns
