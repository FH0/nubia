#!/bin/bash
wp="/usr/local/smartdns"
. $wp/functions.sh

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
kill_path $wp/smartdns

if [ "$1" = "start" ]; then
    iptables -I INPUT -p udp --dport 53 -m comment --comment "$wp" -j ACCEPT
    nohup $wp/smartdns -c $wp/smartdns.conf -f &>/dev/null &
fi
