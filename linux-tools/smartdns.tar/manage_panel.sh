#!/bin/bash
wp="/usr/local/smartdns"
. $wp/functions.sh

change_dns() {
    color_read "yellow" '请输入 DNS 服务器地址' dns_addr
    [ -z "$dns_addr" ] && return 0
    sed -i "$1s|.*|server $dns_addr|" $wp/smartdns.conf
    start_service
}

panel() {
    public_ip=$(ip_info get_ip)
    color_status smartdns_status $wp/smartdns
    first_dns=$(sed -n '11p' $wp/smartdns.conf | awk '{print $2}')
    second_dns=$(sed -n '12p' $wp/smartdns.conf | awk '{print $2}')
    var=1

    echo
    color_println "no_color" "请将 DNS 设置为：" "yellow" "$public_ip"
    echo
    color_println "no_color" "  $((var++)). 开/关 " "$smartdns_status" " SmartDNS"
    echo "  $((var++)). 卸载 SmartDNS"
    color_println "no_color" "  $((var++)). 更改第一个 DNS 服务器  " "yellow" "$first_dns"
    color_println "no_color" "  $((var++)). 更改第二个 DNS 服务器  " "yellow" "$second_dns"
    echo
    color_read "yellow" "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "$smartdns_status" = "green" ]; then
            stop_service
        else
            start_service
        fi
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            bash $wp/uninstall.sh
            clear && echo "SmartDNS 已卸载！"
        else
            clear && panel
        fi
        ;;
    $((var++)))
        change_dns 11
        clear && panel
        ;;
    $((var++)))
        change_dns 12
        clear && panel
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
