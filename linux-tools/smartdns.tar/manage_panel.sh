#!/bin/bash
wp="/usr/local/smartdns"
. $wp/functions.sh

change_dns() {
    colorRead ${YELLOW} '请输入 DNS 服务器地址' dns_addr
    [ -z "$dns_addr" ] && return 0
	sed -i "$1s|.*|server $dns_addr|" $wp/smartdns.conf
    start_service
}

panel(){
    public_ip=$(ip_info get_ip)
	color_status smartdns_status $wp/smartdns
	first_dns=$(sed -n '11p' $wp/smartdns.conf | awk '{print $2}')
	second_dns=$(sed -n '12p' $wp/smartdns.conf | awk '{print $2}')
    var=1

    echo
    echo -e "请将 DNS 设置为：${YELLOW}$public_ip${BLANK}"
    echo
    echo -e "  $((var++)). 开/关${smartdns_status} SmartDNS${BLANK}"
    echo "  $((var++)). 卸载SmartDNS"
    echo -e "  $((var++)). 更改第一个 DNS 服务器  ${YELLOW}$first_dns$BLANK"
    echo -e "  $((var++)). 更改第二个 DNS 服务器  ${YELLOW}$second_dns$BLANK"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "$smartdns_status" = "$GREEN" ];then
                stop_service
            else
                start_service
            fi
            clear && panel
            ;;
        $((var++)) )
			if warning_read;then
				bash $wp/uninstall.sh
				clear && echo "SmartDNS已卸载！"
			else
				clear && panel
			fi
            ;;
        $((var++)) )
            change_dns 11
            clear && panel
            ;;
        $((var++)) )
            change_dns 12
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
