#!/bin/bash
wp="/usr/local/l_ygk"
. $wp/functions.sh

panel() {
    color_status ygk_status $wp/ygk
    version=$($wp/ygk | sed -n '1p' | awk '{print $2}' | awk -F':' '{print $2}')
    var=1

    cat $wp/ygk.json
    echo
    color_println "no_color" "  $var. 开/关  " "$ygk_status" "l_ygk $version" && ((var++))
    echo "  $var. 卸载 l_ygk" && ((var++))
    echo "  $var. 编辑配置文件" && ((var++))
    echo
    color_read "yellow" "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "$ygk_status" = "green" ]; then
            stop_service
        else
            start_service
        fi
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            bash $wp/uninstall.sh
            clear && echo "ygk 已卸载！"
        else
            clear && panel
        fi
        ;;
    $((var++)))
        vi $wp/ygk.json
        start_service
        clear && panel
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
