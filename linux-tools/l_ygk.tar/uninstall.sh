#!/bin/bash
wp="/usr/local/l_ygk"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/lk
