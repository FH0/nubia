#!/bin/bash
wp="/usr/local/l_ygk"
. $wp/functions.sh

install_ygk() {
    chmod -R 777 $wp

    color_println "cyan" "正在安装 ygk 控制面板..."
    cp $wp/manage_panel.sh /bin/lk

    color_println "cyan" "正在调整内核参数..."
    sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
    echo "net.ipv4.ip_forward = 1" >>/etc/sysctl.conf
    echo 1 >/proc/sys/net/ipv4/ip_forward

    color_println "cyan" "正在设置日志文件路径..."
    sed -i "s|log_file\".*|log_file\": \"$wp/ygk.log\",|" $wp/ygk.json

    color_println "cyan" "正在设置 tun_post ..."
    sed -i "s|tun_post\".*|tun_post\": \"$wp/tun_post.sh\"|" $wp/ygk.json
}

main() {
    cmd_need "hexdump"
    install_ygk
    color_println "green" "l_ygk 安装完成！输入 lk 可进入控制面板！"
}

main
