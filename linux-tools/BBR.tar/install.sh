#!/bin/bash
wp="/usr/local/BBR"
. $wp/functions.sh

install_bbr() {
    chmod -R 777 $wp

    color_println "cyan" "正在安装 BBR 控制面板..."
    cp $wp/manage_panel.sh /bin/bbr

    if ! lsmod | grep -q "bbr"; then
        if (($(uname -r | grep -Eo '^.') > 4)) || (uname -r | grep -q "^4" && (($(uname -r | awk -F "." '{print $2}') >= 9))); then
            return 0
        fi

        if [ -z "$(command -v yum)" ]; then
            color_println "cyan" "正在下载 4.16 内核..."
            curl -L -o 4.16.deb http://kernel.ubuntu.com/~kernel-ppa/mainline/v4.16/linux-image-4.16.0-041600-generic_4.16.0-041600.201804012230_amd64.deb
            color_println "cyan" "正在安装 4.16 内核..."
            dpkg -i 4.16.deb >/dev/null 2>&1
            rm -f 4.16.deb
        else
            color_println "cyan" "正在添加源支持..."
            rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org >/dev/null 2>&1
            rpm -Uvh http://www.elrepo.org/elrepo-release-7.0-3.el7.elrepo.noarch.rpm >/dev/null 2>&1
            color_println "cyan" "正在安装新内核..."
            yum --enablerepo=elrepo-kernel install kernel-ml -y >/dev/null 2>&1
            grub2-set-default 0
            grub2-mkconfig -o /boot/grub2/grub.cfg >/dev/null 2>&1
        fi
        color_println "green" "新内核安装完成！"
        color_println "yellow" "请重启系统，然后进入控制面板启用 BBR！"
    fi
}

main() {
    install_bbr
    color_println "green" "bbr 安装完成！输入 bbr 可进入控制面板！"
}

main
