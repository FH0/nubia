#!/bin/bash
wp="/usr/local/BBR"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

panel() {
    var=1
    bbr_status="" && lsmod | grep -q "bbr" && bbr_status="$GREEN"

    echo
    echo -e "  $var. 开/关${bbr_status} BBR\033[0m" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "$bbr_status" = "$GREEN" ];then
				sed -i '/net.core.default_qdisc/d' /etc/sysctl.conf 
				sed -i '/net.ipv4.tcp_congestion_control/d' /etc/sysctl.conf 
				colorEcho $GREEN "重启后即可关闭 BBR"
			else
				sed -i '/^net.core.default_qdisc=fq$/d' /etc/sysctl.conf
				sed -i '/^net.ipv4.tcp_congestion_control=bbr$/d' /etc/sysctl.conf
				echo "net.core.default_qdisc=fq" >> /etc/sysctl.conf
				echo "net.ipv4.tcp_congestion_control=bbr" >> /etc/sysctl.conf
				sysctl -p >/dev/null 2>&1
				colorEcho $GREEN "BBR 启用成功！"
            fi
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
