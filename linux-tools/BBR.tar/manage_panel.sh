#!/bin/bash
wp="/usr/local/BBR"
. $wp/functions.sh

panel() {
    var=1
    bbr_status="red" && lsmod | grep -q "bbr" && bbr_status="green"

    echo
    color_println "no_color" "  $var. 开/关 " "$bbr_status" " BBR" && ((var++))
    echo
    color_read "yellow" "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "$bbr_status" = "green" ]; then
            sed -i '/net.core.default_qdisc/d' /etc/sysctl.conf
            sed -i '/net.ipv4.tcp_congestion_control/d' /etc/sysctl.conf
            color_println "yellow" "重启后即可关闭 BBR"
        else
            sed -i '/net.core.default_qdisc=fq/d' /etc/sysctl.conf
            sed -i '/net.ipv4.tcp_congestion_control=bbr/d' /etc/sysctl.conf
            echo "net.core.default_qdisc=fq" >>/etc/sysctl.conf
            echo "net.ipv4.tcp_congestion_control=bbr" >>/etc/sysctl.conf
            sysctl -p >/dev/null 2>&1
            color_println "yellow" "BBR 启用成功！"
        fi
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
