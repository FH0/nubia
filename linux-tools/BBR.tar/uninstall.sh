#!/bin/bash
wp="/usr/local/BBR"
