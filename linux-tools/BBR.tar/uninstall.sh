#!/bin/bash
wp="/usr/local/swapfile"
