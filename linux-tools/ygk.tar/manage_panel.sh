#!/bin/bash
wp="/usr/local/ygk"
. $wp/functions.sh

panel() {
    color_status ygk_status $wp/ygk
    version=$($wp/ygk | sed -n '1p' | awk '{print $2}' | awk -F':' '{print $2}')
	public_ip=$(ip_info get_ip)
    ports=$(grep "port" $wp/ygk.json | grep -Eo "[0-9]*")
    connections=""
    for Port in $ports;do
        connection=$(echo -e "[${YELLOW}$Port ${GREEN}$(get_connections $Port)${BLANK}]")
        connections="$connection $connections"
    done
    var=1

    cat $wp/ygk.json
    echo
    echo -e "公网地址: ${YELLOW}$public_ip${BLANK}"
    echo -e "[${YELLOW}端口 ${GREEN}连接数${BLANK}] $connections"
    echo
    echo -e "  $var. 开/关${ygk_status}ygk $version${BLANK}" && ((var++))
    echo "  $var. 卸载ygk" && ((var++))
    echo "  $var. 编辑配置文件" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "$ygk_status" = "$GREEN" ]; then
            stop_service
        else
            start_service
        fi
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            bash $wp/uninstall.sh
            clear && echo "ygk已卸载！"
        else
            clear && panel
        fi
        ;;
    $((var++)))
        vi $wp/ygk.json
        start_service
        clear && panel
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
