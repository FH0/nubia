change_to_the_current_directory() {
    cd $(dirname $0)
}

color_print() {
    awk '
    function red_exit(output) {
        output = escape_string(output)
        printf("%s%s%s", colors["red"], output, colors["no_color"])
        exit 1
    }

    # parameters are local variables
    function escape_string(input, i, c, output) {
        output = ""

        for(;;) {
            i = match(input, /\\/)
            if(i == 0) {
                break
            }

            output = output substr(input, 0, i - 1)

            c = substr(input, i + 1, 1)
            if(c == "a") {
                output = output "\a"
            } else if (c == "b") {
                output = output "\b"
            } else if (c == "f") {
                output = output "\f"
            } else if (c == "n") {
                output = output "\n"
            } else if (c == "r") {
                output = output "\r"
            } else if (c == "t") {
                output = output "\t"
            } else if (c == "v") {
                output = output "\v"
            } else {
                output = output c
            }

            input = substr(input, i + 2)
        }
        output = output input

        return output
    }
    
    BEGIN {
        colors["no_color"] = "\033[0m"
        colors["black"] = "\033[0;30m"
        colors["red"] = "\033[0;31m"
        colors["green"] = "\033[0;32m"
        colors["orange"] = "\033[0;33m"
        colors["blue"] = "\033[0;34m"
        colors["purple"] = "\033[0;35m"
        colors["cyan"] = "\033[0;36m"
        colors["light_gray"] = "\033[0;37m"
        colors["dark_gray"] = "\033[1;30m"
        colors["light_red"] = "\033[1;31m"
        colors["light_green"] = "\033[1;32m"
        colors["yellow"] = "\033[1;33m"
        colors["light_blue"] = "\033[1;34m"
        colors["light_purple"] = "\033[1;35m"
        colors["light_cyan"] = "\033[1;36m"
        colors["white"] = "\033[1;37m"

        if(ARGC < 3 || ARGC % 2 == 0) {
            red_exit("The number of parameters must be no less than 3 and an odd number.\n")
        }
        
        for(i = 1; i < ARGC; i += 2) {
            color = ARGV[i]
            output = ARGV[i + 1]

            # default no_color
            if (color == "") {
                color = "no_color"
            }

            # check color exists
            if(!(color in colors)) {
                red_exit("invalid color: " color "\n")
            }

            # color print
            output = escape_string(output)
            printf("%s%s%s", colors[color], output, colors["no_color"])
        }

        exit 0
    }' "$@"
}

color_println() {
    color_print "$@\n"
}

color_read() {
    color=$1
    output="$2"
    varaible="$3"

    color_print "$color" "$output: "
    if echo "$SHELL" | grep -q "bash"; then
        read -e $varaible </dev/tty
    else
        read $varaible </dev/tty
    fi
}

column_align() {
    output="$1"
    split="${2:- }" # default space

    printf "$output" | awk -F "$split" '{
        for(j = 0; j < NF; j++) {
            arr[NR - 1, j] = $(j + 1)
            len[j] = length(arr[NR - 1, j]) > len[j] ? length(arr[NR - 1, j]) : len[j]
        }
    }
    END {
        for(i = 0; i < NR; i++) {
            for(j = 0; j < NF - 1; j++) {
                printf("%-*s  ", len[j], arr[i, j])
            }
            printf("%-*s\n", len[j], arr[i, NF - 1])
        }
    }'
}

bytes_readable() {
    awk 'BEGIN {
        bytes = ARGV[1]
        ARGV[1] = ""

        unit = "BKMGTEPZY"

        while(bytes >= 1024) {
            bytes /= 1024
            unit = substr(unit, 2)
        }

        print(bytes, substr(unit, 1, 1))
    }' "$1"
}

# trap "kill_background" EXIT
kill_background() {
    kill $(jobs -p) >/dev/null 2>&1
}

get_connections() {
    port=$1
    if command -v ss >/dev/null 2>&1; then
        ss -tun state established sport = :$port | awk '{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l
    elif command -v netstat >/dev/null 2>&1; then
        netstat -tun | awk '$4~/:'$port'$/ && $6~/ESTABLISHED/{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l
    else
        color_println "red" "缺少 ss 或 netstat 命令"
        exit 1
    fi
}

ip_info() {
    if [ "$1" = "init" ]; then
        sed -i '/^##/d' $wp/manage_panel.sh
        tmp_data=$(curl -sL http://ip-api.com/json) ||
            tmp_data=$(curl -sL http://api.ipapi.com/check?access_key=d72b841ab430468491424731634bcbb2)
        echo -n "## " >>$wp/manage_panel.sh
        echo -n "$tmp_data" | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | tr '\n' ' ' >>$wp/manage_panel.sh
        echo "$tmp_data" | grep -Eo '"[A-Z][A-Z]"' | sed -n '$p' | awk -F '"' '{print $2}' >>$wp/manage_panel.sh
    elif [ "$1" = "get_ip" ]; then
        grep "^##" $wp/manage_panel.sh | awk '{print $2}'
    elif [ "$1" = "get_country" ]; then
        grep "^##" $wp/manage_panel.sh | awk '{print $3}'
    fi
}

stop_service() {
    systemctl stop ${wp##*/}.service
    $wp/run_ctl.sh stop
    if command -v systemctl >/dev/null 2>&1; then
        systemctl disable ${wp##*/}.service
        rm -f /etc/systemd/system/${wp##*/}.service
        systemctl daemon-reload
    else
        if [ -e "/etc/rc.d/rc.local" ]; then
            rcFile="/etc/rc.d/rc.local"
        elif [ -f "/etc/rc.local" ]; then
            rcFile="/etc/rc.local"
        else
            return
        fi
        tmp_echo=$(grep -v "$wp/run_ctl.sh" $rcFile)
        echo "$tmp_echo" >$rcFile
    fi
} >/dev/null 2>&1

start_service() {
    $wp/run_ctl.sh start
    if command -v systemctl >/dev/null 2>&1; then
        echo -e "[Unit]\nDescription=$wp\nAfter=network.target\n\n[Service]\nType=forking\nExecStart=$wp/run_ctl.sh start\nRestart=always\n\n[Install]\nWantedBy=multi-user.target" >/etc/systemd/system/${wp##*/}.service
        systemctl daemon-reload
        systemctl enable ${wp##*/}.service
    else
        if [ -e "/etc/rc.d/rc.local" ]; then
            rcFile="/etc/rc.d/rc.local"
        elif [ -f "/etc/rc.local" ]; then
            rcFile="/etc/rc.local"
        else
            return
        fi

        tmp_echo=$(grep -v "^exit" $rcFile)
        echo "$tmp_echo" >$rcFile
        echo "if [ -f \"$wp/run_ctl.sh\" ]; then $wp/run_ctl.sh start; else echo \"\$(grep -v $wp/run_ctl.sh \$0)\" >\$0; fi" >>$rcFile
        echo "exit 0" >>$rcFile
    fi
} >/dev/null 2>&1

enable_tcp_fastopen() {
    if [ -e "/proc/sys/net/ipv4/tcp_fastopen" ]; then
        echo 3 >/proc/sys/net/ipv4/tcp_fastopen
    fi
    if [ -e "/proc/sys/net/ipv6/tcp_fastopen" ]; then
        echo 3 >/proc/sys/net/ipv6/tcp_fastopen
    fi
}

cmd_need() {
    update_flag=0
    exit_flag=0

    for cmd in $1; do
        if ! command -v $cmd >/dev/null 2>&1; then
            # check if auto install
            if command -v apt >/dev/null 2>&1; then
                # apt install package need update first
                if [ "update_flag" = "0" ]; then
                    apt update >/dev/null 2>&1
                    update_flag=1
                fi

                package=$(dpkg -S bin/$cmd 2>&1 | grep "bin/$cmd$" | awk -F':' '{print $1}')
                if [ ! -z "$package" ]; then
                    color_println "cyan" "正在安装 $cmd ..."
                    apt install $package -y >/dev/null 2>&1
                    continue
                fi
            elif command -v yum >/dev/null 2>&1; then
                package=$(yum whatprovides *bin/$cmd 2>&1 | grep " : " | awk -F' : ' '{print $1}' | sed -n '1p')
                if [ ! -z "$package" ]; then
                    color_println "cyan" "正在安装 $cmd ..."
                    yum install $package -y >/dev/null 2>&1
                    continue
                fi
            fi

            color_println "red" "找不到 $cmd 命令"
            exit_flag=1
        fi
    done

    if [ "$exit_flag" = "1" ]; then
        exit 1
    fi
}

random_password() {
    password_len=${1:-12}
    cat /dev/urandom | tr -dc a-zA-Z0-9 | head -c $password_len
}

random_port() {
    while true; do
        port=$(cat /dev/urandom | tr -dc 0-9 | head -c 5 | sed 's|^0*||g')

        ! [ "$port" -gt "1024" -a "$port" -lt "65536" ] && continue

        if command -v ss >/dev/null 2>&1; then
            if ss -ltun | awk '{print $5}' | grep -q ":$port\$"; then
                continue
            else
                printf "$port"
                break
            fi
        elif command -v netstat >/dev/null 2>&1; then
            if netstat -tun | awk '{print $4}' | grep -q ":$port\$"; then
                continue
            else
                printf "$port"
                break
            fi
        else
            color_println "red" "缺少 ss 或 netstat 命令"
            exit 1
        fi
    done
}

warning_read() {
    read -n1 -p "输入 Y 或 y 确认操作，否则取消：" yn
    if ! echo "$yn" | grep -qE "[Yy]"; then
        exit 0
    fi
}

color_status() {
    eval $1="red"
    for check_cmd in ${@:2}; do
        pgrep -f $check_cmd || return 1
    done
    eval $1="green"
} >/dev/null 2>&1

kill_path() {
    kill -9 $(pgrep -f $1)
}
