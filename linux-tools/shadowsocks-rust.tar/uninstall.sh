#!/bin/bash
wp="/usr/local/shadowsocks-rust"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/ssrs
