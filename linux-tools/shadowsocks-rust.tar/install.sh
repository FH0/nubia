#!/bin/bash
wp="/usr/local/shadowsocks-rust"
. $wp/functions.sh

install_shadowsocks-rust() {
    latestVersion=$(curl https://github.com/shadowsocks/shadowsocks-rust/releases/latest | sed 's|.*tag/\(.*\)".*|\1|')
    if [ ! -z "$(uname -m | grep -E 'amd64|x86_64')" ]; then
        ARCH="x86_64-unknown-linux-musl"
    elif [ ! -z "$(uname -m | grep -E '86')" ]; then
        ARCH="i686-unknown-linux-musl"
    elif [ ! -z "$(uname -m | grep -E 'armv8|aarch64')" ]; then
        ARCH="aarch64-unknown-linux-musl"
    elif [ ! -z "$(uname -m | grep -E 'arm')" ]; then
        ARCH="arm-unknown-linux-musleabi"
    elif [ ! -z "$(uname -m | grep -E 'mips64')" ]; then
        # check little/big endian 0->big 1->little
        if [ "$(echo -n I | hexdump -o | awk '{ print substr($2,6,1); exit}')" == "1" ]; then
            ARCH="mips64el-unknown-linux-muslabi64"
        else
            ARCH="mips64-unknown-linux-muslabi64"
        fi
    elif [ ! -z "$(uname -m | grep -E 'mips')" ]; then
        # check little/big endian 0->big 1->little
        if [ "$(echo -n I | hexdump -o | awk '{ print substr($2,6,1); exit}')" == "1" ]; then
            ARCH="mipsel-unknown-linux-musl"
        else
            ARCH="mips-unknown-linux-musl"
        fi
    else
        color_println "red" "不支持的系统架构！"
        bash $wp/uninstall.sh >/dev/null 2>&1
        exit 1
    fi
    color_println "cyan" "正在下载最新核心 $ARCH $latestVersion ..."
    curl -L "https://github.com/shadowsocks/shadowsocks-rust/releases/download/$latestVersion/shadowsocks-$latestVersion.$ARCH.tar.xz" | tar xJ -C $wp ssserver

    chmod -R 777 $wp

    color_println "cyan" "正在安装 shadowsocks-rust 控制面板 ..."
    ip_info init
    cp $wp/manage_panel.sh /bin/ssrs

    color_println "cyan" "正在设置随机端口 ..."
    random=$(random_port)
    sed -i "s|port.*|port\": $random,|" $wp/config.json

    color_println "cyan" "正在设置随机密码 ..."
    random=$(random_password 6)
    sed -i "s|password.*|password\": \"$random\",|" $wp/config.json

    color_println "cyan" "正在启动 shadowsocks-rust ..."
    start_service
}

main() {
    cmd_need "hexdump"
    install_shadowsocks-rust
    color_println "green" "shadowsocks-rust 安装完成！输入 ssrs 可进入控制面板！"
}

main
