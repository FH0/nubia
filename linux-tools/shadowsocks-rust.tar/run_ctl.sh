#!/bin/bash
wp="/usr/local/shadowsocks-rust"
. $wp/functions.sh

bash <(iptables -S | grep "${wp}" | sed "s|^..|iptables -D|g")
kill_path $wp/ssserver 

if [ "$1" = "start" ]; then
	for port in $(grep "port" $wp/config.json | awk -F ':' '{print $NF}' | grep -Eo "[0-9]*"); do
		iptables -I INPUT -p tcp --dport $port -m comment --comment "${wp}" -j ACCEPT
	done

	nohup $wp/ssserver -c $wp/config.json >/dev/null 2>&1 &
fi
