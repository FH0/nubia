#!/bin/bash
wp="/usr/local/shadowsocks-rust"
. $wp/functions.sh

panel() {
    color_status ss_status $wp/ssserver
    version=$($wp/ssserver --help | sed -n '1p' | awk '{print $2}')
    public_ip=$(ip_info get_ip)
    ports=$(grep "port" $wp/config.json | awk -F ':' '{print $NF}' | grep -Eo "[0-9]*")
    connections=""
    for Port in $ports; do
        connection=$(color_println "no_color" "[" "yellow" "$Port " "green" "$(get_connections $Port)]")
        connections="$connection $connections"
    done
    var=1

    cat $wp/config.json
    echo
    color_println "no_color" "公网地址: " "yellow" "$public_ip"
    color_println "no_color" "[" "yellow" "端口 " "green" "连接数] $connections"
    echo
    color_println "no_color" "  $var. 开/关 " "$ss_status" " shadowsocks-rust $version" && ((var++))
    echo "  $var. 卸载 shadowsocks-rust" && ((var++))
    echo "  $var. 编辑配置文件" && ((var++))
    echo
    color_read "yellow" "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "$ss_status" = "green" ]; then
            stop_service
        else
            start_service
        fi
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            bash $wp/uninstall.sh
            clear && echo "shadowsocks-rust 卸载完成！"
        else
            clear && panel
        fi
        ;;
    $((var++)))
        vi $wp/config.json
        start_service
        clear && panel
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
