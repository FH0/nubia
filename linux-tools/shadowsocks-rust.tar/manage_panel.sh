#!/bin/bash
wp="/usr/local/shadowsocks-rust"
. $wp/functions.sh

panel() {
    color_status ss_status $wp/ssserver
    version=$($wp/ssserver --help | sed -n '1p' | awk '{print $2}')
    public_ip=$(ip_info get_ip)
    ports=$(grep "port" $wp/config.json | awk -F ':' '{print $NF}' | grep -Eo "[0-9]*")
    connections=""
    for Port in $ports; do
        connection=$(echo -e "[${YELLOW}$Port ${GREEN}$(get_connections $Port)${BLANK}]")
        connections="$connection $connections"
    done
    var=1

    cat $wp/config.json
    echo
    echo -e "公网地址: ${YELLOW}$public_ip${BLANK}"
    echo -e "[${YELLOW}端口 ${GREEN}连接数${BLANK}] $connections"
    echo
    echo -e "  $var. 开/关${ss_status} shadowsocks-rust $version${BLANK}" && ((var++))
    echo "  $var. 卸载 shadowsocks-rust" && ((var++))
    echo "  $var. 编辑配置文件" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
    $((var++)))
        if [ "$ss_status" = "$GREEN" ]; then
            stop_service
        else
            start_service
        fi
        clear && panel
        ;;
    $((var++)))
        if warning_read; then
            bash $wp/uninstall.sh
            clear && echo "shadowsocks-rust 卸载完成！"
        else
            clear && panel
        fi
        ;;
    $((var++)))
        vi $wp/config.json
        start_service
        clear && panel
        ;;
    *)
        clear && exit 0
        ;;
    esac
}

clear && panel
