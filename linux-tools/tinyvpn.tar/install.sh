#!/bin/bash
wp="/usr/local/tinyvpn"
. $wp/functions.sh

install_v2ray() {
    chmod -R 777 $wp

    color_println "cyan" "正在安装 tinyvpn-udp2raw 控制面板..."
    ip_info init
    cp $wp/manage_panel.sh /bin/tu

    color_println "cyan" "正在启动 tinyvpn-udp2raw..."
    echo "udp2raw $(random_port) $(random_password 8)" >$wp/tu.ini
    echo "tinyvpn $(random_port) $(random_password 8)" >>$wp/tu.ini
    start_service
}

main() {
    install_v2ray
    color_println "green" "tinyvpn-udp2raw 安装完成！输入 tu 可进入控制面板！"
}

main
