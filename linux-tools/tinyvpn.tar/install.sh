#!/bin/bash
wp="/usr/local/tinyvpn"
. $wp/functions.sh

install_v2ray(){
    chmod -R 777 $wp
    
    colorEcho $BLUE "正在安装 tinyvpn-udp2raw 控制面板..."
	ip_info init
    cp $wp/manage_panel.sh /bin/tu

    colorEcho $BLUE "正在启动 tinyvpn-udp2raw..."
	echo "udp2raw $(random_port) $(random_password 8)" >$wp/tu.ini
	echo "tinyvpn $(random_port) $(random_password 8)" >>$wp/tu.ini
	start_service
}

main(){
    install_v2ray
    colorEcho $GREEN "tinyvpn-udp2raw 安装完成！输入 tu 可进入控制面板！"
}

main
