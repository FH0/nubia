cd ${0%/*} && ./关闭.sh S

address=`cat config.json|grep address|grep ","|awk '{print $2}'|awk -F "\"" '{print $2}'`

iptables -t nat -N own
iptables -t nat -A own -d $address -j ACCEPT
iptables -t nat -A own -o lo -j ACCEPT
iptables -t nat -A own -p tcp -j REDIRECT --to 12345
iptables -t nat -I OUTPUT 1 -p tcp -j own

iptables -t nat -N hot
iptables -t nat -A hot -p tcp -j REDIRECT --to-ports 12345
iptables -t nat -A PREROUTING -p tcp -j hot

ip rule add fwmark 1 table 121
ip route add local 0.0.0.0/0 dev lo table 121

iptables -t mangle -N ownout
iptables -t mangle -A ownout -d 192.168.0.0/16 -j ACCEPT
iptables -t mangle -A ownout -p udp -j MARK --set-xmark 0x1
iptables -t mangle -I OUTPUT 1 -p udp -j ownout

iptables -t mangle -N hotpre
iptables -t mangle -A hotpre -d 0.0.0.0/8 -j ACCEPT
iptables -t mangle -A hotpre -d 10.0.0.0/8 -j ACCEPT
iptables -t mangle -A hotpre -d 127.0.0.0/8 -j ACCEPT
iptables -t mangle -A hotpre -d 169.254.0.0/16 -j ACCEPT
iptables -t mangle -A hotpre -d 172.16.0.0/12 -j ACCEPT
iptables -t mangle -A hotpre -d 192.168.0.0/16 -j ACCEPT
iptables -t mangle -A hotpre -d 224.0.0.0/4 -j ACCEPT
iptables -t mangle -A hotpre -d 240.0.0.0/4 -j ACCEPT
iptables -t mangle -A hotpre -p udp -j TPROXY --on-port 12345 --tproxy-mark 1
iptables -t mangle -I PREROUTING 1 -p udp -j hotpre

./v2ray -config config.json > /dev/null 2>&1 &

./检测.sh