cd ${0%/*}
echo
if [[ "`pgrep v2ray`" == "" ]];then
    echo '   ○ v2ray停止运行'
else
    echo '   ● v2ray正在运行'
fi
