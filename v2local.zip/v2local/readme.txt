
1.config.json仅需修改ip地址，端口，UUID和Host,小白请不要使用他人的v2搭建脚本

2.如果出现问题请重装服务器v2和到https://yaohuo.me/bbs-593923.html下载最新v2local

‌3.

4.服务器搭建脚本(不支持centos，请选择deb系)（默认开启80 8080端口且不能更改）:
apt-get install wget unzip -y;cd /root;wget --no-check-certificate https://github.com/FH0/nubia/raw/master/ssr_jzdh.zip;unzip ssr_jzdh.zip;bash ~/SSR-Bash-Python/jzdh.sh

5.安装过程中如果提示not found，请执行apt-get update -y

6.如果不能联网请停掉防火墙