cd ${0%/*} && chmod 0777 * && rm -f *bak

pkill v2ray

iptables -t nat -D PREROUTING -p tcp -j hot > /dev/null 2>&1
iptables -t nat -D OUTPUT -p tcp -j own > /dev/null 2>&1
iptables -t nat -F own > /dev/null 2>&1
iptables -t nat -F hot > /dev/null 2>&1
iptables -t nat -X own > /dev/null 2>&1
iptables -t nat -X hot > /dev/null 2>&1

iptables -t mangle -D PREROUTING -p udp -j hotpre > /dev/null 2>&1
iptables -t mangle -D OUTPUT -p udp -j ownout > /dev/null 2>&1
iptables -t mangle -F ownout > /dev/null 2>&1
iptables -t mangle -F hotpre > /dev/null 2>&1
iptables -t mangle -X ownout > /dev/null 2>&1
iptables -t mangle -X hotpre > /dev/null 2>&1

ip rule del fwmark 0x1 table 121 > /dev/null 2>&1
ip route del local 0.0.0.0/0 dev lo table 121 > /dev/null 2>&1

if [[ "$1" == "S" ]];then
    sleep 0
else
    ./检测.sh
fi