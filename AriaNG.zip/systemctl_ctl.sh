#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/AriaNG"

if [ "$1" = "aria2c" -a "$2" = "stop" ];then
    bash <(iptables -S | grep "${wp}/aria2c" | sed "s|-[AI] |-D |g;s|^|iptables |g")
    kill -9 $(ps -ef | grep "${wp}/aria2c" | sed -n "1p" | awk '{print $2}')
elif [ "$1" = "aria2c" -a "$2" = "start" ];then
    iptables -I INPUT -p tcp --dport 6800 -m string ! --string "${wp}/aria2c" --algo bm -j ACCEPT
    $wp/aria2c --conf-path=$wp/aria2.conf
elif [ "$1" = "nginx" -a "$2" = "stop" ];then
    bash <(iptables -S | grep "${wp}/nginx" | sed "s|-[AI] |-D |g;s|^|iptables |g")
    kill -9 $(ps -ef | grep "${wp}/nginx" | sed -n "1p" | awk '{print $2}')
else
    iptables -I INPUT -p tcp --dport $(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*") -m string ! --string "${wp}/nginx" --algo bm -j ACCEPT
    $wp/nginx -c $wp/nginx.conf
fi
