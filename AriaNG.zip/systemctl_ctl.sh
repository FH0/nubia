#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/AriaNG"

if [ "$1" = "aria2c" -a "$2" = "stop" ];then
    bash <(iptables -S | grep "${wp}/aria2c" | sed "s|^..|iptables -D|g")
    kill $(pgrep -f $wp/aria2c)
elif [ "$1" = "aria2c" -a "$2" = "start" ];then
    bash <(iptables -S | grep "${wp}/aria2c" | sed "s|^..|iptables -D|g")
    kill $(pgrep -f $wp/aria2c)
    iptables -I INPUT -p tcp --dport 6800 -m comment --comment "${wp}/aria2c" -j ACCEPT
	$wp/setcap cap_net_bind_service=+ep $wp/aria2c
	su -s /bin/bash nobody -c "$wp/aria2c -D --conf-path=$wp/aria2.conf"
elif [ "$1" = "nginx" -a "$2" = "stop" ];then
    bash <(iptables -S | grep "${wp}/nginx" | sed "s|^..|iptables -D|g")
    $wp/nginx -s quit -c $wp/nginx.conf
else
    bash <(iptables -S | grep "${wp}/nginx" | sed "s|^..|iptables -D|g")
    kill $(pgrep -f $wp/nginx)
    iptables -I INPUT -p tcp --dport $(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*") -m comment --comment "${wp}/nginx" -j ACCEPT
    $wp/nginx -c $wp/nginx.conf
fi
