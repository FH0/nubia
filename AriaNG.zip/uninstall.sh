#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/AriaNG"

systemctl stop ariang_nginx.service
systemctl disable ariang_nginx.service > /dev/null 2>&1
rm -f /etc/systemd/system/ariang_nginx.service
systemctl stop ariang_aria2c.service
systemctl disable ariang_aria2c.service > /dev/null 2>&1
rm -f /etc/systemd/system/ariang_aria2c.service
systemctl daemon-reload ; systemctl reset-failed

rm -rf $wp
rm -f /bin/ag

sed -i '/AriaNG_update\.sh/d' /etc/crontab
