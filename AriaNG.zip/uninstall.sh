#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/AriaNG"

$wp/systemctl_ctl.sh nginx stop >/dev/null 2>&1
$wp/systemctl_ctl.sh aria2c stop >/dev/null 2>&1

if command -v systemctl >/dev/null;then
    systemctl disable ariang_nginx.service > /dev/null 2>&1
    rm -f /etc/systemd/system/ariang_nginx.service
    systemctl disable ariang_aria2c.service > /dev/null 2>&1
    rm -f /etc/systemd/system/ariang_aria2c.service
    systemctl daemon-reload
	systemctl reset-failed
elif [ -e "/etc/rc.local" ];then
	tmp_echo=$(grep -v "$wp/systemctl_ctl.sh" /etc/rc.local)
	echo "$tmp_echo" > /etc/rc.local
fi

rm -rf $wp
rm -f /bin/ag

sed -i '/AriaNG_update\.sh/d' /etc/crontab
