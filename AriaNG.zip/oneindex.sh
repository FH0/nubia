#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/oneindex"

path=$3 #取原始路径，我的环境下如果是单文件则为/data/demo.png,如果是文件夹则该值为文件夹内某个文件比$
downloadpath='/usr/local/AriaNG/Download'  #修改成Aria2下载文件夹
folder=$(sed -n "1p" $wp/oneindex.ini)

if [ "$2" -eq 0 ];then
    exit 0
fi

while true;do  #提取下载文件根路径，如把/data/a/b/c/d.jpg变成/data/a
    filepath=$path
    path=${path%/*};
    if [ "$path" = "$downloadpath" ] && [ $2 -eq 1 ];then  #如果下载的是单个文件
        $wp/php $wp/oneindex/one.php upload:file $filepath /$folder
        rm -rf $filepath
        $wp/php $wp/oneindex/one.php cache:refresh
        exit 0
    elif [ "$path" = "$downloadpath" ];then
        $wp/php $wp/oneindex/one.php upload:folder $filepath /$folder
        rm -rf "$filepath/"
        $wp/php $wp/oneindex/one.php cache:refresh
        exit 0
    fi
done
