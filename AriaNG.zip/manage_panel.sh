#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/AriaNG"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

panel() {
    var=1
    Port=$(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*")
    Path=($(grep -n "location" $wp/nginx.conf))
    random_path=${Path[2]}
    download_path=${Path[6]}
    ariang_status="${RED}" && pgrep -f $wp/aria2c >/dev/null 2>&1 && pgrep -f $wp/nginx >/dev/null 2>&1 && ariang_status="$GREEN"
    system_storage=$(df -h | grep "/$" | awk '{print $4}')

    echo
    echo -e "    \033[36m剩余存储: \033[33m${system_storage}\033[0m"
    echo -e "  \033[36mAriaNG地址: \033[33mhttp://$public_ip:$Port$random_path\033[0m"
    echo -e "\033[36m下载页面地址: \033[33mhttp://$public_ip:$Port$download_path\033[0m"

    echo
    echo -e "  $var. 开/关${ariang_status}AriaNG\033[0m" && ((var++))
    echo "  $var. 设置网址端口" && ((var++))
    echo "  $var. 设置网址路径" && ((var++))
    echo "  $var. 卸载AriaNG" && ((var++))
    echo "  $var. 清空已下载文件" && ((var++))
    if [ -d "/usr/local/oneindex" ] && pgrep -f /usr/local/oneindex/php;then
        oneindex_status=$(sed -n "17p" $wp/aria2.conf | awk -F '=' '{print $2}')
        [ -z "$oneindex_status" ] || oneindex_status="$GREEN"
        Opath=$(sed -n "1p" $wp/oneindex.ini)
        echo -e "  $var. 开/关${oneindex_status}oneindex\033[0m自动上传" && ((var++))
        echo -e "  $var. 更改网盘路径 $YELLOW$Opath\033[0m" && ((var++))
	else
		sed -i "17s|.*|on-download-complete=|" $wp/aria2.conf
    fi
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "${GREEN}" = "$ariang_status" ];then
				$wp/systemctl_ctl.sh nginx stop
				$wp/systemctl_ctl.sh aria2c stop
				if command -v systemctl >/dev/null;then
					systemctl disable ariang_nginx.service
					systemctl disable ariang_aria2c.service
				elif [ -e "/etc/rc.local" ];then
					tmp_echo=$(grep -v "$wp/systemctl_ctl.sh" /etc/rc.local)
					echo "$tmp_echo" > /etc/rc.local
				fi
            else
				$wp/systemctl_ctl.sh nginx start
				$wp/systemctl_ctl.sh aria2c start
				if command -v systemctl >/dev/null;then
					systemctl enable ariang_nginx.service
					systemctl enable ariang_aria2c.service
				elif [ -e "/etc/rc.local" ];then
					tmp_echo=$(grep -Ev "^exit|$wp/systemctl_ctl.sh" /etc/rc.local)
					echo "$tmp_echo" > /etc/rc.local
					echo "$wp/systemctl_ctl.sh nginx start >/dev/null 2>&1" >> /etc/rc.local
					echo "$wp/systemctl_ctl.sh aria2c start >/dev/null 2>&1" >> /etc/rc.local
					echo "exit 0" >> /etc/rc.local
				fi
            fi >/dev/null 2>&1
            clear && panel
            ;;
        2)
            colorRead ${YELLOW} "请输入端口[默认随机]" Port
            [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
            web=$(grep -Eo 'href="http.*" target' $wp/index.html)
            web_=$(echo "$web" | sed 's|:[0-9][0-9]*|:'$Port'|')
            sed -i "s|$web|$web_|g" $wp/index.html
            sed -i "s|listen.*|listen       $Port;|" $wp/nginx.conf
			$wp/systemctl_ctl.sh nginx start >/dev/null 2>&1
			$wp/systemctl_ctl.sh aria2c start >/dev/null 2>&1
			if command -v systemctl >/dev/null;then
				systemctl enable ariang_nginx.service
				systemctl enable ariang_aria2c.service
			elif [ -e "/etc/rc.local" ];then
				tmp_echo=$(grep -Ev "^exit|$wp/systemctl_ctl.sh" /etc/rc.local)
				echo "$tmp_echo" > /etc/rc.local
				echo "$wp/systemctl_ctl.sh nginx start >/dev/null 2>&1" >> /etc/rc.local
				echo "$wp/systemctl_ctl.sh aria2c start >/dev/null 2>&1" >> /etc/rc.local
				echo "exit 0" >> /etc/rc.local
			fi >/dev/null 2>&1
            clear && panel
            ;;
        3)
            Path=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
            nginx_path=($(grep -n "location" $wp/nginx.conf))
            web=$(grep -Eo 'href="http.*" target' $wp/index.html)
            web_=$(echo "href=\"http://$public_ip:$Port/$Path/Download\" target")
            sed -i "s|$web|$web_|g" $wp/index.html
            sed -i "${nginx_path[0]%:}s|location.*|location /$Path {|" $wp/nginx.conf
            sed -i "${nginx_path[4]%:}s|location.*|location /$Path/Download {|" $wp/nginx.conf
			$wp/systemctl_ctl.sh nginx start >/dev/null 2>&1
			$wp/systemctl_ctl.sh aria2c start >/dev/null 2>&1
			if command -v systemctl >/dev/null;then
				systemctl enable ariang_nginx.service
				systemctl enable ariang_aria2c.service
			elif [ -e "/etc/rc.local" ];then
				tmp_echo=$(grep -Ev "^exit|$wp/systemctl_ctl.sh" /etc/rc.local)
				echo "$tmp_echo" > /etc/rc.local
				echo "$wp/systemctl_ctl.sh nginx start >/dev/null 2>&1" >> /etc/rc.local
				echo "$wp/systemctl_ctl.sh aria2c start >/dev/null 2>&1" >> /etc/rc.local
				echo "exit 0" >> /etc/rc.local
			fi >/dev/null 2>&1
            clear && panel
            ;;
        4)
            read
            bash $wp/uninstall.sh
            clear && echo "AriaNG已卸载！" && exit 0
            ;;
        5)
            read
            rm -rf $wp/Download/*
            clear && panel
            ;;
        6)
            if [ -d "/usr/local/oneindex" ];then
                if [ "${GREEN}" = "$oneindex_status" ];then
                    sed -i "17s|.*|on-download-complete=|" $wp/aria2.conf
                else
                    sed -i "17s|.*|on-download-complete=$wp/oneindex\.sh|" $wp/aria2.conf
                fi >/dev/null 2>&1
				$wp/systemctl_ctl.sh nginx start >/dev/null 2>&1
				$wp/systemctl_ctl.sh aria2c start >/dev/null 2>&1
				if command -v systemctl >/dev/null;then
					systemctl enable ariang_nginx.service
					systemctl enable ariang_aria2c.service
				elif [ -e "/etc/rc.local" ];then
					tmp_echo=$(grep -Ev "^exit|$wp/systemctl_ctl.sh" /etc/rc.local)
					echo "$tmp_echo" > /etc/rc.local
					echo "$wp/systemctl_ctl.sh nginx start >/dev/null 2>&1" >> /etc/rc.local
					echo "$wp/systemctl_ctl.sh aria2c start >/dev/null 2>&1" >> /etc/rc.local
					echo "exit 0" >> /etc/rc.local
				fi >/dev/null 2>&1
            fi
            clear && panel
            ;;
        7)
            if [ -d "/usr/local/oneindex" ];then
                colorRead ${YELLOW} "请输入路径[保留开头/]" Opath
                [ -z "$Opath" ] && clear && panel
                echo "$Opath" > $wp/oneindex.ini
            fi
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -qE "^##([0-9]{1,3}\.){3}[0-9]{1,3}" $0;then
    public_ip=$(ifconfig | grep 'inet ' | awk '{print $2}' | grep -Ev '^10\.|^192\.168|^172\.[1-3]|^127\.' | sed -n '1p')
    [ -z "$public_ip" ] && public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
else
    public_ip=$(curl -sL http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    [ -z "$JSON" ] || sed -i '$a##'$public_ip'' $0
fi

clear && panel
