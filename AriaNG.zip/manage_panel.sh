#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/AriaNG"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

panel() {
    var=1
    Port=$(sed -n '17p' $wp/nginx.conf | grep -Eo "[0-9]*")
    random_path=$(sed -n "21p" $wp/nginx.conf | sed 's|.*\(/.*\) .*|\1|')
    ariang_status="" && systemctl -q is-active ariang_nginx.service && systemctl -q is-active ariang_aria2c.service && ariang_status="$GREEN"
    system_storage=$(df -h | grep "/$" | awk '{print $4}')
    
    echo
    echo -e "    \033[36m剩余存储: \033[33m${system_storage}\033[0m"
    echo -e "  \033[36mAriaNG地址: \033[33mhttp://$public_ip:$Port$random_path\033[0m"
    if [ "$random_path" = "/" ];then
        echo -e "\033[36m下载页面地址: \033[33mhttp://$public_ip:$Port/Download\033[0m"
    else
        echo -e "\033[36m下载页面地址: \033[33mhttp://$public_ip:$Port$random_path/Download\033[0m"
    fi
    echo
    echo -e "  $var. 开/关${ariang_status}AriaNG\033[0m" && ((var++))
    echo "  $var. 设置网址端口" && ((var++))
    echo "  $var. 设置网址路径" && ((var++))
    echo "  $var. 卸载AriaNG" && ((var++))
    echo "  $var. 清空已下载文件" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ ! -z "$ariang_status" ];then
                systemctl disable ariang_nginx.service
                systemctl stop ariang_nginx.service
                systemctl disable ariang_aria2c.service
                systemctl stop ariang_aria2c.service
            else
                systemctl enable ariang_nginx.service
                systemctl start ariang_nginx.service
                systemctl enable ariang_aria2c.service
                systemctl start ariang_aria2c.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        2)
            colorRead ${YELLOW} "请输入端口[默认随机]" Port
            [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
            random=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
            sed -i "17s|.*|        listen       $Port;|" $wp/nginx.conf
            [ ! -z "$ariang_status" ] && systemctl restart ariang_nginx.service
            clear && panel
            ;;
        3)
            colorRead ${YELLOW} "请输入路径[输入1随机]" Path
            [ "$Path" = "1" ] && Path=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
            if [ -z "$Path" ];then
                sed -i "21s|.*|        location / {|" $wp/nginx.conf
                sed -i "26s|.*|        location /Download {|" $wp/nginx.conf
                sed -i '22s|alias|root|' $wp/nginx.conf
            else
                sed -i "21s|.*|        location /$Path {|" $wp/nginx.conf
                sed -i "26s|.*|        location /$Path/Download {|" $wp/nginx.conf
                sed -i '22s|root|alias|' $wp/nginx.conf
            fi
            [ ! -z "$ariang_status" ] && systemctl restart ariang_nginx.service
            clear && panel
            ;;
        4)
            read
            bash $wp/uninstall.sh
            clear && echo "AriaNG已卸载！" && exit 0
            ;;
        5)
            read
            rm -rf $wp/Download/*
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -q "^##" $0;then
    public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
else
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i '$a##'$public_ip'' $0
fi

clear && panel
