#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/AriaNG"
. $wp/functions.sh

panel() {
    var=1
	public_ip=$(ip_info get_ip)
    Port=$(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*")
    Path=($(grep -n "location" $wp/nginx.conf))
    random_path=${Path[2]}
    download_path=${Path[6]}
    ariang_status="${RED}" && pgrep -f $wp/aria2c >/dev/null 2>&1 && pgrep -f $wp/nginx >/dev/null 2>&1 && ariang_status="$GREEN"
    system_storage=$(df -h | grep "/$" | awk '{print $(NF-4)}')

    echo
    echo -e "    ${BLUE}剩余存储: ${YELLOW}${system_storage}${BLANK}"
    echo -e "  ${BLUE}AriaNG地址: ${YELLOW}http://$public_ip:$Port$random_path${BLANK}"
    echo -e "${BLUE}下载页面地址: ${YELLOW}http://$public_ip:$Port$download_path${BLANK}"

    echo
    echo -e "  $((var++)). 开/关${ariang_status}AriaNG${BLANK}"
    echo "  $((var++)). 设置网址端口"
    echo "  $((var++)). 设置网址路径"
    echo "  $((var++)). 卸载AriaNG"
    echo "  $((var++)). 清空已下载文件"
    if [ -d "/usr/local/oneindex" ] && pgrep -f /usr/local/oneindex/php >/dev/null 2>&1;then
        oneindex_status=$(sed -n "17p" $wp/aria2.conf | awk -F '=' '{print $2}')
        [ -z "$oneindex_status" ] || oneindex_status="$GREEN"
        Opath=$(sed -n "1p" $wp/oneindex.ini)
        echo -e "  $((var++)). 开/关${oneindex_status}oneindex${BLANK}自动上传"
        echo -e "  $((var++)). 更改网盘路径 $YELLOW$Opath${BLANK}"
	else
		sed -i "17s|.*|on-download-complete=|" $wp/aria2.conf
    fi
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "${GREEN}" = "$ariang_status" ];then
				stop_service "nginx stop" ariang_nginx
				stop_service "aria2c stop" ariang_aria2c
            else
				start_service "nginx start" ariang_nginx
				start_service "aria2c start" ariang_aria2c
            fi
            clear && panel
            ;;
        2)
            colorRead ${YELLOW} "请输入端口[默认随机]" Port
            [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
            web=$(grep -Eo 'href="http.*" target' $wp/index.html)
            web_=$(echo "$web" | sed 's|:[0-9][0-9]*|:'$Port'|')
            sed -i "s|$web|$web_|g" $wp/index.html
            sed -i "s|listen.*|listen       $Port;|" $wp/nginx.conf
			start_service "nginx start" ariang_nginx
			start_service "aria2c start" ariang_aria2c
            clear && panel
            ;;
        3)
            Path=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
            nginx_path=($(grep -n "location" $wp/nginx.conf))
            web=$(grep -Eo 'href="http.*" target' $wp/index.html)
            web_=$(echo "href=\"http://$public_ip:$Port/$Path/Download\" target")
            sed -i "s|$web|$web_|g" $wp/index.html
            sed -i "${nginx_path[0]%:}s|location.*|location /$Path {|" $wp/nginx.conf
            sed -i "${nginx_path[4]%:}s|location.*|location /$Path/Download {|" $wp/nginx.conf
			start_service "nginx start" ariang_nginx
			start_service "aria2c start" ariang_aria2c
            clear && panel
            ;;
        4)
			if warning_read;then
				bash $wp/uninstall.sh
				clear && echo "AriaNG已卸载！" && exit 0
			fi
            ;;
        5)
			if warning_read;then
				rm -rf $wp/Download/*
				clear && panel
			fi
            ;;
        6)
            var=6 && clear && exit 1
			if [ -d "/usr/local/oneindex" ];then
                if [ "${GREEN}" = "$oneindex_status" ];then
                    sed -i "17s|.*|on-download-complete=|" $wp/aria2.conf
                else
                    sed -i "17s|.*|on-download-complete=$wp/oneindex\.sh|" $wp/aria2.conf
                fi >/dev/null 2>&1
				start_service "nginx start" ariang_nginx
				start_service "aria2c start" ariang_aria2c
            fi
            clear && panel
            ;;
        7)
            var=6 && clear && exit 1
            if [ -d "/usr/local/oneindex" ];then
                colorRead ${YELLOW} "请输入路径[保留开头/]" Opath
                [ -z "$Opath" ] && clear && panel
                echo "$Opath" > $wp/oneindex.ini
            fi
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
