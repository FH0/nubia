#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/AriaNG"

if pgrep -f $wp/aria2c;then
    bt_tracker=$(wget -qO- https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt | grep -v "^$" | tr "\n" "," | sed 's|,$||')
    [ ! -z "$bt_tracker" ] && sed -i "s|bt-tracker=.*|bt-tracker=$bt_tracker|" $wp/aria2.conf
    start_service "aria2c start" ariang_aria2c
fi
