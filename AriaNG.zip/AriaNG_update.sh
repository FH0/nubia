#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/AriaNG"

systemctl -q is-active ariang_nginx.service && systemctl -q is-active ariang_aria2c.service && aria2=on || aria2=""

if [ "$aria2" = "on" ];then
    bt_tracker=$(wget -qO- https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt | grep -v "^$" | tr "\n" "," | sed 's|,$||')
    [ ! -z "$bt_tracker" ] && sed -i "s|bt-tracker=.*|bt-tracker=$bt_tracker|" $wp/aria2.conf
    systemctl restart ariang_aria2c.service
fi
