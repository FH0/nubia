#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/AriaNG"
. $wp/functions.sh

install_ariang(){
    chmod -R 777 $wp

    colorEcho $BLUE "正在安装AriaNG控制面板..."
    ip_info init
	cp $wp/manage_panel.sh /bin/ag

    colorEcho $BLUE "正在添加种子高速源..."
    bt_tracker=$(curl -sL https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt | grep -v "^$" | tr "\n" "," | sed 's|,$||')
    [ -z "$bt_tracker" ] || sed -i "s|bt-tracker=.*|bt-tracker=$bt_tracker|" $wp/aria2.conf
    
    colorEcho $BLUE "正在启动种子高速源自动更新程序..."
    sed -i '/AriaNG_update\.sh/d' /etc/crontab
    echo "00 03 * * * root $wp/AriaNG_update.sh" >> /etc/crontab

    colorEcho $BLUE "正在设置随机网址..."
    random=$(random_password 6)
    random_port=$(random_port)
    sed -i "s|listen.*|listen       $random_port;|" $wp/nginx.conf
    nginx_path=($(grep -n "location" $wp/nginx.conf))
    sed -i "${nginx_path[0]%:}s|location.*|location /$random {|" $wp/nginx.conf
    sed -i "${nginx_path[4]%:}s|location.*|location /$random/Download {|" $wp/nginx.conf
    sed -i "s|href=\"http.*\" target|href=\"http\://$public_ip\:$random_port/$random/Download\" target|" $wp/index.html

    colorEcho $BLUE "正在设置随机rpc密码..."
    random_base64=$(printf "$random" | base64)
    sed -i "s|secret:\"[0-9a-zA-Z]*\"|secret:\"$random_base64\"|" $wp/index.html
    sed -i "s|rpc-secret=.*|rpc-secret=$random|" $wp/aria2.conf

    colorEcho $BLUE "正在启动AriaNG..."
	start_service
	
    mkdir -p /usr/local/nginx/logs
	grep -q "^nobody" /etc/group || groupadd nobody
}

main(){
    install_ariang
    colorEcho $GREEN "AriaNG安装完成！输入ag可进入控制面板！"
}

main
