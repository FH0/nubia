#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/AriaNG"

RED="31m"      # Error message
GREEN="32m"    # Success message
YELLOW="33m"   # Warning message
BLUE="36m"     # Info message

colorEcho(){
    COLOR=$1
    echo -e "\033[${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    [ -z "$(command -v yum)" ] && Installer="apt-get" || Installer="yum"
    var="0"
    for command in $1;do
        echo "$CHECK" | grep -q "$command"
        if [ "$?" != "0" ];then
            [ "$var" = "0" ] && apt-get update && var="1"
            $Installer install $command -y
        fi > /dev/null 2>&1
    [ "$?" != "0" ] && colorEcho $RED "相关命令安装失败！" && exit 1
    done
}

install_ariang(){
    colorEcho $BLUE "正在开启AriaNG自启程序..."
    cat $wp/ariang_aria2c.service > /etc/systemd/system/ariang_aria2c.service
    cat $wp/ariang_nginx.service > /etc/systemd/system/ariang_nginx.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装AriaNG控制面板..."
    cat $wp/manage_pannel.sh > /bin/ag
    chmod +x /bin/ag
    
    colorEcho $BLUE "正在添加种子高速源..."
    bt_tracker=$(wget -qO- https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt | grep -v "^$" | tr "\n" "," | sed 's|,$||')
    [ ! -z "$bt_tracker" ] && sed -i "s|bt-tracker=.*|bt-tracker=$bt_tracker|" $wp/aria2.conf
    
    colorEcho $BLUE "正在启动种子高速源自动更新程序..."
    sed -i '/AriaNG_update\.sh/d' /etc/crontab
    echo "00 03 * * * root $wp/AriaNG_update.sh" >> /etc/crontab

    colorEcho $BLUE "正在设置随机网址..."
    random=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
    sed -i "17s|.*|        listen       $(shuf -i 1024-65535 -n 1);|" $wp/nginx.conf
    sed -i "21s|.*|        location /$random {|" $wp/nginx.conf
    sed -i "26s|.*|        location /$random/Download {|" $wp/nginx.conf

    colorEcho $BLUE "正在设置随机rpc密码..."
    random_base64=$(printf "$random" | base64)
    sed -i "s|secret:\"|secret:\"$random_base64|" $wp/index.html
    sed -i "s|rpc-secret=.*|rpc-secret=$random|" $wp/aria2.conf

    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1
}

main(){
    cmd_need "unzip wget curl"
    install_ariang
    mkdir -p /usr/local/nginx/logs
    systemctl enable ariang_nginx.service >/dev/null 2>&1; systemctl start ariang_nginx.service
    systemctl enable ariang_aria2c.service >/dev/null 2>&1; systemctl start ariang_aria2c.service
    colorEcho $GREEN "AriaNG安装完成！输入ag可进入控制面板！"
}

main
