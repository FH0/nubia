#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/AriaNG"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

install_ariang(){
    chmod -R 777 $wp
    
    if command -v systemctl >/dev/null;then
        colorEcho $BLUE "正在开启AriaNG自启程序..."
        cp $wp/ariang_aria2c.service /etc/systemd/system/ariang_aria2c.service
        cp $wp/ariang_nginx.service /etc/systemd/system/ariang_nginx.service
        systemctl daemon-reload
		systemctl enable ariang_nginx.service >/dev/null 2>&1
		systemctl enable ariang_aria2c.service >/dev/null 2>&1
	elif [ -e "/etc/rc.local" ];then
        colorEcho $BLUE "正在开启AriaNG自启程序..."
		tmp_echo=$(grep -v "^exit" /etc/rc.local)
		echo "$tmp_echo" > /etc/rc.local
		echo "$wp/systemctl_ctl.sh nginx start >/dev/null 2>&1" >> /etc/rc.local
		echo "$wp/systemctl_ctl.sh aria2c start >/dev/null 2>&1" >> /etc/rc.local
		echo "exit 0" >> /etc/rc.local
	fi

    colorEcho $BLUE "正在安装AriaNG控制面板..."
    cp $wp/manage_panel.sh /bin/ag
    public_ip=$(curl -sL http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i '$a##'$public_ip'' /bin/ag

    colorEcho $BLUE "正在添加种子高速源..."
    bt_tracker=$(wget -qO- https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt | grep -v "^$" | tr "\n" "," | sed 's|,$||')
    [ ! -z "$bt_tracker" ] && sed -i "s|bt-tracker=.*|bt-tracker=$bt_tracker|" $wp/aria2.conf
    
    colorEcho $BLUE "正在启动种子高速源自动更新程序..."
    sed -i '/AriaNG_update\.sh/d' /etc/crontab
    echo "00 03 * * * root $wp/AriaNG_update.sh" >> /etc/crontab

    colorEcho $BLUE "正在设置随机网址..."
    random=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
    random_port=$(shuf -i 1024-65535 -n 1)
    sed -i "s|listen.*|listen       $random_port;|" $wp/nginx.conf
    nginx_path=($(grep -n "location" $wp/nginx.conf))
    sed -i "${nginx_path[0]%:}s|location.*|location /$random {|" $wp/nginx.conf
    sed -i "${nginx_path[4]%:}s|location.*|location /$random/Download {|" $wp/nginx.conf
    sed -i "s|href=\"http.*\" target|href=\"http\://$public_ip\:$random_port/$random/Download\" target|" $wp/index.html

    colorEcho $BLUE "正在设置随机rpc密码..."
    random_base64=$(printf "$random" | base64)
    sed -i "s|secret:\"[0-9a-zA-Z]*\"|secret:\"$random_base64\"|" $wp/index.html
    sed -i "s|rpc-secret=.*|rpc-secret=$random|" $wp/aria2.conf

	$wp/systemctl_ctl.sh nginx start >/dev/null 2>&1
	$wp/systemctl_ctl.sh aria2c start >/dev/null 2>&1
	
	grep -q "^nobody" /etc/group || groupadd nobody
}

main(){
    install_ariang
    mkdir -p /usr/local/nginx/logs
    colorEcho $GREEN "AriaNG安装完成！输入ag可进入控制面板！"
}

main
