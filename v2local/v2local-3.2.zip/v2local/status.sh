
wp=${0%/*} ; wp=${wp:-.}
v2local_cmd=status . $wp/bin/v2local_function.sh
