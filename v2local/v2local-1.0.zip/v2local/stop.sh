
wp=$(cd "$(dirname $0)"; pwd)
type shopt >/dev/null 2>&1 && shopt -s expand_aliases
for C in awk chmod chpst echo getip grep killall ln mkdir pgrep rm sed seq sort wc;do
    alias $C="$wp/bin/busybox $C"
done
chmod -R 777 $wp

{
    killall v2raY redsocks2
    ip rule | grep " 1110" | sed 's|.*from|ip rule del from |g' | sh
	ip route flush table 1110
    iptables -t nat -S | grep "v2local" | sed "s|^..|iptables -w -t nat -D|g" | sh
    iptables -t mangle -S | grep "v2local" | sed "s|^..|iptables -w -t mangle -D|g" | sh
} >/dev/null 2>&1

[ -z "$1" ] && $wp/status.sh
