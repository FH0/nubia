
wp=$(cd "$(dirname $0)"; pwd)
type shopt >/dev/null 2>&1 && shopt -s expand_aliases
for C in awk chmod chpst echo getip grep killall ln mkdir pgrep rm sed seq sort wc;do
    alias $C="$wp/bin/busybox $C"
done
chmod -R 777 $wp

echo
v2ray_status="○⊃" && [ -z "$(pgrep v2raY)" ] || v2ray_status="⊂●"
redsocks2_status="   ○⊃" && [ -z "$(pgrep redsocks2)" ] || redsocks2_status="   ⊂●"
echo "    $v2ray_status V2Ray  $redsocks2_status redsocks2"

app_uids=$(sed -n '1p' $wp/bin/config.json | awk -F '=' '{print $2}')
if [ ! -z "$app_uids" ];then
    echo
    if [ -z "$(sed -n '1p' $wp/bin/config.json | grep 'app_proxy')" ];then
        echo "    {放行的应用}:"
    else
        echo "    {代理的应用}:"
    fi
    echo
    grep -E "$(echo $app_uids | sed 's| | \||g')" /data/system/packages.list | awk '{print "    "$2"  "$1}'
fi
