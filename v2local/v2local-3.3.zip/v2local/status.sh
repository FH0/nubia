
wp=$(dirname $(readlink -f $0))
v2local_cmd=status . $wp/bin/v2local_function.sh
