
wp=$(cd "$(dirname $0)"; pwd)
type shopt >/dev/null 2>&1 && shopt -s expand_aliases
for C in awk basename chmod chpst echo getip grep killall pgrep rm sed sort;do
    alias $C="$wp/bin/busybox $C"
done
chmod -R 777 $wp

{
    killall v2raY redsocks2
    /system/bin/ip rule | grep " 1110" | sed 's|.*from|/system/bin/ip rule del from |g' | sh
    /system/bin/ip route flush table 1110
    iptables -t nat -S | grep "v2local" | sed "s|^..|iptables -w -t nat -D|g" | sh
    iptables -t mangle -S | grep "v2local" | sed "s|^..|iptables -w -t mangle -D|g" | sh
} >/dev/null 2>&1

[ -z "$1" ] && $wp/status.sh
