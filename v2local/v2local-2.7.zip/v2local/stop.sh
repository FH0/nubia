
wp=${0%/*} ; wp=${wp:-.}
. $wp/bin/v2local_function.sh stop
