#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/swapfile"

swapoff $wp/eKzE1I > /dev/null 2>&1
sed -i "/eKzE1I swap/d" /etc/fstab

rm -rf $wp
rm -f /bin/sp
