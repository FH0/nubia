#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/swapfile"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    [ -z "$(command -v yum)" ] && Installer="apt-get" || Installer="yum"
    var="0"
    for command in $1;do
        echo "$CHECK" | grep -q "$command"
        if [ "$?" != "0" ];then
            [ "$var" = "0" ] && apt-get update && var="1"
            $Installer install $command -y
        fi > /dev/null 2>&1
    [ "$?" != "0" ] && colorEcho $RED "相关命令安装失败！" && exit 1
    done
}

install_swapfile(){
    input=$(($(grep 'MemTotal' /proc/meminfo | awk '{print $2}')/512))
    dd if=/dev/zero of=$wp/eKzE1I bs=1M count=$input > /dev/null 2>&1
    mkswap $wp/eKzE1I > /dev/null 2>&1
    chmod 600 $wp/eKzE1I
    swapon $wp/eKzE1I
    
    colorEcho $BLUE "正在开启swap自启程序..."
    sed -i "/eKzE1I swap/d" /etc/fstab
    echo "$wp/eKzE1I swap swap defaults 0 0" >> /etc/fstab

    colorEcho $BLUE "正在安装swap控制面板..."
    cat $wp/manage_panel.sh > /bin/sp
    chmod +x /bin/sp
}

main(){
    install_swapfile
    colorEcho $GREEN "swap分区安装完成！输入sp可进入控制面板！"
}

main
