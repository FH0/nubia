
wp=$(dirname $(readlink -f $0))

# 使用 busybox 提供的所有命令
shopt -s expand_aliases >/dev/null 2>&1
for cmd in $($wp/bin/busybox --list); do
    alias $cmd="$wp/bin/busybox $cmd"
done

cmd=status . $wp/bin/functions.sh
