#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/frps"

systemctl stop frp.service
systemctl disable frp.service > /dev/null 2>&1
rm -f /etc/systemd/system/frp.service
systemctl daemon-reload ; systemctl reset-failed

rm -rf $wp
rm -f /bin/frp
