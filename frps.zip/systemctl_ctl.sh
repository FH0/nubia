#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/frps"

bash <(iptables -S | grep "$wp" | sed "s|-[AI] |-D |g;s|^|iptables |g")

if [ "$1" = "stop" ];then
    kill -9 $(ps -ef | grep "$wp" | sed -n "1p" | awk '{print $2}')
else
    iptables -I INPUT -p tcp --dport $(sed -n "2p" $wp/frps.ini | grep -Eo "[0-9]*") -m string ! --string "$wp" --algo bm -j ACCEPT
    iptables -I INPUT -p udp --dport $(sed -n "2p" $wp/frps.ini | grep -Eo "[0-9]*") -m string ! --string "$wp" --algo bm -j ACCEPT
    $wp/frps -c $wp/frps.ini
fi
