#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/frps"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

panel() {
    var=1
    frp_port=$(sed -n "2p" $wp/frps.ini | grep -Eo "[0-9]*")
    token=$(sed -n "3p" $wp/frps.ini | awk -F " = " '{print $2}')
    frp_status="${RED}" && systemctl is-active -q frp.service && frp_status="$GREEN"

    echo
    echo -e "\033[36mfrp服务器: \033[33m$public_ip:$frp_port\033[0m"
    echo -e "    \033[36mtoken: \033[33m$token\033[0m"
    echo
    echo -e "  $var. 开/关${frp_status}frp\033[0m" && ((var++))
    echo "  $var. 更改frp端口" && ((var++))
    echo "  $var. 更改token" && ((var++))
    echo "  $var. 卸载frp" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "${GREEN}" = "$frp_status" ];then
                systemctl disable frp.service
                systemctl stop frp.service
            else
                systemctl enable frp.service
                systemctl start frp.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        2)
            colorRead ${YELLOW} '请输入frp端口[默认随机]' Port
            [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
            sed -i '2s|.*|bind_port = '$Port'|' $wp/frps.ini
            systemctl restart frp.service
            clear && panel
            ;;
        3)
            colorRead ${YELLOW} '请输入token[默认随机]' token
            [ -z "$token" ] && token=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
            sed -i '3s|.*|token = '$token'|' $wp/frps.ini
            systemctl restart frp.service
            clear && panel
            ;;
        4)
            read
            bash $wp/uninstall.sh
            clear && echo "frp已卸载！" && exit 0
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -q "^##" $0;then
    public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
else
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i '$a##'$public_ip'' $0
fi

clear && panel
