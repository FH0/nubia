#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/frps"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

install_frp(){
    colorEcho $BLUE "正在开启frp自启程序..."
    cat $wp/frp.service > /etc/systemd/system/frp.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装frp控制面板..."
    cat $wp/manage_panel.sh > /bin/frp
    chmod +x /bin/frp
    
    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1
}

add_one_port(){
    Port=$(shuf -i 1024-65535 -n 1)
    token=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
    echo -e "[common]\nbind_port = $Port\ntoken = $token" > $wp/frps.ini
}

main(){
    install_frp
    add_one_port
    systemctl enable frp.service >/dev/null 2>&1; systemctl start frp.service
    colorEcho $GREEN "frp安装完成！输入frp可进入控制面板！"
}

main
