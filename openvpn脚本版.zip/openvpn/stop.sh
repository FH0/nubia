chmod -R 777 ${0%/*} ; ${0%/*}/start.sh stop
