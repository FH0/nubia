
pre_openvpn(){
    export PATH=$1/bin:$PATH
    if ! echo $1 | grep -q '^/data';then
        echo
        auto_echo "请放在/data文件夹内"
        exit 1
    fi
    chmod -R 777 $1/*.sh $1/bin
    for need_cmd in pkill awk grep sed cat rm pgrep tr wc sort sleep;do
        if [ -z "$(busybox which $need_cmd)" ];then
            busybox cp ./bin/busybox ./bin/$need_cmd
        fi
    done
    . ./config.ini
    rm -f *.bak */*.bak
    if [ -d "/system/lib64" ];then
        openvpn=openvpn_aarch64
        pdnsd=pdnsd_aarch64
    else
        openvpn=openvpn_arm
        pdnsd=pdnsd_arm
    fi
    if getprop ro.build.version.release | grep "^4" >/dev/null 2>&1;then
        echo
        auto_echo "仅支持安卓5及后续版本"
        exit 1
    fi
    interface=$(ip addr | grep "inet " | grep -Ev " lo| usb" | sed -n "1p" | awk '{print $NF}')
}

auto_echo(){
    echo "   $@"
}

check_openvpn(){
    if pgrep $openvpn >/dev/null 2>&1;then
        openvpn_status="⊂●"
    else
        openvpn_status="○⊃"
    fi
    if pgrep $pdnsd >/dev/null 2>&1;then
        pdnsd_status="⊂●"
    else
        pdnsd_status="○⊃"
    fi
    echo
    auto_echo "$openvpn_status  openvpn   $pdnsd_status  pdnsd"
    echo
    auto_echo "如果openvpn在运行却没有网，请执行stop.sh，然后看日志文件"
    auto_echo "如果出现Restart pause，那么是服务器不稳定"
    echo
    auto_echo "脚本版的配置文件不能完全兼容软件版的"
    auto_echo "问问题时请带上日志截图"
    rm -f ./config/e2ad8140d4a43dcf084a086125880998*
}

start_openvpn(){
    if [ ! -z "$user" -a ! -z "$passwd" ];then
        echo -e "$user\n$passwd" > ./config/$config.passwd
        $openvpn --config ./config/$config --auth-user-pass ./config/$config.passwd --dev-node /dev/tun --dev tun_openvpn --route-noexec --verb 2 2>&1 >./bin/openvpn.log &
    else
        $openvpn --config ./config/$config --dev-node /dev/tun --dev tun_openvpn --route-noexec --verb 2 2>&1 >./bin/openvpn.log &
    fi
    $pdnsd -c ./bin/pdnsd.conf >/dev/null 2>&1 &
}

stop_openvpn(){
    pkill $openvpn
    pkill $pdnsd
    daemon_pid=$(busybox ps | grep "bin/daemon.sh" | awk '{print $1}')
    busybox kill -9 $daemon_pid >/dev/null 2>&1
    ip route show table 122 | sed 's|^|ip route del table 122 |g' | sh
    iptables -F
    ip rule | grep -E " 122|999.*uid" | sed 's|.*from|ip rule del from |g' | sh
    iptables -t nat -S | grep -E "dport 53|MASQUERADE" | sed 's|^..|iptables -t nat -D|g' | sh
}

rule_log(){
    echo >>./bin/openvpn.log
    echo "$(getprop ro.product.brand) $(getprop ro.product.model) $(getprop ro.build.version.release)" >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip addr | grep -Eo "inet .*" >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip route show table 122 >>./bin/openvpn.log
    sed -i "s|$IP|x\.x\.x\.x|g;s|.*201. ||g;/WARNING/d;/Options error/d" ./bin/openvpn.log
}

add_rule(){
    while ! ip addr show dev tun_openvpn >/dev/null 2>&1;do
        sleep 0.5
        if ! pgrep $openvpn >/dev/null 2>&1;then
            auto_echo "不支持的配置文件！"
            exit 1
        fi
    done
    sleep 0.5
    ip route add default dev tun_openvpn proto static table 122
    if [ ! -z "$app_direct" ];then
        for X in ${app_direct};do
            app_uid=$(grep "$X " /data/system/packages.list | awk '{print $2}')
            app_uids="$app_uid $app_uids"
        done
        app_uids=$(echo "$app_uids" | tr " " "\n" | sort)
        var=3004
        for app_uid in ${app_uids};do
            ip rule add uidrange $var-$(($app_uid-1)) table 122
            var=$(($app_uid+1))
        done
        ip rule add uidrange $(($app_uid+1))-99999 table 122
    else
        ip rule add uidrange 3004-99999 table 122
    fi
    iptables -t nat -I OUTPUT -p udp --dport 53 ! -d $DNS -j REDIRECT --to 1253
    iptables -t nat -I POSTROUTING -j MASQUERADE
    if [ "$hot_proxy" = "on" ];then
        host_interface=$(ip addr | grep "192.168.43" | awk '{print $NF}')
        ip rule add iif $host_interface table 122
        iptables -t nat -I PREROUTING -p udp --dport 53 ! -d $DNS -j DNAT --to $DNS
    fi
    
    rule_log
    [ "$daemon" = "on" ] && IP=$IP app_uids=$app_uids sh ./bin/daemon.sh &
}

edit_config(){
    busybox cp ./config/$config ./config/e2ad8140d4a43dcf084a086125880998
    config="e2ad8140d4a43dcf084a086125880998"
    sed -i 's|^[ \t]*||g;s|[ \t]*$||g;s|\r||g;/^$/d;/^[#\;]/d;s|“||g;s|”||g' ./config/$config
    sed -i '/^resolv/d;/^connect/d;/^machine/d;/^setenv/d;/^persist/d;/^nobind/d;/^push/d;/^verb/d' ./config/$config
    IP=$(grep "http-proxy " ./config/$config | awk '{print $2}' || grep "remote " ./config/$config | awk '{print $2}')
    if ! echo "$IP" | grep -qEo '([0-9]{1,3}\.){3}[0-9]{1,3}';then
        domain_ip=$(busybox nslookup $IP | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sed -n '$p')
        if [ -z "$domain_ip" ];then
            echo
            auto_echo "域名解析失败"
            rm -f ./config/e2ad8140d4a43dcf084a086125880998*
            exit 1
        else
            sed -i 's|'$IP'|'$domain_ip'|' ./config/$config
            IP=$domain_ip
        fi
    fi
    if (( $(grep "EXT1" ./config/$config | wc -l) > 10 )) >/dev/null 2>&1;then
        echo
        auto_echo "http-proxy-option不能超过10行"
        rm -f ./config/e2ad8140d4a43dcf084a086125880998*
        exit 1
    fi
    echo -e "\nglobal {\n	run_as=\"net_raw\";\n	server_ip = 127.0.0.1;\n	server_port = 1253;\n	query_method=udp_tcp;\n}\n\nserver {\n	label= \"openvpn\";\n	ip = $DNS;\n	proxy_only=on;\n	timeout=4;\n}" > ./bin/pdnsd.conf
}

cd ${0%/*}
pre_openvpn ${0%/*}
if [ "$1" = "stop" ];then
    stop_openvpn
    iptables -t nat -I POSTROUTING -j MASQUERADE
elif [ -z "$1" ];then
    stop_openvpn
    edit_config
    start_openvpn
    add_rule
fi
check_openvpn
