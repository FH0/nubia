
pre_openvpn(){
    if ! pwd | grep -q '^/data';then
        echo
        echo "请放在/data文件夹内"
        exit 1
    fi
    chmod -R 777 ${0%/*}/*.sh ${0%/*}/bin
    export PATH=$(pwd)/bin:${PATH}
    for need_cmd in pkill awk grep sed pgrep tr sort sleep;do
        if ! command -v $need_cmd >/dev/null 2>&1;then
            busybox cp ./bin/busybox ./bin/$need_cmd
        fi
    done
    . ./config.ini
    rm -f *.bak */*.bak
    if [ -d "/system/lib64" ];then
        openvpn=openvpn_aarch64
    else
        openvpn=openvpn_arm
    fi
    interface=$(ip addr | grep "inet " | grep -Ev " lo| usb" | sed -n "1p" | awk '{print $NF}')
}

auto_echo(){
    echo "   $@"
}

check_openvpn(){
    if pgrep $openvpn >/dev/null 2>&1;then
        openvpn_status="⊂●"
    else
        openvpn_status="○⊃"
    fi
    echo
    auto_echo "$openvpn_status  $openvpn"
    echo
    auto_echo "如果openvpn在运行却没有网，请执行stop.sh，然后看日志文件"
    auto_echo "如果出现Restart pause，那么是服务器不稳定"
    echo
    auto_echo "脚本版的配置文件不能完全兼容软件版的"
    auto_echo "问问题时请带上日志截图"
    rm -f ./config/e2ad8140d4a43dcf084a086125880998*
}

start_openvpn(){
    if [ ! -z "$user" -a ! -z "$passwd" ];then
        echo "$user $passwd" | awk '{print $1 "\n" $2}' > ./config/$config.passwd
        $openvpn --config ./config/$config --auth-user-pass ./config/$config.passwd --dev-node /dev/tun --dev tun_openvpn --route-noexec 2>&1 | grep -E "Initialization|Restart|exiting" >>./bin/openvpn.log &
    else
        $openvpn --config ./config/$config --dev-node /dev/tun --dev tun_openvpn --route-noexec 2>&1 | grep -E "Initialization|Restart|exiting" >>./bin/openvpn.log &
    fi
}

stop_openvpn(){
    pkill $openvpn
    ps -ef | grep "bin/daemon.sh" | awk '{print $1" "$2}' | xargs kill -9 >/dev/null 2>&1
    ip route show table 122 | sed 's|^|ip route del table 122 |g' | sh
    iptables -S | grep " DROP" | sed 's|^..|iptables -D|g' | sh
    ip rule | grep " 122" | sed 's|.*from|ip rule del from |g' | sh
    iptables -t nat -S | grep "dport 53" | sed 's|^..|iptables -t nat -D|g' | sh
    ip6tables -t mangle -S OUTPUT | grep " DROP" | sed 's|^..|ip6tables -t mangle -D|g' | sh
}

rule_log(){
    echo $(getprop ro.product.brand) $(getprop ro.product.model) >./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip rule | grep " 122" >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip addr | grep -Eo "inet .*" >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip route show table 122 >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    ping -c1 -w2 $DNS 2>&1 | sed -n "1,2p" >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    sed -i "s|$IP|x\.x\.x\.x|g" ./bin/openvpn.log
}

add_rule(){
    while ! ip addr show dev tun_openvpn >/dev/null 2>&1;do
        sleep 0.5
        if ! pgrep $openvpn >/dev/null 2>&1;then
            auto_echo "不支持的配置文件！"
            exit 1
        fi
    done
    sleep 0.5
    iptables -I OUTPUT -o $interface ! -d $IP -j DROP
    ip route add default dev tun_openvpn proto kernel table 122
    if [ ! -z "$app_direct" ];then
        for X in ${app_direct};do
            app_uid=$(grep "$X " /data/system/packages.list | awk '{print $2}')
            app_uids="$app_uid $app_uids"
        done
        app_uids=$(echo "$app_uids" | tr " " "\n" | sort)
        var=1
        for app_uid in ${app_uids};do
            ip rule add uidrange $var-$(($app_uid-1)) table 122
            iptables -t mangle -I OUTPUT -m owner --uid-owner $app_uid -j ACCEPT
            iptables -I OUTPUT -m owner --uid-owner $app_uid -j ACCEPT
            var=$(($app_uid+1))
        done
        ip rule add uidrange $(($app_uid+1))-99999 table 122
    else
        ip rule add uidrange 1-99999 table 122
    fi
    if ip addr | grep -q "192.168.43";then
        hot_interface=$(ip addr | grep "192.168.43" | awk '{print $NF}')
        ip route add 192.168.43/24 dev $hot_interface table 122
    fi
    ip rule add to $DNS table 122
    iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to $DNS:53
    [ "$interface" = "wlan0" ] || ip6tables -t mangle -I OUTPUT -o $interface -j DROP

    rule_log
    [ "$daemon" = "on" ] && sh ./bin/daemon.sh &
}

edit_config(){
    cp ./config/$config ./config/e2ad8140d4a43dcf084a086125880998
    config="e2ad8140d4a43dcf084a086125880998"
    IP=$(grep "^[ \t]*http-proxy " ./config/$config | awk '{print $2}' || grep "^[ \t]*remote" ./config/$config | awk '{print $2}')
    if ! echo "$IP" | grep -qEo '([0-9]{1,3}\.){3}[0-9]{1,3}';then
        domain_ip=$(./bin/busybox wget -qO- http://119.29.29.29/d?dn=$IP | awk -F ";" '{print $NF}')
        if [ -z "$domain_ip" ];then
            echo
            echo " 域名解析失败"
            exit 1
        else
            sed -i 's|'$IP'|'$domain_ip'|' ./config/$config
            IP=$domain_ip
        fi
    fi
    sed -i "s|\"||g ; s|'||g ; s|“||g ; s|”||g ; /setenv /d ; /push /d" ./config/$config
    sed -i 's|EXT1 |EXT1 "|g ; s|EXT1.*|&"|g' ./config/$config
    sed -i "/connect-retry/d" ./config/$config
}

cd $(dirname $0)
pre_openvpn
if [ "$1" = "stop" ];then
    stop_openvpn
elif [ -z "$1" ];then
    stop_openvpn
    edit_config
    start_openvpn
    add_rule
fi
check_openvpn
