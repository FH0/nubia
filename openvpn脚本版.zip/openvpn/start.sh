
pre_openvpn(){
    mount -o rw,remount /system
    export PATH=${PATH}:$(pwd)/bin
    for C in pkill awk grep sed pgrep wget sleep sort;do
        if ! command -v $C >/dev/null 2>&1;then
            if ! busybox cp bin/busybox /system/bin/$C;then
                echo "请赋予文件夹及其子文件777权限"
                exit 1
            fi
        fi
    done
    . ./config.ini
    rm -f *.bak */*.bak
    IP=$(grep "^[ \t]*http-proxy " ./config/$config | awk '{print $2}' || grep "^[ \t]*remote" ./config/$config | awk '{print $2}')
    interface=$(ip addr | grep "inet " | grep -Ev " lo| usb" | sed -n "1p" | awk '{print $NF}')
    if [ -d "/system/lib64" ];then
        openvpn=openvpn_aarch64
    else
        openvpn=openvpn_arm
    fi
    if [ -d "/sys/class/net/ccmni0" ]; then
        _interface="ccmni+"
    elif [ -d "/sys/class/net/rmnet0" ]; then
        _interface="rmnet+"
    elif [ -d "/sys/class/net/rmnet_data0" ]; then
        _interface="rmnet_data+"
    fi
}

check_openvpn(){
    if pgrep $openvpn >/dev/null 2>&1;then
        openvpn_status="    ⊂●"
    else
        openvpn_status="    ○⊃"
    fi
    echo
    echo "$openvpn_status  $openvpn"
    mount -o ro,remount /system
}

start_openvpn(){
    if [ ! -z "$user" -a ! -z "$passwd" ];then
        echo "$user $passwd" | awk '{print $1 "\n" $2}' > ./config/$config.passwd
        $openvpn --config ./config/$config --auth-user-pass ./config/$config.passwd --dev-node /dev/tun --dev tun_openvpn --route-noexec 2>&1 | grep -E "Initialization|Restart|exiting" >>./bin/openvpn.log &
    else
        $openvpn --config ./config/$config --dev-node /dev/tun --dev tun_openvpn --route-noexec 2>&1 | grep -E "Initialization|Restart|exiting" >>./bin/openvpn.log &
    fi
}

stop_openvpn(){
    pkill $openvpn
    ip route flush table 122
    iptables -t mangle -F OUTPUT
    ip rule | grep -E " 122| to" | sed 's|.*from|ip rule del from |g' | sh
    iptables -t nat -S | grep -E "MASQUERADE|dport 53" | sed 's|^..|iptables -t nat -D|g' | sh
    ip6tables -t mangle -F OUTPUT
}

rule_log(){
    echo $(getprop ro.product.brand) $(getprop ro.product.model) >./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip rule | grep " 122" | sed 's|[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*|x\.x\.x\.x|g' >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip addr | grep -Eo "inet .*" >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip route show table 122 | sed 's|[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*|x\.x\.x\.x|g' >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    iptables -t nat -S OUTPUT >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    iptables -t mangle -S OUTPUT | sed 's|[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*|x\.x\.x\.x|g' >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    ping -c1 -w2 $DNS 2>&1 | sed -n "1,2p" >>./bin/openvpn.log
    echo >>./bin/openvpn.log
}

add_rule(){
    while ! ip addr show dev tun_openvpn >/dev/null 2>&1;do
        sleep 0.5
    done
    sleep 0.5
    ip route add $IP dev $interface table 122
    ip addr | grep -q "192.168.43" && ip route add 192.168.43/24 dev wlan0 table 122
    ip route add default dev tun_openvpn proto static table 122
    ip rule add not to $IP table 122
    iptables -t mangle -I OUTPUT -o $interface ! -d $IP -j DROP
    iptables -F
    iptables -t nat -I POSTROUTING -j MASQUERADE
    iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to $DNS:53
    iptables -t nat -I PREROUTING -p udp --dport 53 -j DNAT --to $DNS:53
    ip6tables -t mangle -I OUTPUT -o $_interface -j DROP
    
    rule_log
}

edit_config(){
    if ! echo "$IP" | grep -qEo '([0-9]{1,3}\.){3}[0-9]{1,3}';then
        domain_ip=$(./bin/busybox wget -qO- http://119.29.29.29/d?dn=$IP | awk -F ";" '{print $NF}')
        if [ -z "$domain_ip" ];then
            echo
            echo " 域名解析失败"
            mount -o ro,remount /system
            exit 1
        else
            sed -i 's|'$IP'|'$domain_ip'|' ./config/$config
            IP=$domain_ip
        fi
    fi
    sed -i "s|\"||g ; s|'||g ; s|“||g ; s|”||g ; /setenv /d ; /push /d" ./config/$config
    sed -i 's|EXT1 |EXT1 "|g ; s|EXT1.*|&"|g' ./config/$config
}

chmod -R 777 ${0%/*}/*.sh ${0%/*}/bin
cd ${0%/*}
pre_openvpn
if [ "$1" = "stop" ];then
    stop_openvpn
elif [ -z "$1" ];then
    stop_openvpn
    edit_config
    start_openvpn
    add_rule
fi
check_openvpn
