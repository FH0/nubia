
pre_openvpn(){
    mount -o rw,remount /system
    export PATH=${PATH}:$(pwd)/bin
    for C in killall awk grep pgrep;do
        if ! command -v $C >/dev/null 2>&1;then
            if ! busybox cp bin/busybox /system/bin/$C;then
                echo "请赋予文件夹及其子文件777权限"
                exit 1
            fi
        fi
    done
    if [ ! -f "/sbin/ifconfig" ];then
        cp /system/bin/ifconfig /sbin
    fi
    . ./config.ini
    rm -f *.bak */*.bak
    IP=$(grep "^remote" config/$config | awk '{print $2}')
    if [ -d "/system/lib64" ];then
        openvpn=openvpn_aarch64
    else
        openvpn=openvpn_arm
    fi
}

check_openvpn(){
    if pgrep $openvpn >/dev/null 2>&1;then
        openvpn_status="    ⊂●"
    else
        openvpn_status="    ○⊃"
    fi
    echo
    echo "$openvpn_status  $openvpn"
}

start_openvpn(){
    $openvpn --config ./config/$config --dev-node /dev/tun --dev tun_openvpn --route-noexec &
    mount -o ro,remount /system
} >/dev/null 2>&1

stop_openvpn(){
    killall $openvpn
    ip route fel default via 10.8.0.2 dev tun_openvpn table 122
    ip route del $IP dev wlan0 table 122
    ip rule del table 122
} >/dev/null 2>&1

add_rule(){
    while ! ifconfig tun_openvpn >/dev/null 2>&1;do
        ifconfig tun_openvpn
    done >/dev/null 2>&1
    ip route add default via 10.8.0.2 dev tun_openvpn table 122
    ip route add $IP dev wlan0 table 122
    ip rule add table 122
}

chmod -R 777 ${0%/*}
cd ${0%/*}
pre_openvpn
if [ "$1" = "stop" ];then
    stop_openvpn
elif [ -z "$1" ];then
    stop_openvpn
    start_openvpn
    add_rule
fi
check_openvpn
