
pre_openvpn(){
    export PATH=$1/bin:$PATH
    if ! echo $1 | grep -q '^/data';then
        echo
        auto_echo "请放在/data文件夹内"
        exit 1
    fi
    chmod -R 777 $1/*.sh $1/bin
    for need_cmd in pkill awk grep sed cat rm pgrep tr wc sort sleep;do
        if [ -z "$(busybox which $need_cmd)" ];then
            busybox cp ./bin/busybox ./bin/$need_cmd
        fi
    done
    . ./config.ini
    rm -f *.bak */*.bak
    if [ -d "/system/lib64" ];then
        openvpn=openvpn_aarch64
    else
        openvpn=openvpn_arm
    fi
    if getprop ro.build.version.release | grep "^4" >/dev/null 2>&1;then
        echo
        auto_echo "仅支持安卓5及后续版本"
        exit 1
    fi
    interface=$(ip addr | grep "inet " | grep -Ev " lo| usb" | sed -n "1p" | awk '{print $NF}')
}

auto_echo(){
    echo "   $@"
}

check_openvpn(){
    if pgrep $openvpn >/dev/null 2>&1;then
        openvpn_status="⊂●"
    else
        openvpn_status="○⊃"
    fi
    echo
    auto_echo "$openvpn_status  openvpn"
    echo
    echo
    auto_echo "如果配置文件正确，但脚本一直处于执行中"
    auto_echo "或者执行成功本机却没有网"
    auto_echo "或者热点没网"
    auto_echo "那么是不支持此手机，没有解决办法"
    rm -f ./config/e2ad8140d4a43dcf084a086125880998*
}

start_openvpn(){
    if [ ! -z "$user" -a ! -z "$passwd" ];then
        echo -e "$user\n$passwd" > ./config/$config.passwd
        $openvpn --config ./config/$config --auth-user-pass ./config/$config.passwd --dev-node /dev/tun --dev tun_openvpn --route-noexec --verb 2 >/dev/null 2>&1 &
    else
        $openvpn --config ./config/$config --dev-node /dev/tun --dev tun_openvpn --route-noexec --verb 2 >/dev/null 2>&1 &
    fi
}

stop_openvpn(){
    pkill $openvpn
    daemon_pid=$(busybox ps | grep "bin/daemon.sh" | awk '{print $1}')
    busybox kill -9 $daemon_pid
    ip route show table 122 | sed 's|^|ip route del table 122 |g' | sh
    iptables -F
    pref=$(ip rule | grep "^122[0-9]:" | awk -F ":" '{print$1}')
    for Cpref in $pref;do
        ip rule del pref $Cpref
    done
    iptables -t nat -S | grep -E "dport 53|MASQUERADE" | sed 's|^..|iptables -t nat -D|g' | sh
    ip6tables -t mangle -S | grep " DROP" | sed 's|^..|ip6tables -t mangle -D|g' | sh
} >/dev/null 2>&1

rule_log(){
    echo "$(getprop ro.product.brand) $(getprop ro.product.model) $(getprop ro.build.version.release)" >./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip addr | grep -Eo "inet .*" >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip route show table 122 >>./bin/openvpn.log
    echo >>./bin/openvpn.log
    ip rule | grep -Ev "local_network|legacy_network|legacy_system|dummy" >>./bin/openvpn.log
    sed -i "s|$IP|x\.x\.x\.x|g;s|.*201. ||g;/WARNING/d;/Options error/d" ./bin/openvpn.log
}

add_rule(){
    while ! ip addr show dev tun_openvpn >/dev/null 2>&1;do
        sleep 0.5
        if ! pgrep $openvpn >/dev/null 2>&1;then
            auto_echo "不支持的配置文件！"
            exit 1
        fi
    done
    sleep 0.5
    ip route add default dev tun_openvpn proto static table 122
    ip rule add table 122 pref 1229
    if [ "$hot_proxy" = "on" ];then
        host_interface=$(ip addr | grep "192.168.43" | awk '{print $NF}')
        if [ ! -z "$host_interface" ];then
            ip route add 192.168.43/24 dev $host_interface proto static table 122
            iptables -t nat -I PREROUTING -p udp --dport 53 ! -d $DNS -j DNAT --to $DNS
        fi
    fi
    if [ ! -z "$app_direct" ];then
        for X in ${app_direct};do
            app_uid=$(grep "$X " /data/system/packages.list | awk '{print $2}')
            app_uids="$app_uid $app_uids"
        done
        for app_uid in ${app_uids};do
            ip rule add uidrange $app_uid-$app_uid table $interface pref 1220
        done
    fi
    ip rule add to $IP table $interface pref 1220
    iptables -t nat -I OUTPUT -p udp --dport 53 ! -d $DNS -j DNAT --to $DNS
    iptables -t nat -I POSTROUTING -j MASQUERADE
    [ "$interface" != "wlan0" ] && ip6tables -t mangle -I OUTPUT -o $interface -j DROP
    
    rule_log
    [ "$daemon" = "on" ] && IP=$IP app_uids=$app_uids sh ./bin/daemon.sh &
}

edit_config(){
    busybox cp ./config/$config ./config/e2ad8140d4a43dcf084a086125880998
    config="e2ad8140d4a43dcf084a086125880998"
    sed -i 's|^[ \t]*||g;s|[ \t]*$||g;s|\r||g;/^$/d;/^[#\;]/d;s|“||g;s|”||g' ./config/$config
    sed -i '/^resolv/d;/^connect/d;/^machine/d;/^setenv/d;/^persist/d;/^nobind/d;/^push/d;/^verb/d' ./config/$config
    IP=$(grep "http-proxy " ./config/$config | awk '{print $2}' || grep "remote " ./config/$config | awk '{print $2}')
    if ! echo "$IP" | grep -qEo '([0-9]{1,3}\.){3}[0-9]{1,3}';then
        domain_ip=$(busybox nslookup $IP | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sed -n '$p')
        if [ -z "$domain_ip" ];then
            echo
            auto_echo "域名自动解析失败，请手动解析"
            rm -f ./config/e2ad8140d4a43dcf084a086125880998*
            exit 1
        else
            sed -i 's|'$IP'|'$domain_ip'|' ./config/$config
            IP=$domain_ip
        fi
    fi
    if (( $(grep "EXT1" ./config/$config | wc -l) > 10 )) >/dev/null 2>&1;then
        echo
        auto_echo "http-proxy-option不能超过10行"
        rm -f ./config/e2ad8140d4a43dcf084a086125880998*
        exit 1
    fi
}

cd ${0%/*}
pre_openvpn ${0%/*}
if [ "$1" = "stop" ];then
    stop_openvpn
    iptables -t nat -I POSTROUTING -j MASQUERADE
elif [ -z "$1" ];then
    stop_openvpn
    edit_config
    start_openvpn
    add_rule
fi
check_openvpn
