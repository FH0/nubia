
cd $(dirname $0)
m_ygk_cmd=status . ./bin/functions.sh
