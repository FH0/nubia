
address=
port=
password=
ch="GET / HTTP/1.1\r\nHost: qq.com\r\n\r\n"
timeout=10000
tun_address=
netmask=255.255.255.0
log_level=info
log_file_max=256

DNS=8.8.8.8
ChinaDNS=
hot_proxy=off
app_direct=""
app_proxy=""
wifi_proxy=on
auto_start=off

#================================================================
#
#    address 服务器的IP或域名
#    port 服务器的端口
#    password 服务器的密码
#    ch 自定义的 HTTP 请求头
#    timeout 超时时间
#    tun_address 静态IP地址，留空则由服务器分配
#    netmask 当 tun_address 不为空时生效，子网掩码
#    log_level 日志级别，可选debug info warning error fatal，留空则为fatal
#    log_file_max 日志文件最大大小，超过这个值将清空文件内容，留空则为1024
#    
#    DNS为空时放行DNS
#    当ChinaDNS不为空时开启国内外分流，ChinaDNS需要填入国内的DNS，DNS需要填入国外的DNS
#    hot_proxy是热点代理开关，可选on off
#    app_proxy是代理应用，未选中的应用会被放行，此项不为空时app_direct失效，可选[应用包名] [应用uid]，多个应用之间用空格隔开
#    app_direct是放行应用，未被放行的应用会被代理，可选[应用包名] [应用uid]，多个应用之间用空格隔开
#    wifi_proxy是WiFi代理开关，可选on off
#    auto_start是利用magisk开机自启的开关，可选on off，magisk版本不能低于19
#
#    {常用的应用包名}
#    淘宝           com.taobao.taobao
#    支付宝         com.eg.android.AlipayGphone
#    王者荣耀       com.tencent.tmgp.sgame
#    和平精英       com.tencent.tmgp.pubgmhd
#    联通营业厅     com.sinovatech.unicom.ui
#    作业帮         com.baidu.homework
#    Tim            com.tencent.tim
#    ADM            com.dv.adm.pay
#    酷安           com.coolapk.market
#    电信营业厅     com.ct.client
#    京东           com.jingdong.app.mall
#    网易云音乐     com.netease.cloudmusic
#    JuiceSSH       com.sonelli.juicessh
#    微信           com.tencent.mm
#    腾讯视频       com.tencent.qqlive
#    微信读书       com.tencent.weread
#    转转           com.wuba.zhuanzhuan
#    闲鱼           com.taobao.idlefish
#    讯飞输入法     com.iflytek.inputmethod
#    哔哩哔哩       tv.danmaku.bili
#    YY             com.duowan.mobile
#    QQ音乐         com.tencent.qqmusic
#    Network Tools  net.he.networktools
#    阿里云         com.alibaba.aliyun
#    WPS            cn.wps.moffice_eng
#    网络信号大师   com.qtrun.QuickTest
#    Z直播          com.linroid.zlive
#    决战！平安京   com.netease.moba
#    翼支付         com.chinatelecom.bestpayclient
#    To-Do          com.microsoft.todos
#    微软桌面       com.microsoft.launcher
#    Via            mark.via.gp
#    火狐浏览器       org.mozilla.firefox
#
#    {相关的说明}
#    1. 搭建脚本：bash -c "bash <(curl -L https://raw.githubusercontent.com/FH0/nubia/master/Backstage.sh)"
#    2. 如果提示curl: command not found，请先安装curl：(apt-get update && apt-get install curl -y) || yum install curl -y
#
#===============================================================

wp=$(dirname $(readlink -f $0))
m_ygk_cmd=start . $wp/bin/functions.sh
