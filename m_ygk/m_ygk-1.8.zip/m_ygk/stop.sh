
wp=$(dirname $(readlink -f $0))
m_ygk_cmd=stop . $wp/bin/functions.sh
