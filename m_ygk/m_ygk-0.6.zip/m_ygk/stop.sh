
cd $(dirname $0)
m_ygk_cmd=stop . ./bin/functions.sh
