#!/system/bin/sh

${0%/*}/start.sh
exit 0