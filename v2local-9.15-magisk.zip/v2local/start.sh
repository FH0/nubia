#!/system/bin/sh

jzdh=$1 && cd ${0%/*}

v2local_check() {
    echo
    v2ray_status="    ○⊃ V2Ray" && [ ! -z "$(pgrep 'v2ray$')" ] && v2ray_status="    ⊂● V2Ray"
    [ "$dns_proxy" = "on" ] && pdnsd_status="   ○⊃ pdnsd"
    [ -z "$(pgrep pdnsd)" ] || pdnsd_status="   ⊂● pdnsd"
    [ "$udp_proxy" = "on" ] && Redsocks2_status="   ○⊃ Redsocks2"
    [ -z "$(pgrep redsocks2)" ] || Redsocks2_status="   ⊂● Redsocks2"
    echo "${v2ray_status} ${pdnsd_status} ${Redsocks2_status}"
    if [ ! -z "${app_direct}" ];then
        echo
        for X in ${app_direct};do
            app_info=$(grep "$X " /data/system/packages.list)
            F=$(echo "$app_info" | awk '{print $2}')
            X=$(echo "$app_info" | awk '{print $1}')
            [ -z "$F" ] || echo "    ${F} ${X}"
        done
        echo
    fi
}

v2local_stop() {
    pkill "^v2ray$"
    pkill "^pdnsd$"
    pkill "^redsocks2$"
    ip route flush cache
    ip rule del fwmark 0x1112 table 121
    ip route del local 0.0.0.0/0 dev lo table 121
    iptables -t nat -F VNO
    iptables -t nat -F VNP
    iptables -t mangle -F VMO
    iptables -t mangle -F VMP
    iptables -t nat -D OUTPUT -j VNO
    iptables -t nat -D PREROUTING -j VNP
    iptables -t mangle -D OUTPUT -j VMO
    iptables -t mangle -D PREROUTING -j VMP
    iptables -t nat -X VNO
    iptables -t nat -X VNP
    iptables -t mangle -X VMO
    iptables -t mangle -X VMP
    echo "0" > /proc/sys/net/ipv6/conf/all/disable_ipv6
} > /dev/null 2>&1

pre_v2local() {
    mount -o rw,remount /system
    source $(pwd)/v2ray.ini
    export PATH=${PATH}:$(pwd)/bin
    chmod -R 777 $(pwd)
    for C in awk grep sed pkill chmod rm pgrep nohup sleep;do
        if [ ! -f "/system/bin/$C" ];then
            busybox cp bin/busybox /system/bin/$C
        fi
    done
    rm -f *.bak
    rm -f */*.bak
}

vim_config() {
    UUID=$(echo "$v2ray" | awk '{print $2}')
    address=$(echo "$v2ray" | awk '{print $1}')
    for E in config.json break_copyright.json;do
        sed -i 's|address.*|address": "'$address'",|g' bin/${E}
        sed -i 's|^          "port.*|          "port": '$port',|g' bin/${E}
        sed -i 's|"id".*|"id": "'$UUID'",|g' bin/${E}
        sed -i 's|"alterId".*|"alterId": '$alterId',|g' bin/${E}
        sed -i 's|"security".*|"security": "'$security'"|g' bin/${E}
        sed -i 's|"path": \[".*"\]|"path": \["'$Path'"\]|g' bin/${E}
        sed -i 's|"Host": \[".*"\]|"Host": \["'$Host'"\]|g' bin/${E}
    done
    sed -i 's|.* ip.*|    ip = '$DNS_ip'\;|' bin/pdnsd.conf
    sed -i 's|file =.*|file = "'$hosts'"\;|' bin/pdnsd.conf
}

v2local_bin_start() {
    [ "$dns_proxy" = "on" ] && nohup pdnsd -c bin/pdnsd.conf &
    config=config && [ "$break_copyright" = "on" ] && config=break_copyright
    nohup v2ray -config bin/${config}.json &
    sleep $v2ray_wait
    nohup redsocks2 -c bin/redsocks2.conf &
    mount -o ro,remount /system
} > /dev/null 2>&1

add_iptables() {
    iptables -t nat -N VNO
    iptables -t nat -I OUTPUT -j VNO
    iptables -t nat -N VNP
    iptables -t nat -I PREROUTING -j VNP
    iptables -t mangle -N VMO
    iptables -t mangle -N VMP
    iptables -t mangle -I OUTPUT -j VMO
    iptables -t mangle -I PREROUTING -j VMP
}

app_direct() {
    for X in ${app_direct};do
        app_info=$(grep "$X " /data/system/packages.list)
        F=$(echo "$app_info" | awk '{print $2}')
        X=$(echo "$app_info" | awk '{print $1}')
        [ -z "$F" ] || iptables -t mangle -A VMO -m owner --uid-owner $F -j ACCEPT
        [ -z "$F" ] || iptables -t nat -A VNO -m owner --uid-owner $F -j ACCEPT
    done
}

udp_iptables() {
    special_ip='0/8,10/8,127/8,192.168/16,255.255/8,240/4,224/3,169.254/16,100.64/10,172.16/12'
    ip route add local 0.0.0.0/0 dev lo table 121
    ip rule add fwmark 0x1112 table 121
    [ "$wifi_proxy" = "off" ] && iptables -t mangle -A VMO -o wlan+ -j ACCEPT
    iptables -t mangle -A VMO -d "$special_ip" -j ACCEPT
    iptables -t mangle -A VMP -d "$special_ip" -j ACCEPT
    iptables -t mangle -A VMO -p udp ! --dport 53 -j MARK --set-mark 0x1112
    iptables -t mangle -A VMP -p udp -j TPROXY --on-port 1114 --tproxy-mark 0x1112
    [ "$?" = "2" ] && echo && echo "  TPROXY启动失败，请关掉UDP代理" && (v2local_stop;exit 0)
}

necessary_iptables() {
    echo "1" > /proc/sys/net/ipv6/conf/all/disable_ipv6
    [ "$wifi_proxy" = "off" ] && iptables -t nat -A VNO -o wlan+ -j ACCEPT
    [ "$dns_proxy" = "on" ] && iptables -t nat -A VNO -p udp --dport 53 -j REDIRECT --to 1113
    [ -z "$network_whitelist" ] || iptables -t mangle -I VMO -o $network ! -s "${network_whitelist}/16" -j DROP
    iptables -t nat -A VNO -m owner --uid-owner 0  -p tcp -d $address --dport $port -j ACCEPT
    [ "$break_copyright" = "on" ] && iptables -t nat -A VNO -p tcp --dport 80 -m owner --uid-owner 0 -j ACCEPT
    iptables -t nat -A VNO -p tcp -d 192.168/16 -j ACCEPT
    iptables -t nat -A VNO -o lo -j ACCEPT    
    iptables -t nat -A VNO -p tcp -j REDIRECT --to 1111
}

hot_tcp_iptables() {
    iptables -t nat -A VNP -p tcp -d 192.168/16 -j ACCEPT
    [ "$dns_proxy" = "on" ] && iptables -t nat -A VNP -p udp --dport 53 -j REDIRECT --to 1113
    iptables -t nat -A VNP -p tcp -j REDIRECT --to 1111
}

control_network() {
    network_ip=$(ip addr show $network | grep -Eo "[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*")
    judge_network_ip=$(echo $network_ip | grep "^$network_whitelist")
    var=1
    if [ ! -z "$network_ip" ];then
        echo "  当前IP：$network_ip" && echo
        while [ -z "$judge_network_ip" ];do
            settings put global airplane_mode_on 1
            am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true > /dev/null 2>&1
            sleep $plane_stop
            settings put global airplane_mode_on 0
            am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false > /dev/null 2>&1
            sleep $plane_wait
            network_ip=$(ip addr show $network | grep -Eo "[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*")
            judge_network_ip=$(echo $network_ip | grep "^$network_whitelist")
            echo "  当前IP：$network_ip" && echo
            [ "$var" = "20" ] && v2local_check && exit 0
            var=$(($var+1))
        done
    fi
}

main() {
    #检查权限，定义变量
    pre_v2local
    if [ -z "$jzdh" ];then
        #停止v2local
        v2local_stop
        #调内网
        [ -z "$network_whitelist" ] || control_network
        #编辑配置文件
        vim_config
        #启动相关模块
        v2local_bin_start
        #创建初始规则
        add_iptables
        #放行应用
        [ -z "$app_direct" ] || app_direct
        #udp规则
        [ "$udp_proxy" = "on" ] && udp_iptables
        #热点规则
        [ "$hot_tcp_proxy" = "on" ] && hot_tcp_iptables
        #tcp主规则
        necessary_iptables
        #获取v2local运行状态
        v2local_check
        exit 0
    elif [ "$jzdh" = "stop" ];then
        #停止v2local
        v2local_stop
        #获取v2local运行状态
        v2local_check
        exit 0
    elif [ "$jzdh" = "check" ];then
        #获取v2local运行状态
        v2local_check
        exit 0
    fi
}

main