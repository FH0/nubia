#!/system/bin/sh

${0%/*}/start.sh stop
exit 0