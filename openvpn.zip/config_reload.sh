#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/openvpn"

if grep -q "^nobody:" /etc/group;then
	group=nobody
else
	group=nogroup
fi

clients=$(tail -n +2 $wp/EasyRSA/pki/index.txt | grep "^V" | awk -F "=" '{print $2}' | tr '\n' ' ')
Num=$(cat $wp/openvpn.ini | wc -l)
public_ip=$(grep "^##" /bin/op | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')

rm -f $wp/client/*
for C in $clients;do
	for T in $(seq 1 $Num);do
		protocol=$(sed -n "${T}p" $wp/openvpn.ini | awk '{print $1}')
		port=$(sed -n "${T}p" $wp/openvpn.ini | awk '{print $2}')
		echo -e "client\ndev tun\nproto $protocol\nsndbuf 0\nrcvbuf 0\nremote $public_ip $port\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\nremote-cert-tls server\nauth SHA512\ncipher AES-256-CBC\ncomp-lzo\nsetenv opt block-outside-dns\nkey-direction 1\nverb 3" > $wp/client/${C}_${protocol}_$port.ovpn
		echo "<ca>" >> $wp/client/${C}_${protocol}_$port.ovpn
		cat $wp/server/ca.crt >> $wp/client/${C}_${protocol}_$port.ovpn
		echo "</ca>" >> $wp/client/${C}_${protocol}_$port.ovpn
		echo "<cert>" >> $wp/client/${C}_${protocol}_$port.ovpn
		cat $wp/EasyRSA/pki/issued/$C.crt >> $wp/client/${C}_${protocol}_$port.ovpn
		echo "</cert>" >> $wp/client/${C}_${protocol}_$port.ovpn
		echo "<key>" >> $wp/client/${C}_${protocol}_$port.ovpn
		cat $wp/EasyRSA/pki/private/$C.key >> $wp/client/${C}_${protocol}_$port.ovpn
		echo "</key>" >> $wp/client/${C}_${protocol}_$port.ovpn
		echo "<tls-auth>" >> $wp/client/${C}_${protocol}_$port.ovpn
		cat $wp/server/ta.key >> $wp/client/${C}_${protocol}_$port.ovpn
		echo "</tls-auth>" >> $wp/client/${C}_${protocol}_$port.ovpn
	done
done

rm -f $wp/server/*\.conf
for T in $(seq 1 $Num);do
	protocol=$(sed -n "${T}p" $wp/openvpn.ini | awk '{print $1}')
	port=$(sed -n "${T}p" $wp/openvpn.ini | awk '{print $2}')
	echo -e "port $port\nproto $protocol\ndev tun\nsndbuf 0\nrcvbuf 0\nca ca.crt\ncert server.crt\nkey server.key\ndh dh.pem\nauth SHA512\ntls-auth ta.key 0\ntopology subnet\nserver 10.8.0.0 255.255.255.0\nifconfig-pool-persist ipp.txt\npush \"redirect-gateway def1 bypass-dhcp\"" > $wp/server/${protocol}_$port.conf
	DNSs=$(grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' /etc/resolv.conf)
	for J in $DNSs;do
		echo "push \"dhcp-option DNS $J\"" >> $wp/server/${protocol}_$port.conf
	done
	echo -e "keepalive 10 120\ncipher AES-256-CBC\ncomp-lzo\nuser nobody\ngroup $group\npersist-key\npersist-tun\nverb 3\ncrl-verify crl.pem" >> $wp/server/${protocol}_$port.conf
done
