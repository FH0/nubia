#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/openvpn"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    [ -z "$(command -v yum)" ] && Installer="apt-get" || Installer="yum"
    var="0"
    for command in $1;do
        if ! echo "$CHECK" | grep -q "$command";then
            [ "$var" = "0" ] && apt-get update && var="1"
            $Installer install $command -y
        fi > /dev/null 2>&1
    done
}

init_key(){
	cd $wp/server
	chmod +x $wp/openvpn
	$wp/openvpn --genkey --secret ta.key
	cd $wp/EasyRSA
	chmod +x $wp/EasyRSA/easyrsa
	$wp/EasyRSA/easyrsa init-pki
	$wp/EasyRSA/easyrsa --batch build-ca nopass
	$wp/EasyRSA/easyrsa gen-dh
	$wp/EasyRSA/easyrsa build-server-full server nopass
	cp $wp/EasyRSA/pki/ca.crt \
		$wp/EasyRSA/pki/private/ca.key \
		$wp/EasyRSA/pki/dh.pem \
		$wp/EasyRSA/pki/issued/server.crt \
		$wp/EasyRSA/pki/private/server.key \
		$wp/server
}

install_openvpn(){
    colorEcho $BLUE "正在初始化openvpn证书..."
	init_key >/dev/null 2>&1
	
    colorEcho $BLUE "正在开启openvpn自启程序..."
    cat $wp/openvpn.service > /etc/systemd/system/openvpn.service
    cat $wp/openvpn_nginx.service > /etc/systemd/system/openvpn_nginx.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装openvpn控制面板..."
    cat $wp/manage_panel.sh > /bin/op
    chmod +x /bin/op
    
    colorEcho $BLUE "正在调整内核参数..."
    sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
	echo "net.ipv4.ip_forward = 1" >> /etc/sysctl.conf
	echo 1 > /proc/sys/net/ipv4/ip_forward
    
    colorEcho $BLUE "正在设置随机网址..."
    random=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
    sed -i "s|listen.*|listen       $(shuf -i 1024-65535 -n 1);|" $wp/nginx.conf
    nginx_path=($(grep -n "location" $wp/nginx.conf))
    sed -i "${nginx_path[0]%:}s|location.*|location /$random {|" $wp/nginx.conf

    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1
}

main(){
    cmd_need "iproute"
    install_openvpn
	touch $wp/openvpn.ini
    mkdir -p /usr/local/nginx/logs
    colorEcho $GREEN "openvpn安装完成！输入op可进入控制面板！"
}

main
