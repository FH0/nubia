#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/openvpn"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

add_port() {
    colorRead ${YELLOW} '请输入端口[默认随机]' Port
    [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
    echo " 1. tcp"
    echo " 2. udp"
    echo
    colorRead ${YELLOW} '请选择协议[默认udp]' protocol
    [ -z "$protocol" ] && protocol=2
    [ "$protocol" = "1" ] && protocol=tcp
    [ "$protocol" = "2" ] && protocol=udp
    echo "$protocol $Port" >> $wp/openvpn.ini
    $wp/config_reload.sh
    systemctl restart openvpn.service
}

del_port() {
    var=1
    for D in $openvpn_ports;do
        echo -e " $var. 删除${YELLOW}$D\033[0m端口"
        ((var++))
    done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    if [ ! -z "$input_choice" ];then
        sed -i "${input_choice}d" $wp/openvpn.ini
        if grep -q "[0-9]" $wp/openvpn.ini;then
            $wp/config_reload.sh
			systemctl restart openvpn.service
        else
            systemctl stop openvpn.service
        fi
    fi
}

add_user(){
    colorRead ${YELLOW} '请输入用户名' client_name
	if [ ! -z "$client_name" ];then
		cd $wp/EasyRSA
		$wp/EasyRSA/easyrsa build-client-full $client_name nopass
		EASYRSA_CRL_DAYS=3650 $wp/EasyRSA/easyrsa gen-crl
		cat $wp/EasyRSA/pki/crl.pem > $wp/server/crl.pem
		$wp/config_reload.sh
		systemctl restart openvpn.service
	fi >/dev/null 2>&1
}

del_user(){
    var=1
    for D in $clients;do
        echo -e " $var. 删除${YELLOW}$D\033[0m用户"
        ((var++))
	done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    if [ ! -z "$input_choice" ];then
		cd $wp/EasyRSA
        client_name=$(echo $clients | awk '{print $'$input_choice'}')
		$wp/EasyRSA/easyrsa --batch revoke $client_name
		EASYRSA_CRL_DAYS=3650 $wp/EasyRSA/easyrsa gen-crl
		rm -f $wp/EasyRSA/pki/reqs/$client_name.req
		rm -f $wp/EasyRSA/pki/private/$client_name.key
		rm -f $wp/EasyRSA/pki/issued/$client_name.crt
		cat $wp/EasyRSA/pki/crl.pem > $wp/server/crl.pem
		clients=$(tail -n +2 $wp/EasyRSA/pki/index.txt | grep "^V" | awk -F "=" '{print $2}' | tr '\n' ' ')
		if [ -z "$clients" ];then
			systemctl stop openvpn.service
		else
			$wp/config_reload.sh
			systemctl restart openvpn.service
		fi
    fi
}

reset_openvpn() {
    read
	
	rm -rf $wp/EasyRSA/pki
	$wp/EasyRSA/easyrsa init-pki
	$wp/EasyRSA/easyrsa --batch build-ca nopass
	$wp/EasyRSA/easyrsa gen-dh
	$wp/EasyRSA/easyrsa build-server-full server nopass
	cp $wp/EasyRSA/pki/ca.crt \
		$wp/EasyRSA/pki/private/ca.key \
		$wp/EasyRSA/pki/dh.pem \
		$wp/EasyRSA/pki/issued/server.crt \
		$wp/EasyRSA/pki/private/server.key \
		$wp/server
	
	for J in $clients;do
		$wp/EasyRSA/easyrsa build-client-full $J nopass
	done
	
	cd $wp/server
	$wp/openvpn --genkey --secret ta.key
	
	$wp/config_reload.sh
	EASYRSA_CRL_DAYS=3650 $wp/EasyRSA/easyrsa gen-crl
	cat $wp/EasyRSA/pki/crl.pem > $wp/server/crl.pem
	systemctl restart openvpn.service
}

panel(){
	openvpn_status="${RED}" && systemctl is-active -q openvpn.service && openvpn_status="$GREEN"
    nginx_status="${RED}" && systemctl is-active -q openvpn_nginx.service && nginx_status="$GREEN"
    ports_num=$(cat $wp/openvpn.ini | wc -l)
    connections=""
    for S in $(seq 1 $ports_num);do
        protocol=$(sed -n "${S}p" $wp/openvpn.ini | awk '{print $1}')
		Port=$(sed -n "${S}p" $wp/openvpn.ini | awk '{print $2}')
		connection=$(echo -e "[${YELLOW}$protocol $Port ${GREEN}$(ss -o state established sport = :$Port | awk '{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l)\033[0m]")
        connections="$connection $connections"
    done
	clients=$(tail -n +2 $wp/EasyRSA/pki/index.txt 2>&1 | grep "^V" | awk -F "=" '{print $2}' | tr '\n' ' ')
    var=1

    if [ "$nginx_status" = "$GREEN" ];then
        Port=$(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*")
        Path=($(grep -n "location" $wp/nginx.conf))
        random_path=${Path[2]}
        echo
        echo -e "${BLUE}客户端配置文件下载地址: ${YELLOW}http://$public_ip:$Port$random_path\033[0m"
    fi
    echo
    echo -e "${YELLOW}用户 ${GREEN}$clients\033[0m"
    if [ "$openvpn_status" = "$GREEN" ];then
		echo
		echo -e "[${YELLOW}协议 端口 ${GREEN}连接数\033[0m] $connections"
	fi
    echo
    echo -e "  $var. 开/关${openvpn_status}openvpn\033[0m" && ((var++))
	echo -e "  $var. 开/关${nginx_status}客户端配置文件下载\033[0m" && ((var++))
    echo "  $var. 卸载openvpn" && ((var++))
    echo "  $var. 添加一个用户" && ((var++))
    echo "  $var. 删除一个用户" && ((var++))
    echo "  $var. 添加一个端口" && ((var++))
    echo "  $var. 删除一个端口" && ((var++))
    echo "  $var. 重置所有秘钥" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "$openvpn_status" = "$GREEN" ];then
                systemctl stop openvpn.service
                systemctl disable openvpn.service
            elif grep -q "[0-9]" $wp/openvpn.ini;then
                systemctl start openvpn.service
                systemctl enable openvpn.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        2)
            if [ "$nginx_status" = "$GREEN" ];then
                systemctl stop openvpn_nginx.service
                systemctl disable openvpn_nginx.service
            else
                systemctl start openvpn_nginx.service
                systemctl enable openvpn_nginx.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        3)
            read
            bash $wp/uninstall.sh
            clear && echo "openvpn已卸载！"
            ;;
        4)
            add_user
            clear && panel
            ;;
        5)
            [ ! -z "$clients" ] && del_user
            panel
            ;;
        6)
            add_port
            clear && panel
            ;;
        7)
            openvpn_ports=$(awk '{print $2}' $wp/openvpn.ini)
			[ ! -z "$openvpn_ports" ] && del_port
            clear && panel
            ;;
        8)
            reset_openvpn
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -qE "^##([0-9]{1,3}\.){3}[0-9]{1,3}" $0;then
    public_ip=$(ifconfig | grep 'inet ' | awk '{print $2}' | grep -Ev '^10\.|^192\.168|^172\.[1-3]|^127\.' | sed -n '1p')
    [ -z "$public_ip" ] && public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    country=$(grep "^##" $0 | awk '{print $2}')
else
    JSON=$(curl -s http://ip-api.com/json)
    public_ip=$(echo $JSON | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    country=$(echo $JSON | sed 's|.*"countryCode":"\(..\)".*|\1|')
    [ -z "$JSON" ] || sed -i '$a##'$public_ip' '$country'' $0
fi

clear && panel
