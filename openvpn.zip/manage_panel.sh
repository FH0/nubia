#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/openvpn"
. $wp/functions.sh

add_port() {
    colorRead ${YELLOW} '请输入端口[默认随机]' Port
    [ -z "$Port" ] && Port=$(random_port)
    echo " 1. tcp"
    echo " 2. udp"
    echo
    colorRead ${YELLOW} '请选择协议[默认udp]' protocol
    [ -z "$protocol" ] && protocol=2
    [ "$protocol" = "1" ] && protocol=tcp
    [ "$protocol" = "2" ] && protocol=udp
    echo "$protocol $Port" >> $wp/openvpn.ini
	if [ ! -z "$clients" ];then
		$wp/config_reload.sh
		start_service
	fi
}

del_port() {
    var=1
    for D in $openvpn_ports;do
        echo -e " $var. 删除${YELLOW}$D${BLANK}端口"
        ((var++))
    done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    if [ ! -z "$input_choice" ];then
        sed -i "${input_choice}d" $wp/openvpn.ini
        if grep -q "[0-9]" $wp/openvpn.ini && [ ! -z "$clients" ];then
            $wp/config_reload.sh
			start_service
        else
            stop_service
        fi
    fi
}

add_user(){
    colorRead ${YELLOW} '请输入用户名[默认随机]' client_name
	[ -z "$client_name" ] && client_name=$(random_password 4)
	cd $wp/EasyRSA
	$wp/EasyRSA/easyrsa build-client-full $client_name nopass >/dev/null 2>&1
	EASYRSA_CRL_DAYS=3650 $wp/EasyRSA/easyrsa gen-crl >/dev/null 2>&1
	cat $wp/EasyRSA/pki/crl.pem > $wp/server/crl.pem
	if grep -q "[0-9]" $wp/openvpn.ini;then
		$wp/config_reload.sh >/dev/null 2>&1
		start_service
	fi
}

del_user(){
    var=1
    for D in $clients;do
        echo -e " $var. 删除${YELLOW}$D${BLANK}用户"
        ((var++))
	done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    if [ ! -z "$input_choice" ];then
		cd $wp/EasyRSA
        client_name=$(echo $clients | awk '{print $'$input_choice'}')
		$wp/EasyRSA/easyrsa --batch revoke $client_name
		EASYRSA_CRL_DAYS=3650 $wp/EasyRSA/easyrsa gen-crl
		rm -f $wp/EasyRSA/pki/reqs/$client_name.req
		rm -f $wp/EasyRSA/pki/private/$client_name.key
		rm -f $wp/EasyRSA/pki/issued/$client_name.crt
		cat $wp/EasyRSA/pki/crl.pem > $wp/server/crl.pem
		clients=$(tail -n +2 $wp/EasyRSA/pki/index.txt | grep "^V" | awk -F "=" '{print $2}' | tr '\n' ' ')
		if grep -q "[0-9]" $wp/openvpn.ini && [ ! -z "$clients" ];then
			$wp/config_reload.sh
			start_service
		else
			stop_service
		fi
    fi
}

reset_openvpn() {
    read
	
	rm -rf $wp/EasyRSA/pki
	cd $wp/EasyRSA
	$wp/EasyRSA/easyrsa init-pki
	$wp/EasyRSA/easyrsa --batch build-ca nopass
	$wp/EasyRSA/easyrsa gen-dh
	$wp/EasyRSA/easyrsa build-server-full server nopass
	cp $wp/EasyRSA/pki/ca.crt \
		$wp/EasyRSA/pki/private/ca.key \
		$wp/EasyRSA/pki/dh.pem \
		$wp/EasyRSA/pki/issued/server.crt \
		$wp/EasyRSA/pki/private/server.key \
		$wp/server
	
	for J in $clients;do
		$wp/EasyRSA/easyrsa build-client-full $J nopass
	done
	
	EASYRSA_CRL_DAYS=3650 $wp/EasyRSA/easyrsa gen-crl
	cat $wp/EasyRSA/pki/crl.pem > $wp/server/crl.pem

	cd $wp/server
	LD_LIBRARY_PATH="$wp" $wp/openvpn --genkey --secret ta.key
	
	$wp/config_reload.sh
	start_service
}

panel(){
	public_ip=$(ip_info get_ip)
	openvpn_status="${RED}" && pgrep -f $wp/openvpn >/dev/null && openvpn_status="$GREEN"
    ports_num=$(cat $wp/openvpn.ini | wc -l)
    connections=""
    for S in $(seq 1 $ports_num);do
        protocol=$(sed -n "${S}p" $wp/openvpn.ini | awk '{print $1}')
		Port=$(sed -n "${S}p" $wp/openvpn.ini | awk '{print $2}')
		connection=$(echo -e "[${YELLOW}$protocol $Port ${GREEN}$(get_connections)${BLANK}]")
        connections="$connection $connections"
    done
	clients=$(tail -n +2 $wp/EasyRSA/pki/index.txt 2>&1 | grep "^V" | awk -F "=" '{print $2}' | tr '\n' ' ')
    var=1

	Port=$(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*")
	Path=($(grep -n "location" $wp/nginx.conf))
	random_path=${Path[2]}
	echo
	echo -e "${BLUE}客户端配置文件下载地址: ${YELLOW}http://$public_ip:$Port$random_path${BLANK}"
    echo
    echo -e "${YELLOW}用户 ${GREEN}$clients${BLANK}"
    if [ "$openvpn_status" = "$GREEN" ];then
		echo
		echo -e "[${YELLOW}协议 端口 ${GREEN}连接数${BLANK}] $connections"
	fi
    echo
    echo -e "  $var. 开/关${openvpn_status}openvpn${BLANK}" && ((var++))
    echo "  $var. 卸载openvpn" && ((var++))
    echo "  $var. 添加一个用户" && ((var++))
    echo "  $var. 删除一个用户" && ((var++))
    echo "  $var. 添加一个端口" && ((var++))
    echo "  $var. 删除一个端口" && ((var++))
    echo "  $var. 重置所有证书" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "$openvpn_status" = "$GREEN" ];then
                stop_service
            elif grep -q "[0-9]" $wp/openvpn.ini && [ ! -z "$clients" ];then
                start_service
            fi
            clear && panel
            ;;
        2)
            if warning_read;then
				bash $wp/uninstall.sh
				clear && echo "openvpn已卸载！"
			else
				clear && panel
			fi
            ;;
        3)
            add_user
            clear && panel
            ;;
        4)
            [ ! -z "$clients" ] && del_user
            clear && panel
            ;;
        5)
            add_port
            clear && panel
            ;;
        6)
            openvpn_ports=$(awk '{print $2}' $wp/openvpn.ini)
			[ ! -z "$openvpn_ports" ] && del_port
            clear && panel
            ;;
        7)
            reset_openvpn
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
