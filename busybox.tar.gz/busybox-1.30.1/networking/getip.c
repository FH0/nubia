//config:config GETIP
//config:       bool "getip"
//config:       default y
//config:       select PLATFORM_LINUX
//config:       help
//config:

//applet:IF_GETIP(APPLET(getip, BB_DIR_USR_BIN, BB_SUID_DROP))

//kbuild:lib-$(CONFIG_GETIP) += getip.o

//usage:#define getip_trivial_usage "None"
//usage:#define getip_full_usage "None"

#include "libbb.h"

int getip_main(int argc,char **argv)
{
    if( argc != 2 )
        exit(1);
	len_and_sockaddr *lsa;
	lsa = xhost_and_af2sockaddr(argv[1], 0, AF_INET);
	char *dotted;
	dotted = xmalloc_sockaddr2dotted_noport(&lsa->u.sa);
	puts(dotted);
    return 0;
}

