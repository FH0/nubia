#!/bin/bash

alias qq=ls

yy(){
qq
}
yy
