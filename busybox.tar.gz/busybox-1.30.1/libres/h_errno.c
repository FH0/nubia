int diet_h_errno;
