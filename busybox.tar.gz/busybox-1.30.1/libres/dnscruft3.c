#include <netinet/in.h>
#include <resolv.h>
#include <netdb.h>
#include "dietdns.h"

struct diet_res_state _diet_res; /* don't ask. */
