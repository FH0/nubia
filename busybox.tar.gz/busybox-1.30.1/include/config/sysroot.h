#define CONFIG_SYSROOT "/usr/local/android-arm/sysroot"
