#undef CONFIG_SEQ
