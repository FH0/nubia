#undef CONFIG_ASH
