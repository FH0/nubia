#undef CONFIG_WHO
