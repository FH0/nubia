#undef CONFIG_TC
