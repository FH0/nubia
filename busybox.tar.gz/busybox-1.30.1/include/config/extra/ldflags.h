#define CONFIG_EXTRA_LDFLAGS "-L/usr/local/android-aarch64/sysroot/usr/lib -static"
