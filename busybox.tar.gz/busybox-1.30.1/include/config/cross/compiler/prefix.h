#define CONFIG_CROSS_COMPILER_PREFIX "aarch64-linux-android-"
