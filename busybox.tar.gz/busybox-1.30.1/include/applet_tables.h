/* This is a generated file, don't edit */

#define NUM_APPLETS 12
#define KNOWN_APPNAME_OFFSETS 0

const char applet_names[] ALIGN1 = ""
"awk" "\0"
"basename" "\0"
"chmod" "\0"
"echo" "\0"
"getip" "\0"
"grep" "\0"
"killall" "\0"
"pgrep" "\0"
"pkill" "\0"
"rm" "\0"
"sed" "\0"
"sort" "\0"
;

#define APPLET_NO_awk 0
#define APPLET_NO_basename 1
#define APPLET_NO_chmod 2
#define APPLET_NO_echo 3
#define APPLET_NO_getip 4
#define APPLET_NO_grep 5
#define APPLET_NO_killall 6
#define APPLET_NO_pgrep 7
#define APPLET_NO_pkill 8
#define APPLET_NO_rm 9
#define APPLET_NO_sed 10
#define APPLET_NO_sort 11

#ifndef SKIP_applet_main
int (*const applet_main[])(int argc, char **argv) = {
awk_main,
basename_main,
chmod_main,
echo_main,
getip_main,
grep_main,
kill_main,
pgrep_main,
pgrep_main,
rm_main,
sed_main,
sort_main,
};
#endif

const uint8_t applet_suid[] ALIGN1 = {
0x00,
0x00,
0x00,
};

