#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/oneindex"

systemctl stop oneindex.service
systemctl disable oneindex.service >/dev/null 2>&1
rm -f /etc/systemd/system/oneindex.service
systemctl daemon-reload ; systemctl reset-failed

rm -rf $wp
rm -f /bin/oi
