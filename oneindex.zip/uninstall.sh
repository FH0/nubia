#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/oneindex"

systemctl stop oneindex.service
systemctl disable oneindex.service >/dev/null 2>&1
rm -f /etc/systemd/system/oneindex.service
systemctl daemon-reload ; systemctl reset-failed

rm -rf $wp
rm -f /bin/oi
