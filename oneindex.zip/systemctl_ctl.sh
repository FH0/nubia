#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/oneindex"

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
kill -9 $(ps -ef | grep "$wp/oneindex" | grep -v "grep" | awk '{print $2}')

if [ "$1" = "start" ];then
    for dport in $(cat $wp/oneindex.ini);do
        iptables -I INPUT -p tcp --dport $dport -m comment --comment "$wp" -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m comment --comment "$wp" -j ACCEPT
    done
	cd $wp/oneindex
    if command -v setcap;then
        setcap cap_net_bind_service=+ep ../php
        su -s /bin/bash nobody -c "../php -S 0.0.0.0:$(cat ../oneindex.ini)"
    else
        ../php -S 0.0.0.0:$(cat ../oneindex.ini)
    fi
fi
