#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/oneindex"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

chPort() {
    colorRead ${YELLOW} '请输入端口[默认随机]' Port
    [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
    echo "$Port" > $wp/oneindex.ini
    systemctl restart oneindex.service
}

panel(){
    oneindex_status="${RED}" && systemctl is-active -q oneindex.service && oneindex_status="$GREEN"
    Port=$(cat $wp/oneindex.ini)
    var=1

    echo
	if [ "$oneindex_status" = "$GREEN" ];then 
		echo -e "oneindex地址: $YELLOW$public_ip:$Port\033[0m"
		echo
	fi
    echo -e "  $var. 开/关${oneindex_status}oneindex\033[0m ${GREEN}$core_version\033[0m" && ((var++))
    echo "  $var. 卸载oneindex" && ((var++))
    echo "  $var. 更改端口" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "$oneindex_status" = "$GREEN" ];then
                systemctl stop oneindex.service
                systemctl disable oneindex.service
            elif grep -q "[0-9]" $wp/oneindex.ini;then
                systemctl start oneindex.service
                systemctl enable oneindex.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        2)
            read
            bash $wp/uninstall.sh
            clear && echo "oneindex已卸载！"
            ;;
        3)
            chPort
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -qE "^##([0-9]{1,3}\.){3}[0-9]{1,3}" $0;then
    public_ip=$(ifconfig | grep 'inet ' | awk '{print $2}' | grep -Ev '^10\.|^192\.168|^172\.[1-3]|^127\.' | sed -n '1p')
    [ -z "$public_ip" ] && public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    country=$(grep "^##" $0 | awk '{print $2}')
else
    JSON=$(curl -s http://ip-api.com/json)
    public_ip=$(echo $JSON | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    country=$(echo $JSON | sed 's|.*"countryCode":"\(..\)".*|\1|')
    [ -z "$JSON" ] || sed -i '$a##'$public_ip' '$country'' $0
fi

clear && panel
