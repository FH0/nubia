#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/oneindex"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

install_oneindex(){
    if ! apt-get install libcap2-bin -y >/dev/null 2>&1;then
        yum install libcap -y
    fi >/dev/null 2>&1
    
    colorEcho $BLUE "正在开启oneindex自启程序..."
    cat $wp/oneindex.service > /etc/systemd/system/oneindex.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装oneindex控制面板..."
    cat $wp/manage_panel.sh > /bin/oi
    chmod +x /bin/oi
    
    colorEcho $BLUE "正在启动oneindex..."
	Port=$(shuf -i 1024-65535 -n 1)
	echo $Port > $wp/oneindex.ini
	systemctl start oneindex.service >/dev/null 2>&1
	systemctl enable oneindex.service >/dev/null 2>&1
    
    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1
}

main(){
    install_oneindex
    colorEcho $GREEN "oneindex安装完成！输入oi可进入控制面板！"
}

main
