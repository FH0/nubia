
wp=$(cd "$(dirname $0)"; pwd)
. $wp/config.ini
type shopt >/dev/null 2>&1 && shopt -s expand_aliases
for C in $($wp/bin/busybox --list);do
    alias $C="$wp/bin/busybox $C"
done
echo $wp | grep -q "^/system" && mount -o rw,remount /system >/dev/null 2>&1
chmod -R 777 $wp

vim_config(){
    cp $wp/config/$config $wp/config/fddf83c9c6a72ba254c0ccc1d63fc6a4.ovpn
    echo -e "$user\n$password" > $wp/config/user.password

    echo -e "port=1113\nserver=$DNS\ncache-size=4096" > $wp/bin/dnsmasq.conf
    rm -f *.bak $wp/bin/*.bak $wp/bin/openvpn.log
}

bin_start(){
    iptables --help | grep -q "xtables" && xtables="-w"
    echo 1 >/proc/sys/net/ipv4/conf/all/route_localnet
    iptables $xtables -t nat -I OUTPUT -m comment --comment "tun_openvpn" -p udp --dport 53 ! -d 8.8.8.8 -j DNAT --to 8.8.8.8
    iptables $xtables -t nat -I POSTROUTING -m comment --comment "tun_openvpn" -j MASQUERADE
    if [ -z "$user" ];then
        $wp/bin/openvpN --daemon ovpn-client --config $wp/config/fddf83c9c6a72ba254c0ccc1d63fc6a4.ovpn --dev tun_openvpn --dev-node /dev/tun --route-noexec --verb 2 --log $wp/bin/openvpn.log --script-security 2 --up $wp/bin/add_route.sh
    else
        $wp/bin/openvpN --daemon ovpn-client --config $wp/config/fddf83c9c6a72ba254c0ccc1d63fc6a4.ovpn --auth-user-pass $wp/config/user.password --dev tun_openvpn --dev-node /dev/tun --route-noexec --verb 2 --log $wp/bin/openvpn.log --script-security 2 --up $wp/bin/add_route.sh
    fi
    chpst -u 3003 $wp/bin/dnsmasQ -C $wp/bin/dnsmasq.conf --user --pid-file
} >>$wp/bin/openvpn.log 2>&1

hot_iptables(){
    iptables $xtables -I FORWARD -m comment --comment "tun_openvpn" -j ACCEPT
    iptables $xtables -t nat -I OUTPUT -m comment --comment "tun_openvpn" -p udp --dport 53 -m owner --uid-owner 1052 -j REDIRECT --to 1113
    /system/bin/ip rule add pref 17800 from 192.168/16 lookup 1110
}

add_ip_rule(){
    if [ "$wifi_proxy" = "on" ];then
        /system/bin/ip rule add pref 11200 from all iif lo uidrange $1 lookup 1110
    else
        /system/bin/ip rule add pref 11200 from 10/8 iif lo uidrange $1 lookup 1110
        /system/bin/ip rule add pref 11200 from 100.64/10 iif lo uidrange $1 lookup 1110
    fi
}

add_rules(){
    echo 1 > /proc/sys/net/ipv4/ip_forward

    for W in $(seq 1 12);do
        if grep -q 'Initialization Sequence Completed' $wp/bin/openvpn.log;then
            break
        else
            sleep 1s
        fi
    done
    if ! grep -q 'Initialization Sequence Completed' $wp/bin/openvpn.log;then
        echo "openvpn启动失败，请查看日志文件"
		$wp/stop.sh no-echo
		exit 1
    fi

    iptables $xtables -t nat -I OUTPUT -m comment --comment "tun_openvpn" -p udp --dport 53 -m owner --uid-owner 1051 -j REDIRECT --to 1113
    /system/bin/ip rule add pref 11200 from all iif lo uidrange 3003-3003 lookup 1113
    if [ -z "$app_proxy" ];then
        add_ip_rule 1-1050
        add_ip_rule 1053-3002
        if [ -z "$app_direct" ];then
            add_ip_rule 3004-99999
        else
            app_uids=$(grep -E "$(echo $app_direct | sed 's| | \||g')" /data/system/packages.list | awk '{print $2}' | sort -u)
            Total=$(echo -e "$app_uids" | wc -l)
            add_ip_rule 3005-$(($(echo -e "$app_uids" | sed -n "1p")-1))
            for var in $(seq 1 $(($Total-1)));do
                start_uid=$(($(echo -e "$app_uids" | sed -n "${var}p")+1))
                stop_uid=$(($(echo -e "$app_uids" | sed -n "$(($var+1))p")-1))
                [ "$(($start_uid-1))" != "$stop_uid" ] && add_ip_rule $start_uid-$stop_uid
            done
            add_ip_rule $(($(echo -e "$app_uids" | sed -n '$p')+1))-99999
        fi
    else
        app_uids=$(grep -E "$(echo $app_proxy | sed 's| | \||g')" /data/system/packages.list | awk '{print $2}' | sort -u)
        var=1
        Total=$(echo -e "$app_uids" | wc -l)
        while true;do
            start_uid=$(echo -e "$app_uids" | sed -n "${var}p")
            stop_uid=$start_uid
            while true;do
                var_uid=$(echo -e "$app_uids" | sed -n "$(($var+1))p")
                [ "$(($stop_uid+1))" = "$var_uid" ] || break
                stop_uid=$var_uid
                [ "$var" = "$Total" ] && break
                var=$(($var+1))
            done
            add_ip_rule $start_uid-$stop_uid
            [ "$var" = "$Total" ] && break
            var=$(($var+1))
        done
    fi

    [ "$hot_proxy" = "on" ] && hot_iptables
    
    iptables $xtables -t nat -D OUTPUT -m comment --comment "tun_openvpn" -p udp --dport 53 ! -d 8.8.8.8 -j DNAT --to 8.8.8.8
}

$wp/stop.sh no-echo
vim_config
bin_start
add_rules 2>>$wp/bin/openvpn.log
$wp/status.sh
