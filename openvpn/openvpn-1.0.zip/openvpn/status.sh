
wp=$(cd "$(dirname $0)"; pwd)
. $wp/config.ini

for C in awk chmod chpst echo getip grep killall ln mkdir pgrep rm sed seq sort wc;do
    alias $C="$wp/bin/busybox $C"
done
echo $wp | grep -q "^/system" && mount -o rw,remount /system >/dev/null 2>&1
chmod -R 777 $wp

echo
openvpn_status="○⊃" && [ -z "$(pgrep openvpN)" ] || openvpn_status="⊂●"
dnsmasq_status="   ○⊃" && [ -z "$(pgrep dnsmasQ)" ] || dnsmasq_status="   ⊂●"
echo "    $openvpn_status openvpn  $dnsmasq_status dnsmasq"

if [ ! -z "$app_proxy" -o ! -z "$app_direct" ];then
    echo
    if [ -z "$app_proxy" ];then
        echo "    {放行的应用}:"
		echo
		grep -E "$(echo $app_direct | sed 's| | \||g')" /data/system/packages.list | awk '{print "    "$2"  "$1}'
    else
        echo "    {代理的应用}:"
		echo
		grep -E "$(echo $app_proxy | sed 's| | \||g')" /data/system/packages.list | awk '{print "    "$2"  "$1}'
    fi
fi

echo $wp | grep -q "^/system" && mount -o ro,remount /system >/dev/null 2>&1
