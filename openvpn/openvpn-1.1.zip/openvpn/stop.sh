
wp=$(cd "$(dirname $0)"; pwd)

for C in awk chmod chpst echo getip grep killall ln mkdir pgrep rm sed seq sleep sort wc;do
    alias $C="$wp/bin/busybox $C"
done
echo $wp | grep -q "^/system" && mount -o rw,remount /system >/dev/null 2>&1
chmod -R 777 $wp

{
    killall openvpN dnsmasQ
    /system/bin/ip rule | grep -E " 1110| 1113" | sed 's|.*from|/system/bin/ip rule del from |g' | sh
    mkdir -p /dev/net
    [ -e "/dev/net/tun" ] || ln -s /dev/tun /dev/net/tun
    /system/bin/ip tuntap del mode tun tun_openvpn
    iptables -S | grep "tun_openvpn" | sed "s|^..|iptables -w -D|g" | sh
    iptables -t nat -S | grep "tun_openvpn" | sed "s|^..|iptables -w -t nat -D|g" | sh
} >/dev/null 2>&1

[ -z "$1" ] && $wp/status.sh
