#define CONFIG_PID_FILE_PATH "/var/run"
