#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/dnsmasq"

if systemctl -q is-active dnsmasq.service;then
    curl -sL https://hosts.nfz.moe/127.0.0.1/basic/hosts > $wp/hosts
    systemctl restart dnsmasq.service
fi
