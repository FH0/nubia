#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/dnsmasq"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

pannel() {
    var=1
    dnsmasq_status="" && systemctl -q is-active dnsmasq.service && dnsmasq_status="$GREEN"
    dns1=$(sed -n '2p' $wp/dnsmasq.conf | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    dns2=$(sed -n '3p' $wp/dnsmasq.conf | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    
    echo
    echo -e "${BLUE}去广告DNS地址: ${YELLOW}$public_ip\033[0m"
    echo -e "       ${BLUE}1号DNS: ${YELLOW}$dns1\033[0m"
    echo -e "       ${BLUE}2号DNS: ${YELLOW}$dns2\033[0m"
    echo
    echo -e "  $var. 开/关${dnsmasq_status}dnsmasq\033[0m" && ((var++))
    echo "  $var. 更改1号DNS" && ((var++))
    echo "  $var. 更改2号DNS" && ((var++))
    echo "  $var. 卸载dnsmasq" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" pannel_choice

    case $pannel_choice in
        1)
            if [ ! -z "$dnsmasq_status" ];then
                systemctl disable dnsmasq.service
                systemctl stop dnsmasq.service
                sed -i 's|dnsmasq=.*|dnsmasq=off|' $wp/dnsmasq_update.sh
            else
                systemctl enable dnsmasq.service
                systemctl start dnsmasq.service
                sed -i 's|dnsmasq=.*|dnsmasq=on|' $wp/dnsmasq_update.sh
            fi >/dev/null 2>&1
            clear && pannel
            ;;
        2)
            colorRead ${YELLOW} "请输入1号DNS[默认8.8.8.8]" input_string
            [ -z "$input_string" ] && input_string="8.8.8.8"
            sed -i "2s|.*|server=$input_string|" $wp/dnsmasq.conf
            [ ! -z "$dnsmasq_status" ] && systemctl restart dnsmasq.service
            clear && pannel
            ;;
        3)
            colorRead ${YELLOW} "请输入!号DNS[默认8.8.4.4]" input_string
            [ -z "$input_string" ] && input_string="8.8.4.4"
            sed -i "3s|.*|server=$input_string|" $wp/dnsmasq.conf
            [ ! -z "$dnsmasq_status" ] && systemctl restart dnsmasq.service
            clear && pannel
            ;;
        4)
            read
            bash $wp/uninstall.sh
            clear && echo "dnsmasq已卸载！" && exit 0
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -q "^##" $0;then
    public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
else
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i '$a##'$public_ip'' $0
fi

clear && pannel
