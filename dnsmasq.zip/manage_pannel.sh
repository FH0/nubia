#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/dnsmasq"

RED="\033[31m"      # Error message
GREEN="\033[32m"    # Success message
YELLOW="\033[33m"   # Warning message
BLUE="\033[36m"     # Info message

pannel() {
    var=1
    systemctl -q is-active dnsmasq.service && dnsmasq_status="$GREEN"
    
    echo
    echo -e "\033[36m去广告DNS地址: \033[33m$public_ip\033[0m"
    echo
    echo -e "  $var. 开/关${dnsmasq_status}dnsmasq\033[0m" && ((var++))
    echo "  $var. 卸载dnsmasq" && ((var++))
    echo
    read -p $'\033[33m请选择：\033[0m' pannel_choice

    case $pannel_choice in
        1)
            if [ ! -z "$dnsmasq_status" ];then
                systemctl disable dnsmasq.service
                systemctl stop dnsmasq.service
                sed -i 's|dnsmasq=.*|dnsmasq=off|' $wp/dnsmasq_update.sh
            else
                systemctl enable dnsmasq.service
                systemctl start dnsmasq.service
                sed -i 's|dnsmasq=.*|dnsmasq=on|' $wp/dnsmasq_update.sh
            fi >/dev/null 2>&1
            clear && pannel
            ;;
        2)
            read
            bash $wp/uninstall.sh
            clear && echo "dnsmasq已卸载！" && exit 0
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -q "^##" $0;then
    public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
else
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i '$a##'$public_ip'' $0
fi

clear && pannel
