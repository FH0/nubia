#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/dnsmasq"

bash <(iptables -S | grep "$wp" | sed "s|-[AI] |-D |g;s|^|iptables |g")

if [ "$1" = "stop" ];then
    kill -9 $(systemctl status -l dnsmasq.service | grep "Main PID" | awk '{print $3}')
else
    iptables -I INPUT -p udp --dport 53 -m string ! --string "$wp" --algo bm -j ACCEPT
    $wp/dnsmasq -C $wp/dnsmasq.conf
fi
