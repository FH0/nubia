#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/dnsmasq"

bash <(iptables -t nat -S | grep "$wp" | sed "s|^..|iptables -t nat -D|g")
kill -9 $(ps -ef | grep "$wp" | grep -v "grep" | grep -v "\.sh" | awk '{print $2}')

if [ "$1" = "start" ];then
    iptables -t nat -I OUTPUT -p udp --dport 53 -m comment --comment "$wp" -j REDIRECT --to 55553
    iptables -t nat -I OUTPUT -p tcp --dport 53 -m comment --comment "$wp" -j REDIRECT --to 55553
    iptables -t nat -I OUTPUT -m owner --uid-owner dnsmasq -m comment --comment "$wp" -j ACCEPT
    $wp/dnsmasq -C $wp/dnsmasq.conf
fi
