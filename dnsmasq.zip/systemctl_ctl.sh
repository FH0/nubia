#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/dnsmasq"

bash <(iptables -S | grep "$wp" | sed "s|-[AI] |-D |g;s|^|iptables |g")

if [ "$1" = "stop" ];then
    kill -9 $(ps -ef | grep "$wp" | sed -n "1p" | awk '{print $2}')
else
    iptables -I INPUT -p udp --dport 53 -m string ! --string "$wp" --algo bm -j ACCEPT
    $wp/dnsmasq -C $wp/dnsmasq.conf
fi
