#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/dnsmasq"

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
bash <(iptables -t nat -S | grep "$wp" | sed "s|^..|iptables -t nat -D|g")
kill -9 $(ps -ef | grep "$wp" | grep -v "grep" | grep -v "\.sh" | awk '{print $2}')

if [ "$1" = "start" ];then
    iptables -I INPUT -p udp --dport 53 -m comment --comment "$wp" -j ACCEPT
    iptables -t nat -I OUTPUT -p udp --dport 53 -m comment --comment "$wp" -j REDIRECT --to 53
    iptables -t nat -I OUTPUT -p udp --dport 53 -m owner --uid-owner nobody -m comment --comment "$wp" -j ACCEPT
    $wp/dnsmasq -C $wp/dnsmasq.conf
fi
