#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/dnsmasq"
. $wp/functions.sh

panel() {
    var=1
    dnsmasq_status="${RED}" && pgrep -f $wp/dnsmasq >/dev/null && dnsmasq_status="$GREEN"
    dns1=$(sed -n '2p' $wp/dnsmasq.conf | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    dns2=$(sed -n '3p' $wp/dnsmasq.conf | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    
    echo
    echo -e "${BLUE}1号DNS: ${YELLOW}$dns1${BLANK}"
    echo -e "${BLUE}2号DNS: ${YELLOW}$dns2${BLANK}"
    echo
    echo -e "  $((var++)). 开/关${dnsmasq_status}dnsmasq${BLANK}"
    echo "  $((var++)). 更改1号DNS"
    echo "  $((var++)). 更改2号DNS"
    echo "  $((var++)). 卸载dnsmasq"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "${GREEN}" = "$dnsmasq_status" ];then
				stop_service stop dnsmasq
            else
                start_service start dnsmasq
            fi
            clear && panel
            ;;
        2)
            colorRead ${YELLOW} "请输入1号DNS[默认8.8.8.8]" input_string
            [ -z "$input_string" ] && input_string="8.8.8.8"
            sed -i "2s|.*|server=$input_string|" $wp/dnsmasq.conf
            start_service start dnsmasq
            clear && panel
            ;;
        3)
            colorRead ${YELLOW} "请输入2号DNS[默认8.8.4.4]" input_string
            [ -z "$input_string" ] && input_string="8.8.4.4"
            sed -i "3s|.*|server=$input_string|" $wp/dnsmasq.conf
            start_service start dnsmasq
            clear && panel
            ;;
        4)
            if warning_read;then
                bash $wp/uninstall.sh
                clear && echo "dnsmasq已卸载！" && exit 0
            else
                clear && panel
            fi
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
