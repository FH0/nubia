#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/dnsmasq"
. $wp/functions.sh

stop_service stop dnsmasq

rm -rf $wp
rm -f /bin/dq

sed -i '/dnsmasq_update\.sh/d' /etc/crontab
