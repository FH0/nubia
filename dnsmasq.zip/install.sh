#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/dnsmasq"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    [ -z "$(command -v yum)" ] && Installer="apt-get" || Installer="yum"
    var="0"
    for command in $1;do
        echo "$CHECK" | grep -q "$command"
        if [ "$?" != "0" ];then
            [ "$var" = "0" ] && apt-get update && var="1"
            $Installer install $command -y
        fi > /dev/null 2>&1
    [ "$?" != "0" ] && colorEcho $RED "相关命令安装失败！" && exit 1
    done
}

install_dnsmasq(){
    colorEcho $BLUE "正在开启dnsmasq自启程序..."
    cat $wp/dnsmasq.service > /etc/systemd/system/dnsmasq.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装dnsmasq控制面板..."
    cat $wp/manage_panel.sh > /bin/dq
    chmod +x /bin/dq
    
    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1
}

main(){
    cmd_need "curl"
    install_dnsmasq
    systemctl enable dnsmasq.service >/dev/null 2>&1; systemctl start dnsmasq.service
    colorEcho $GREEN "dnsmasq安装完成！输入dq可进入控制面板！"
}

main
