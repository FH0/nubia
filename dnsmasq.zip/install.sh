#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/dnsmasq"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    [ -z "$(command -v yum)" ] && Installer="apt-get" || Installer="yum"
    var="0"
    for command in $1;do
        if ! echo "$CHECK" | grep -q "$command";then
            [ "$var" = "0" ] && apt-get update && var="1"
            $Installer install $command -y
        fi > /dev/null 2>&1
    done
}

install_dnsmasq(){
    colorEcho $BLUE "正在开启dnsmasq自启程序..."
    cat $wp/dnsmasq.service > /etc/systemd/system/dnsmasq.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装dnsmasq控制面板..."
    cat $wp/manage_panel.sh > /bin/dq
    chmod +x /bin/dq
    
    colorEcho $BLUE "正在安装去广告hosts..."
	curl -sOL https://hosts.nfz.moe/127.0.0.1/full/hosts
	curl -sL https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/fakenews/hosts >> hosts
	sort -u hosts | sed "s|0.0.0.0|127.0.0.1|g;s|:: |::1 |g" > hosts.bak
	mv hosts.bak $wp/hosts
	
    colorEcho $BLUE "正在安装hosts自动更新程序..."
    sed -i '/dnsmasq_update\.sh/d' /etc/crontab
    echo "00 03 * * * root $wp/dnsmasq_update.sh" >> /etc/crontab
	
    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1

    useradd dnsmasq
}

main(){
    install_dnsmasq
    systemctl enable dnsmasq.service >/dev/null 2>&1; systemctl start dnsmasq.service
    colorEcho $GREEN "dnsmasq安装完成！输入dq可进入控制面板！"
}

main
