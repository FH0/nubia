#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

$wp/systemctl_ctl.sh stop >/dev/null 2>&1

if command -v systemctl >/dev/null;then
	systemctl disable v2ray.service
	rm -f /etc/systemd/system/v2ray.service
	systemctl daemon-reload ; systemctl reset-failed
elif [ -e "/etc/rc.local" ];then
	tmp_echo=$(grep -v "$wp/systemctl_ctl.sh" /etc/rc.local)
	echo "$tmp_echo" > /etc/rc.local
fi >/dev/null 2>&1

rm -rf $wp
rm -f /bin/v2

sed -i '/v2ray_update\.sh/d' /etc/crontab
