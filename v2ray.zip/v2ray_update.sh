#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

systemctl is-active -q v2ray.service && v2ray=on || v2ray=""

old_core=$($wp/v2ray -version | sed -n "1p" | awk '{print $2}' | sed "s|v||")
latest_core=$(curl -s https://github.com/v2ray/v2ray-core/releases/latest | sed 's|.*tag/v\(.*\)".*|\1|')

update_v2ray() {
    rm -rf /tmp/v2ray && mkdir -p /tmp/v2ray && cd /tmp/v2ray
    wget -q -N --no-check-certificate https://github.com/v2ray/v2ray-core/releases/download/v${latest_core}/v2ray-linux-64.zip
    unzip -q -o v2ray-linux-64.zip
    $(command -v cp) -f $(find . -size +8000k -name v2ray) $wp ; $(command -v cp) -f $(find . -size +8000k -name v2ctl) $wp
    chmod -R 777 $wp
    systemctl restart v2ray.service
}

main() {
    [ "$v2ray" = "on" ] && [ "$old_core" != "$latest_core" ] && update_v2ray
}

main
