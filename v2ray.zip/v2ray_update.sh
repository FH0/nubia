#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

old_core=$($wp/v2ray -version | sed -n "1p" | awk '{print $2}' | sed "s|v||")
latest_core=$(curl -s https://github.com/v2ray/v2ray-core/releases/latest | sed 's|.*tag/v\(.*\)".*|\1|')

if pgrep -f $wp/v2ray && [ "$old_core" != "$latest_core" ];then
    curl -sOL https://github.com/v2ray/v2ray-core/releases/download/v${latest_core}/v2ray-linux-64.zip
    unzip -q -o v2ray-linux-64.zip v2ray v2ctl -d $wp
    chmod -R 777 $wp
	rm -f v2ray-linux-64.zip
    $wp/run_ctl.sh satrt
fi
