#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

update_v2ray() {
    rm -rf /tmp/v2ray && mkdir -p /tmp/v2ray && cd /tmp/v2ray
    wget -q -N --no-check-certificate https://github.com/v2ray/v2ray-core/releases/download/v${latest_core}/v2ray-linux-64.zip
    unzip -q -o v2ray-linux-64.zip v2ray v2ctl -d $wp
    chmod -R 777 $wp
    systemctl restart v2ray.service
}

old_core=$($wp/v2ray -version | sed -n "1p" | awk '{print $2}' | sed "s|v||")
latest_core=$(curl -s https://github.com/v2ray/v2ray-core/releases/latest | sed 's|.*tag/v\(.*\)".*|\1|')

if systemctl is-active -q v2ray.service && [ "$old_core" != "$latest_core" ];then
    update_v2ray
fi
