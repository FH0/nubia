#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

add_port() {
    colorRead ${YELLOW} '请输入端口[默认随机]' Port
    [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
    colorRead ${YELLOW} '请设置UUID[默认随机]' UUID
    [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
    echo " 1. tcp"
    echo " 2. ws"
    echo " 3. kcp"
    echo
    colorRead ${YELLOW} '请选择传输类型[默认ws]' network
    [ -z "$network" ] && network=2
    [ "$network" = "1" ] && network=tcp
    [ "$network" = "2" ] && network=ws
    [ "$network" = "3" ] && network=kcp
    echo "$Port $network $UUID" >> $wp/v2ray.ini
    $wp/config_reload.sh
    systemctl restart v2ray.service
}

del_port() {
    var=1
    for Echo in $v2ray_ports;do
        echo -e " $var. 删除${YELLOW}$Echo\033[0m端口"
        ((var++))
    done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    if [ ! -z "$input_choice" ];then
        sed -i "${input_choice}d" $wp/v2ray.ini
        $wp/config_reload.sh
        if grep -q "[0-9]" $wp/v2ray.ini;then
            systemctl restart v2ray.service
        else
            systemctl stop v2ray.service
        fi
    fi
}

change_uuid() {
    var=1
    for Echo in $v2ray_ports;do
        echo -e " $var. 更改${YELLOW}$Echo\033[0m端口设置"
        ((var++))
    done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    [ -z "$input_choice" ] && clear && panel
    echo " 1. 更改UUID"
    echo " 2. 更改传输方式"
    echo
    colorRead ${YELLOW} '请选择' port_choice
    [ -z "$port_choice" ] && clear && panel
    if [ "$port_choice" = "1" ];then
        colorRead ${YELLOW} '请设置UUID[默认随机]' UUID
        [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
        network=$(sed -n "${input_choice}p" $wp/v2ray.ini | awk '{print $2}')
    elif [ "$port_choice" = "2" ];then
        echo "  1. tcp"
        echo "  2. ws"
        echo "  3. kcp"
        echo
        colorRead ${YELLOW} '请选择传输类型[默认ws]' network
        [ -z "$network" ] && network=2
        [ "$network" = "1" ] && network=tcp
        [ "$network" = "2" ] && network=ws
        [ "$network" = "3" ] && network=kcp
        UUID=$(sed -n "${input_choice}p" $wp/v2ray.ini | awk '{print $3}')
    fi
    port=$(sed -n "${input_choice}p" $wp/v2ray.ini | awk '{print $1}')
    sed -i "${input_choice}d" $wp/v2ray.ini
    echo "$port $network $UUID" >> $wp/v2ray.ini
    $wp/config_reload.sh
    systemctl restart v2ray.service
}

show_config() {
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    for K in ${v2ray_ports};do
        v2ray_uuid=$(grep "^$K " $wp/v2ray.ini | awk '{print $3}')
        network=$(grep "^$K " $wp/v2ray.ini | awk '{print $2}')
        v2rayNG=$(echo -n '{"add":"'$public_ip'","aid":"100","host":"k.youku.com","id":"'$v2ray_uuid'","net":"'$network'","path":"","port":"'$K'","ps":"'$country'","tls":"","type":"none","v":"2"}' | base64 | tr -d "\n|=" | sed 's|^|vmess://|')
        [ "$network" = "tcp" ] && v2rayNG=$(echo -n '{"add":"'$public_ip'","aid":"100","host":"k.youku.com","id":"'$v2ray_uuid'","net":"tcp","path":"","port":"'$K'","ps":"'$country'","tls":"","type":"http","v":"2"}' | base64 | tr -d "\n|=" | sed 's|^|vmess://|')
        printf "${BLUE}%11s ${YELLOW}%-20s\033[0m\n" "服务IP:" "${public_ip}"
        printf "${BLUE}%13s ${YELLOW}%-20s\033[0m\n" "服务端口:" "${K}"
        printf "${BLUE}%11s ${YELLOW}%-20s\033[0m\n" "用户ID:" "${v2ray_uuid}"
        printf "${BLUE}%11s ${YELLOW}%-20s\033[0m\n" "额外ID:" "100"
        printf "${BLUE}%13s ${YELLOW}%-20s\033[0m\n" "加密方式:" "任意选择"
        printf "${BLUE}%13s ${YELLOW}%-20s\033[0m\n" "传输协议:" "$network"
        [ "$network" = "tcp" ] && printf "${BLUE}%13s ${YELLOW}%-20s\033[0m\n" "伪装类型:" "http"
        echo
        printf "${BLUE}%9s ${YELLOW}%-20s\033[0m\n" "v2rayNG:" "${v2rayNG}"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    done
}

show_shadowrocket(){
    for K in ${v2ray_ports};do
        v2ray_uuid=$(grep "^$K " $wp/v2ray.ini | awk '{print $3}')
        network=$(grep "^$K " $wp/v2ray.ini | awk '{print $2}')
        Shadowrocket=$(echo -n 'aes-128-cfb:'$v2ray_uuid'@'$public_ip':'$K'' | base64 | tr -d "\n|=" | sed 's|^|vmess://|;s|$|?obfs=http|')
        echo -e "[${BLUE}$K\033[0m] ${YELLOW}$Shadowrocket\033[0m\n"
    done
}

panel(){
    v2ray_status="${RED}" && systemctl is-active -q v2ray.service && v2ray_status="$GREEN"
    core_version=$($wp/v2ray -version | sed -n "1p" | awk '{print $2}')
    v2ray_ports=$(awk '{print $1}' $wp/v2ray.ini)
    connections=""
    for Port in $v2ray_ports;do
        connection=$(echo -e "[${YELLOW}$Port\033[0m ${GREEN}$(ss -o state established sport = :$Port | awk '{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l)\033[0m]")
        connections="$connection $connections"
    done
    var=1

    show_config
    echo
    echo -e "[${YELLOW}端口\033[0m ${GREEN}连接数\033[0m] $connections"
    echo
    echo -e "  $var. 开/关${v2ray_status}V2Ray\033[0m ${GREEN}$core_version\033[0m" && ((var++))
    echo "  $var. 卸载V2Ray" && ((var++))
    echo "  $var. 添加一个端口" && ((var++))
    echo "  $var. 删除一个端口" && ((var++))
    echo "  $var. 更改端口设置" && ((var++))
    echo "  $var. 查看Shadowrocket配置" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "$v2ray_status" = "$GREEN" ];then
                systemctl stop v2ray.service
                systemctl disable v2ray.service
            elif grep -q "[0-9]" $wp/v2ray.ini;then
                systemctl start v2ray.service
                systemctl enable v2ray.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        2)
            read
            bash $wp/uninstall.sh
            clear && echo "V2Ray已卸载！"
            ;;
        3)
            add_port
            clear && panel
            ;;
        4)
            del_port
            clear && panel
            ;;
        5)
            change_uuid
            clear && panel
            ;;
        6)
            show_shadowrocket
            exit 0
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -qE "^##([0-9]{1,3}\.){3}[0-9]{1,3}" $0;then
    public_ip=$(ifconfig | grep 'inet ' | awk '{print $2}' | grep -Ev '^10\.|^192\.168|^172\.[1-3]|^127\.' | sed -n '1p')
    [ -z "$public_ip" ] && public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    country=$(grep "^##" $0 | awk '{print $2}')
else
    JSON=$(curl -s http://ip-api.com/json)
    public_ip=$(echo $JSON | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    country=$(echo $JSON | sed 's|.*"countryCode":"\(..\)".*|\1|')
    [ -z "$JSON" ] || sed -i '$a##'$public_ip' '$country'' $0
fi

clear && panel
