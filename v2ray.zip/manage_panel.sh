#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

add_port() {
    colorRead ${YELLOW} '请输入端口[默认随机]' Port
    [ -z "$Port" ] && Port=$(shuf -i 1024-65535 -n 1)
    colorRead ${YELLOW} '请设置UUID[默认随机]' UUID
    [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
    echo " 1. tcp"
    echo " 2. ws"
    echo " 3. kcp"
    echo
    colorRead ${YELLOW} '请选择传输类型[默认ws]' network
    [ -z "$network" ] && network=2
    [ "$network" = "1" ] && network=tcp
    [ "$network" = "2" ] && network=ws
    [ "$network" = "3" ] && network=kcp
    echo "$Port $network $UUID" >> $wp/v2ray.ini
    $wp/config_reload.sh
    systemctl restart v2ray.service
}

del_port() {
    var=1
    for Echo in $v2ray_ports;do
        echo -e " $var. 删除\033[33m$Echo\033[0m端口"
        ((var++))
    done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    if [ ! -z "$input_choice" ];then
        sed -i "${input_choice}d" $wp/v2ray.ini
        $wp/config_reload.sh
        if grep -q "[0-9]" $wp/v2ray.ini;then
            systemctl restart v2ray.service
        else
            systemctl stop v2ray.service
        fi
    fi
}

change_uuid() {
    var=1
    for Echo in $v2ray_ports;do
        echo -e " $var. 更改\033[33m$Echo\033[0m端口设置"
        ((var++))
    done
    echo
    colorRead ${YELLOW} '请选择' input_choice
    [ -z "$input_choice" ] && clear && panel
    echo " 1. 更改UUID"
    echo " 2. 更改传输方式"
    echo
    colorRead ${YELLOW} '请选择' port_choice
    [ -z "$port_choice" ] && clear && panel
    if [ "$port_choice" = "1" ];then
        colorRead ${YELLOW} '请设置UUID[默认随机]' UUID
        [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
        network=$(sed -n "${input_choice}p" $wp/v2ray.ini | awk '{print $2}')
    elif [ "$port_choice" = "2" ];then
        echo "  1. tcp"
        echo "  2. ws"
        echo "  3. kcp"
        echo
        colorRead ${YELLOW} '请选择传输类型[默认ws]' network
        [ -z "$network" ] && network=2
        [ "$network" = "1" ] && network=tcp
        [ "$network" = "2" ] && network=ws
        [ "$network" = "3" ] && network=kcp
        UUID=$(sed -n "${input_choice}p" $wp/v2ray.ini | awk '{print $3}')
    fi
    port=$(sed -n "${input_choice}p" $wp/v2ray.ini | awk '{print $1}')
    sed -i "${input_choice}d" $wp/v2ray.ini
    echo "$port $network $UUID" >> $wp/v2ray.ini
    $wp/config_reload.sh
    systemctl restart v2ray.service
}

show_config() {
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    for K in ${v2ray_ports};do
        v2ray_uuid=$(grep "^$K " $wp/v2ray.ini | awk '{print $3}')
        network=$(grep "^$K " $wp/v2ray.ini | awk '{print $2}')
        v2rayNG=$(echo -n '{"add":"'$public_ip'","aid":"100","host":"k.youku.com","id":"'$v2ray_uuid'","net":"'$network'","path":"","port":"'$K'","ps":"'$country'","tls":"","type":"none","v":"2"}' | base64 | sed ':a;N;$!ba;s|\n||g' | sed 's|^|vmess://|')
        [ "$network" = "tcp" ] && v2rayNG=$(echo -n '{"add":"'$public_ip'","aid":"100","host":"k.youku.com","id":"'$v2ray_uuid'","net":"tcp","path":"","port":"'$K'","ps":"'$country'","tls":"","type":"http","v":"2"}' | base64 | sed ':a;N;$!ba;s|\n||g' | sed 's|^|vmess://|')
        printf "\033[36m%11s \033[33m%-20s\033[0m\n" "服务IP:" "${public_ip}"
        printf "\033[36m%13s \033[33m%-20s\033[0m\n" "服务端口:" "${K}"
        printf "\033[36m%11s \033[33m%-20s\033[0m\n" "用户ID:" "${v2ray_uuid}"
        printf "\033[36m%11s \033[33m%-20s\033[0m\n" "额外ID:" "100"
        printf "\033[36m%13s \033[33m%-20s\033[0m\n" "加密方式:" "任意选择"
        printf "\033[36m%13s \033[33m%-20s\033[0m\n" "传输协议:" "$network"
        [ "$network" = "tcp" ] && printf "\033[36m%13s \033[33m%-20s\033[0m\n" "伪装类型:" "http"
        echo
        printf "\033[36m%9s \033[33m%-20s\033[0m\n" "v2rayNG:" "${v2rayNG}"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    done
}

panel(){
    v2ray_status="${RED}" && systemctl is-active -q v2ray.service && v2ray_status="$GREEN"
    core_version=$($wp/v2ray -version | sed -n "1p" | awk '{print $2}')
    v2ray_ports=$(awk '{print $1}' $wp/v2ray.ini)
    connections=""
    for Port in $v2ray_ports;do
        connection=$(echo -e "[\033[33m$Port\033[0m ${GREEN}$(ss -o state established sport = :$Port | awk '{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l)\033[0m]")
        connections="$connection $connections"
    done
    var=1

    show_config
    echo
    echo -e "[\033[33m端口\033[0m ${GREEN}连接数\033[0m] $connections"
    echo
    echo -e "  $var. 开/关${v2ray_status}V2Ray\033[0m ${GREEN}$core_version\033[0m" && ((var++))
    echo "  $var. 卸载V2Ray" && ((var++))
    echo "  $var. 添加一个端口" && ((var++))
    echo "  $var. 删除一个端口" && ((var++))
    echo "  $var. 更改端口设置" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "$v2ray_status" = "$GREEN" ];then
                systemctl stop v2ray.service
                systemctl disable v2ray.service
            elif grep -q "[0-9]" $wp/v2ray.ini;then
                systemctl start v2ray.service
                systemctl enable v2ray.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        2)
            read
            bash $wp/uninstall.sh
            clear && echo "V2Ray已卸载！"
            ;;
        3)
            add_port
            clear && panel
            ;;
        4)
            del_port
            clear && panel
            ;;
        5)
            change_uuid
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -qE "^##([0-9]{1,3}\.){3}[0-9]{1,3}" $0;then
    public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    country=$(grep "^##" $0 | awk '{print $2}')
else
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    country=$(curl -s http://ip-api.com/json | sed 's|.*"countryCode":"\(..\)".*|\1|')
    sed -i '$a##'$public_ip' '$country'' $0
fi

clear && panel
