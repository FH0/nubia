#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"
. $wp/functions.sh

install_v2ray(){
    colorEcho $BLUE "正在安装V2Ray核心..."
    v2ray_latest_version=$(curl -s https://github.com/v2ray/v2ray-core/releases/latest | sed 's|.*tag/\(.*\)".*|\1|')
    curl -sOL https://github.com/v2ray/v2ray-core/releases/download/${v2ray_latest_version}/v2ray-linux-64.zip
    unzip -q -o v2ray-linux-64.zip v2ray v2ctl -d $wp
    rm -f v2ray-linux-64.zip
    
    chmod -R 777 $wp
    
	colorEcho $BLUE "正在开启V2Ray自启程序..."
    if command -v systemctl >/dev/null;then
        cp $wp/*.service /etc/systemd/system
        systemctl daemon-reload
    fi

    colorEcho $BLUE "正在安装V2Ray控制面板..."
	ip_info init
    cp $wp/manage_panel.sh /bin/v2
    
    colorEcho $BLUE "正在开启自动更新程序..."
    sed -i '/v2ray_update\.sh/d' /etc/crontab
    echo "00 03 * * * root $wp/v2ray_update.sh" >> /etc/crontab
}

main(){
    install_v2ray
    colorEcho $GREEN "V2Ray安装完成！输入v2可进入控制面板！"
}

main
