#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/v2ray"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    [ -z "$(command -v yum)" ] && Installer="apt-get" || Installer="yum"
    var="0"
    for command in $1;do
        if ! echo "$CHECK" | grep -q "$command";then
            [ "$var" = "0" ] && apt-get update && var="1"
            $Installer install $command -y
        fi > /dev/null 2>&1
    done
}

install_v2ray(){
    if ! apt-get install libcap2-bin -y >/dev/null 2>&1;then
        yum install libcap -y
    fi >/dev/null 2>&1
    
    colorEcho $BLUE "正在开启V2Ray自启程序..."
    cat $wp/v2ray.service > /etc/systemd/system/v2ray.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装V2Ray控制面板..."
    cat $wp/manage_panel.sh > /bin/v2
    chmod +x /bin/v2
    
    touch $wp/v2ray.ini
    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1
}

main(){
    install_v2ray
    colorEcho $GREEN "V2Ray安装完成！输入v2可进入控制面板！"
}

main
