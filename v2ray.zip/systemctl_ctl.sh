#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
kill -9 $(ps -ef | grep "$wp" | grep -v "grep" | grep -v "\.sh" | awk '{print $2}')

if [ "$1" = "start" ];then
    for dport in $(awk '{print $1}' $wp/v2ray.ini);do
        iptables -I INPUT -p tcp --dport $dport -m string ! --string "$wp" --algo bm -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m string ! --string "$wp" --algo bm -j ACCEPT
    done
    setcap cap_net_bind_service=+ep $wp/v2ray
    su -s /bin/bash nobody -c "$wp/v2ray -config $wp/config.json"
fi
