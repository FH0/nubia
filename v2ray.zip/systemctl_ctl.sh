#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/v2ray"

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
kill -9 $(ps -ef | grep "$wp/v2ray" | grep -v "grep" | awk '{print $2}')

if [ "$1" = "start" ];then
    for dport in $(awk '{print $1}' $wp/v2ray.ini);do
        iptables -I INPUT -p tcp --dport $dport -m comment --comment "$wp" -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m comment --comment "$wp" -j ACCEPT
    done
    if command -v setcap;then
        setcap cap_net_bind_service=+ep $wp/v2ray
        su -s /bin/bash nobody -c "$wp/v2ray -config $wp/config.json"
    else
        $wp/v2ray -config $wp/config.json
    fi
fi
