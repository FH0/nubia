#!/system/bin/sh
#准备环境
kill `ps|grep v2ray|sed 's:root[ \t]\(.*\) 1 .*:\1:g'` > /dev/null 2>&1
iptables -t nat -F && iptables -t nat -X 
if [ $1 = "S" ];then exit 0;fi

#用于代理热点
iptables -t nat -N v2_PRE
iptables -t nat -A v2_PRE -p tcp -j REDIRECT --to-ports 6946
iptables -t nat -A PREROUTING -p tcp -j v2_PRE

#用于代理数据和wifi
iptables -t nat -N v2_OUT
iptables -t nat -A v2_OUT -d 67.209.185.139 -j ACCEPT
iptables -t nat -A v2_OUT -d 10.0.0.200 -j ACCEPT
iptables -t nat -A v2_OUT -d 10.0.0.172 -j ACCEPT
iptables -t nat -A v2_OUT -d 192.168.0.0/16 -j ACCEPT
iptables -t nat -A v2_OUT -p tcp -j REDIRECT --to-ports 6946
iptables -t nat -A OUTPUT -p tcp -j v2_OUT

#启动v2ray
wp=`echo $0 | sed "s:\(.*\)v2ray\.sh:\1:g"`
${wp}v2ray -config ${wp}v2ray.json &
