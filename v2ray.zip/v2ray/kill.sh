#!/system/bin/sh
wp=`echo $0 | sed "s:\(.*\)kill\.sh:\1:g"`
${wp}v2ray.sh S
