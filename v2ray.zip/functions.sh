
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"
BLANK="\033[0m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}${BLANK}"
    echo
}

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT${BLANK}: "
    read $VARIABLE
    echo
}

get_connections(){
    port=$1
    if command -v ss >/dev/null;then
        ss -tun state established sport = :$port | awk '{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l
    elif command -v netstat >/dev/null;then
        netstat -tun | awk '$4~/:'$port'$/ && $6~/ESTABLISHED/{print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l
    fi
}

ip_info(){
    if [ "$1" = "init" ];then
        sed -i '/^##/d' $wp/manage_panel.sh
        tmp_data=$(curl -sL http://ip-api.com/json) || \
            tmp_data=$(curl -sL http://api.ipapi.com/check?access_key=d72b841ab430468491424731634bcbb2)
        echo -n "## " >> $wp/manage_panel.sh
        echo -n "$tmp_data" | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | tr '\n' ' ' >> $wp/manage_panel.sh
        echo "$tmp_data" | grep -Eo '"[A-Z][A-Z]"' | sed -n '$p' | awk -F '"' '{print $2}' >> $wp/manage_panel.sh
    elif [ "$1" = "get_ip" ];then
        grep "^##" $wp/manage_panel.sh | awk '{print $2}'
    elif [ "$1" = "get_country" ];then
        grep "^##" $wp/manage_panel.sh | awk '{print $3}'
    fi
}

stop_service(){
    $wp/run_ctl.sh $1
    if command -v systemctl;then
        rm -f /etc/systemd/system/$2.service
        systemctl daemon-reload
        systemctl disable $2.service
    elif [ -e "/etc/rc.local" ];then
        tmp_echo=$(grep -v "$wp/run_ctl.sh" /etc/rc.local)
        echo "$tmp_echo" > /etc/rc.local
    fi
} >/dev/null 2>&1

start_service(){
    $wp/run_ctl.sh $1
    if command -v systemctl;then
        cp $wp/$2.service /etc/systemd/system
        systemctl daemon-reload
        systemctl enable $2.service
    elif [ -e "/etc/rc.local" ];then
            tmp_echo=$(grep -v "^exit" /etc/rc.local)
            echo "$tmp_echo" > /etc/rc.local
            echo "$wp/run_ctl.sh $1" >> /etc/rc.local
            echo "exit 0" >> /etc/rc.local
    fi
} >/dev/null 2>&1

enable_tcp_fastopen(){
	if [ -e "/proc/sys/net/ipv4/tcp_fastopen" ];then
		echo 3 > /proc/sys/net/ipv4/tcp_fastopen
	fi
}

cmd_need(){
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    for command in $1;do
        echo "$CHECK" | grep -q "$command" || CMD="$command $CMD"
    done
    if [ ! -z "$CMD" ];then
		colorEcho $BLUE "正在安装 $CMD ..."
		if [ -z "$(command -v yum)" ];then
			apt-get update
			apt-get install $CMD -y
		else
			yum install $CMD -y
		fi > /dev/null 2>&1
		clear
	fi
}
