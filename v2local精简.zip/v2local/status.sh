#!/system/bin/sh

. ${0%/*}/bin/v2local_functions.sh

pre_v2local

v2local_check
