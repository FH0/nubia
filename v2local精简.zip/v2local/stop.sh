#!/system/bin/sh

. ${0%/*}/bin/v2local_functions.sh

pre_v2local
#停止v2local
v2local_stop
#获取v2local运行状态
v2local_check
