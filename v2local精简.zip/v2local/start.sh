#!/system/bin/sh

. ${0%/*}/bin/v2local_functions.sh

pre_v2local

#停止v2local
v2local_stop
#编辑配置文件
vim_config
#启动相关模块
v2local_bin_start
#创建初始规则
add_iptables
#放行应用
[ -z "$app_direct" ] || app_direct
#udp规则
[ "$udp_proxy" = "on" ] && udp_iptables
#热点规则
[ "$hot_tcp_proxy" = "on" ] && hot_tcp_iptables
#tcp主规则
necessary_iptables
#获取v2local运行状态
v2local_check
