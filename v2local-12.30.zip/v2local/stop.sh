#!/system/bin/sh

chmod -R 777 ${0%/*} ; ${0%/*}/bin/v2local_functions.sh stop