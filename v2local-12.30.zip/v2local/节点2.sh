
security=auto
alterId=100
port=80
vps_ip=1.1.1.1
uuid=4383ffee-449d-49a1-b245-c7826ed54e46
Host=k.youku.com
network=tcp
mux=off

hot_tcp_proxy=on
udp_proxy=on
wifi_proxy=on
break_bq=off
app_direct=""
DNS=8.8.8.8
hosts=/etc/hosts
smart_proxy=off
auto_start=on

#================================================================
#    
#    vps_ip是服务器IP
#    port是端口
#    network是传输方式，可选tcp ws kcp
#    alterId是额外用户ID
#    Host是混淆
#    security是加密方式，可选auto chacha20-poly1305 aes-128-gcm aes-128-cfb none
#    mux可选on off，开启的话默认为8并发
#
#    break_bq是破版权，可选on off
#    udp_proxy是本机UDP，可选on off
#    hot_tcp_proxy是热点的tcp，可选on off，热点udp和本机udp设置相同
#    wifi_proxy是wifi代理，可选on off
#    app_direct是应用放行，可选[应用包名] [应用uid]，多个应用之间用空格隔开
#    smart_proxy是只代理国外流量，可选on off
#    auto_start是magisk的开机自启，可选on off
#
#    {常用的应用包名}
#    淘宝 com.taobao.taobao
#    支付宝 com.eg.android.AlipayGphone
#    王者荣耀 com.tencent.tmgp.sgame
#    刺激战场 com.tencent.tmgp.pubgmhd
#    联通营业厅 com.sinovatech.unicom.ui
#    作业帮 com.baidu.homework
#    Tim com.tencent.tim
#    ADM com.dv.adm.pay
#    酷安 com.coolapk.market
#    电信营业厅 com.ct.client
#    京东 com.jingdong.app.mall
#    网易云音乐 com.netease.cloudmusic
#    JuiceSSH com.sonelli.juicessh
#    微信 com.tencent.mm
#    腾讯视频 com.tencent.qqlive
#    微信读书 com.tencent.weread
#    转转 com.wuba.zhuanzhuan
#    闲鱼 com.taobao.idlefish
#    讯飞输入法 com.iflytek.inputmethod
#    哔哩哔哩 tv.danmaku.bili
#    YY com.duowan.mobile
#    QQ音乐 com.tencent.qqmusic
#    Network Tools net.he.networktools
#    阿里云 com.alibaba.aliyun
#
#    {相关的说明}
#    1.V2Ray搭建脚本[Debian9/CentOS7]:    bash <(curl -sL https://raw.githubusercontent.com/FH0/nubia/master/Backstage.sh)
#    2.如果提示curl: not found，请先安装curl，(apt-get update -y && apt-get install curl -y) || (yum update -y && yum install curl -y)
#    
#===============================================================
head -n 50 $0 | grep "\=" > ${0%/*}/bin/config.ini
if [ "$auto_start" = "on" ] && [ -d "/sbin/.core/img/.core/service.d" ];then
    if [ ! -f "/sbin/.core/img/.core/service.d/service.sh" ];then
        echo "#!/system/bin/sh" > /sbin/.core/img/.core/service.d/service.sh
    fi
    sed -i "/v2local/d" /sbin/.core/img/.core/service.d/service.sh
    echo "$0" >> /sbin/.core/img/.core/service.d/service.sh
    chmod 777 /sbin/.core/img/.core/service.d/service.sh
fi
chmod -R 777 ${0%/*} ; ${0%/*}/bin/v2local_functions.sh start
#===============================================================