
security=aes-128-gcm
alterId=100
port=
vps_ip=
uuid=
Host=k.youku.com
path=http://k.youku.com
network=GET
DNS=114.114.114.114

#abroad_vps_ip=
#abroad_port=
#abroad_alterId=
#abroad_uuid=
#abroad_DNS=8.8.8.8

hot_proxy=on
break_bq=off
app_direct=""
app_proxy=""
ChinaDNS=
wifi_proxy=on
auto_start=off

#================================================================
#
#    vps_ip是服务器IP
#    port是端口
#    network可选GET POST CONNECT ws kcp
#    alterId是额外用户ID
#    Host是混淆
#    path是首头，当network为tcp时生效
#    security是加密方式，可选auto chacha20-poly1305 aes-128-gcm aes-128-cfb none
#
#    当同时拥有国内节点与国外节点时，可以使用双服务器模式，其他情况不行
#    双服务器模式不推荐Wifi或无限流量用户使用，Wifi或无限流量用户推荐使用ChinaDNS
#    启用双服务器模式后ChinaDNS与break_bq失效
#    取消abroad_前缀参数前的注释即可开启双服务器模式，不用的时候注释abroad_vps_ip即可
#    开启后国内流量走原来的节点，国外流量走abroad_前缀的节点
#
#    break_bq是破版权，同时对本机与热点有效，可选on off
#    hot_proxy是热点代理开关，可选on off
#    app_direct是放行应用，未被放行的应用会被代理，优先级高于app_proxy，可选[应用包名] [应用uid]，多个应用之间用空格隔开
#    app_proxy是代理应用，未选中的应用会被放行，可选[应用包名] [应用uid]，多个应用之间用空格隔开
#    当ChinaDNS不为空时，只代理国外流量，同时对本机与热点生效，填一个国内的DNS服务器地址，不能与DNS的值相同
#    wifi_proxy是WiFi代理开关，可选on off
#    auto_start是利用magisk开机自启的开关，可选on off，magisk版本不能低于19
#
#    {常用的应用包名}
#    淘宝 com.taobao.taobao
#    支付宝 com.eg.android.AlipayGphone
#    王者荣耀 com.tencent.tmgp.sgame
#    刺激战场 com.tencent.tmgp.pubgmhd
#    联通营业厅 com.sinovatech.unicom.ui
#    作业帮 com.baidu.homework
#    Tim com.tencent.tim
#    ADM com.dv.adm.pay
#    酷安 com.coolapk.market
#    电信营业厅 com.ct.client
#    京东 com.jingdong.app.mall
#    网易云音乐 com.netease.cloudmusic
#    JuiceSSH com.sonelli.juicessh
#    微信 com.tencent.mm
#    腾讯视频 com.tencent.qqlive
#    微信读书 com.tencent.weread
#    转转 com.wuba.zhuanzhuan
#    闲鱼 com.taobao.idlefish
#    讯飞输入法 com.iflytek.inputmethod
#    哔哩哔哩 tv.danmaku.bili
#    YY com.duowan.mobile
#    QQ音乐 com.tencent.qqmusic
#    Network Tools net.he.networktools
#    阿里云 com.alibaba.aliyun
#    WPS cn.wps.moffice_eng
#    网络信号大师 com.qtrun.QuickTest
#    Z直播 com.linroid.zlive
#    决战！平安京 com.netease.moba
#    翼支付 com.chinatelecom.bestpayclient
#
#    {相关的说明}
#    1.V2Ray搭建脚本[Debian9/CentOS7]:    bash <(curl -sL https://raw.githubusercontent.com/FH0/nubia/master/Backstage.sh)
#    2.如果提示curl: command not found，请先安装curl，(apt-get update && apt-get install curl -y) || (yum update -y && yum install curl -y)
#    
#===============================================================
wp=$(cd "$(dirname $0)"; pwd)
type shopt >/dev/null 2>&1 && shopt -s expand_aliases
for C in awk chmod chpst echo getip grep killall ln mkdir pgrep rm sed seq sort wc;do
    alias $C="$wp/bin/busybox $C"
done
chmod -R 777 $wp
for C in $(echo ${wp%/*} | sed 's|/| /|g');do
    chmod="$chmod$C"
    chmod o+x $chmod
done
if [ "$auto_start" = "on" -a -d "/data/adb/service.d" ];then
    echo -e "\nwhile true;do\n    if [ -d \"$wp\" ];then\n        sh $wp/$(basename $0)\n        break\n    else\n        sleep 3\n    fi\ndone" | sed '1s|^|#!/system/bin/sh\n|' > /data/adb/service.d/v2tun.sh
    chmod 755 /data/adb/service.d/v2tun.sh
else
    rm -f /data/adb/service.d/v2tun.sh
fi >/dev/null 2>&1
. $wp/bin/v2tun_functions.sh
