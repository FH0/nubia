
wp=$(cd "$(dirname $0)"; pwd)

for C in awk chmod chpst echo getip grep killall ln mkdir pgrep rm sed seq sort wc;do
    alias $C="$wp/bin/busybox $C"
done
chmod -R 777 $wp

{
    killall v2raY tun2sockS
    ip rule | grep -E " 1110| 1113" | sed 's|.*from|ip rule del from |g' | sh
    ip tuntap del mode tun v2tun
    iptables -S | grep "v2tun" | sed "s|^..|iptables -w -D|g" | sh
} >/dev/null 2>&1

[ -z "$1" ] && $wp/status.sh
