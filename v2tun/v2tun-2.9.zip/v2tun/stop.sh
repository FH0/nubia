
wp=${0%/*} ; wp=${wp:-.}
. $wp/bin/v2tun_functions.sh stop
