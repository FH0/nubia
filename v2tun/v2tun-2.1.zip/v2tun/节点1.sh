
security=aes-128-gcm
alterId=100
port=
vps_ip=
uuid=
Host=lt.hn.189.cn:1082
path=http://lt.hn.189.cn:1082
network=GET
mux=off

hot_proxy=on
break_bq=off
app_direct=""
app_proxy=""
DNS=8.8.8.8
smart_proxy=off

#================================================================
#    
#    vps_ip是服务器IP
#    port是端口
#    network可选GET POST CONNECT ws kcp
#    alterId是额外用户ID
#    Host是混淆
#    path是首头，当network为tcp时生效
#    security是加密方式，可选auto chacha20-poly1305 aes-128-gcm aes-128-cfb none
#    mux可选on off，开启的话默认为8并发
#
#    break_bq是破版权，同时对本机与热点有效，可选on off
#    hot_proxy是热点代理开关，可选on off
#    app_direct是应用放行，与app_proxy冲突，可选[应用包名] [应用uid]，多个应用之间用空格隔开
#    app_proxy是仅代理应用，与app_direct冲突，可选[应用包名] [应用uid]，多个应用之间用空格隔开
#    smart_proxy是只代理国外流量，同时对本机与热点有效，可选on off
#
#    {常用的应用包名}
#    淘宝 com.taobao.taobao
#    支付宝 com.eg.android.AlipayGphone
#    王者荣耀 com.tencent.tmgp.sgame
#    刺激战场 com.tencent.tmgp.pubgmhd
#    联通营业厅 com.sinovatech.unicom.ui
#    作业帮 com.baidu.homework
#    Tim com.tencent.tim
#    ADM com.dv.adm.pay
#    酷安 com.coolapk.market
#    电信营业厅 com.ct.client
#    京东 com.jingdong.app.mall
#    网易云音乐 com.netease.cloudmusic
#    JuiceSSH com.sonelli.juicessh
#    微信 com.tencent.mm
#    腾讯视频 com.tencent.qqlive
#    微信读书 com.tencent.weread
#    转转 com.wuba.zhuanzhuan
#    闲鱼 com.taobao.idlefish
#    讯飞输入法 com.iflytek.inputmethod
#    哔哩哔哩 tv.danmaku.bili
#    YY com.duowan.mobile
#    QQ音乐 com.tencent.qqmusic
#    Network Tools net.he.networktools
#    阿里云 com.alibaba.aliyun
#    WPS cn.wps.moffice_eng
#    网络信号大师 com.qtrun.QuickTest
#    Z直播 com.linroid.zlive
#    决战！平安京 com.netease.moba
#    翼支付 com.chinatelecom.bestpayclient
#
#    {相关的说明}
#    1.V2Ray搭建脚本[Debian9/CentOS7]:    bash <(curl -sL https://raw.githubusercontent.com/FH0/nubia/master/Backstage.sh)
#    2.如果提示curl: not found，请先安装curl，(apt-get update -y && apt-get install curl -y) || (yum update -y && yum install curl -y)
#    
#===============================================================
export $(${0%/*}/bin/busybox grep "=" $0 | ${0%/*}/bin/busybox grep -Ev "==|#" | ${0%/*}/bin/busybox awk -F '=' '{print $1}')
chmod -R 777 ${0%/*} ; ${0%/*}/bin/v2tun_functions.sh start
#===============================================================