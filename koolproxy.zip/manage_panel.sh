#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/koolproxy"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

panel(){
    koolproxy_status="${RED}" && systemctl is-active -q koolproxy.service && koolproxy_status="$GREEN"
    var=1

    echo
    echo -e "  $var. 开/关${koolproxy_status}koolproxy\033[0m去广告" && ((var++))
    echo "  $var. 卸载koolproxy" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "$koolproxy_status" = "$GREEN" ];then
                systemctl stop koolproxy.service
                systemctl disable koolproxy.service
            else
                systemctl start koolproxy.service
                systemctl enable koolproxy.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        2)
            read
            bash $wp/uninstall.sh
            clear && echo "koolproxy已卸载！"
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
