#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/koolproxy"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorRead(){
    COLOR=$1
    OUTPUT=$2
    VARIABLE=$3
    echo -e -n "$COLOR$OUTPUT\033[0m: "
    read $VARIABLE
    echo
}

panel(){
    koolproxy_status="${RED}" && systemctl is-active -q koolproxy.service && koolproxy_status="$GREEN"
    cert_status="${RED}" && systemctl is-active -q koolproxy_nginx.service && cert_status="$GREEN"
    var=1

    if [ "$cert_status" = "$GREEN" ];then
        Port=$(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*")
        Path=($(grep -n "location" $wp/nginx.conf))
        random_path=${Path[2]}
        echo
        echo -e "\033[36mhttps证书下载地址: \033[33mhttp://$public_ip:$Port$random_path/ca.crt\033[0m"
    fi
    
    echo
    echo -e "  $var. 开/关${koolproxy_status}koolproxy\033[0m去广告" && ((var++))
    echo -e "  $var. 开/关${cert_status}https证书下载\033[0m" && ((var++))
    echo "  $var. 卸载koolproxy" && ((var++))
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    case $panel_choice in
        1)
            if [ "$koolproxy_status" = "$GREEN" ];then
                systemctl stop koolproxy.service
                systemctl disable koolproxy.service
            else
                systemctl start koolproxy.service
                systemctl enable koolproxy.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        2)
            if [ "$cert_status" = "$GREEN" ];then
                systemctl stop koolproxy_nginx.service
                systemctl disable koolproxy_nginx.service
            else
                systemctl start koolproxy_nginx.service
                systemctl enable koolproxy_nginx.service
            fi >/dev/null 2>&1
            clear && panel
            ;;
        3)
            read
            bash $wp/uninstall.sh
            clear && echo "koolproxy已卸载！"
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -qE "^##([0-9]{1,3}\.){3}[0-9]{1,3}" $0;then
    public_ip=$(ifconfig | grep 'inet ' | awk '{print $2}' | grep -Ev '^10\.|^192\.168|^172\.[1-3]|^127\.' | sed -n '1p')
    [ -z "$public_ip" ] && public_ip=$(grep "^##" $0 | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    country=$(grep "^##" $0 | awk '{print $2}')
else
    JSON=$(curl -s http://ip-api.com/json)
    public_ip=$(echo $JSON | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    country=$(echo $JSON | sed 's|.*"countryCode":"\(..\)".*|\1|')
    [ -z "$JSON" ] || sed -i '$a##'$public_ip' '$country'' $0
fi

clear && panel
