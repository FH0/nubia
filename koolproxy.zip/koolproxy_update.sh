#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/koolproxy"

if systemctl is-active -q koolproxy.service;then
    systemctl restart koolproxy.service
    sleep 5
    systemctl restart koolproxy.service
fi
