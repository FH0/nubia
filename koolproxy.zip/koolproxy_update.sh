#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/koolproxy"

if systemctl is-active -q koolproxy.service;then
    systemctl restart koolproxy.service
    sleep 5
    systemctl restart koolproxy.service
fi
