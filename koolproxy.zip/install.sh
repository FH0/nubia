#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/koolproxy"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    [ -z "$(command -v yum)" ] && Installer="apt-get" || Installer="yum"
    var="0"
    for command in $1;do
        if ! echo "$CHECK" | grep -q "$command";then
            [ "$var" = "0" ] && apt-get update && var="1"
            $Installer install $command -y
        fi > /dev/null 2>&1
    done
}

install_koolproxy(){
    colorEcho $BLUE "正在开启koolproxy自启程序..."
    cat $wp/koolproxy.service > /etc/systemd/system/koolproxy.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装koolproxy控制面板..."
    cat $wp/manage_panel.sh > /bin/kp
    chmod +x /bin/kp

    colorEcho $BLUE "正在开启自动更新程序..."
    sed -i '/koolproxy_update\.sh/d' /etc/crontab
    echo "00 03 * * * root $wp/koolproxy_update.sh" >> /etc/crontab

    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1
}

main(){
    cmd_need "wget"
    install_koolproxy
    systemctl enable koolproxy.service >/dev/null 2>&1 ; systemctl start koolproxy.service
    colorEcho $GREEN "koolproxy安装完成！输入kp可进入控制面板！"
}

main