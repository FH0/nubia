#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/koolproxy"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[36m"

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    [ -z "$(command -v yum)" ] && CHECK=$(dpkg -l) || CHECK=$(rpm -qa)
    [ -z "$(command -v yum)" ] && Installer="apt-get" || Installer="yum"
    var="0"
    for command in $1;do
        if ! echo "$CHECK" | grep -q "$command";then
            [ "$var" = "0" ] && apt-get update && var="1"
            $Installer install $command -y
        fi > /dev/null 2>&1
    done
}

install_koolproxy(){
    colorEcho $BLUE "正在开启koolproxy自启程序..."
    cat $wp/koolproxy.service > /etc/systemd/system/koolproxy.service
    cat $wp/koolproxy_nginx.service > /etc/systemd/system/koolproxy_nginx.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装koolproxy控制面板..."
    cat $wp/manage_panel.sh > /bin/kp
    chmod +x /bin/kp

    colorEcho $BLUE "正在开启自动更新程序..."
    sed -i '/koolproxy_update\.sh/d' /etc/crontab
    echo "00 03 * * * root $wp/koolproxy_update.sh" >> /etc/crontab

    colorEcho $BLUE "正在设置随机网址..."
    random=$(head -c 1000 /dev/urandom | tr -dc a-z0-9A-Z | head -c 6)
    sed -i "s|listen.*|listen       $(shuf -i 1024-65535 -n 1);|" $wp/nginx.conf
    nginx_path=($(grep -n "location" $wp/nginx.conf))
    sed -i "${nginx_path[0]%:}s|location.*|location /$random {|" $wp/nginx.conf

    chmod -R 777 $wp
    chmod +x /etc/systemd/system/* >/dev/null 2>&1

    colorEcho $BLUE "正在生成https证书..."
    $wp/koolproxy --cert >/dev/null 2>&1

    groupadd nobody >/dev/null 2>&1
}

main(){
    cmd_need "wget"
    install_koolproxy
    systemctl enable koolproxy.service >/dev/null 2>&1 ; systemctl start koolproxy.service
    colorEcho $GREEN "koolproxy安装完成！输入kp可进入控制面板！"
}

main