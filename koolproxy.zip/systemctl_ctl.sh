#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/koolproxy"

bash <(iptables -t nat -S | grep "$wp" | sed "s|^..|iptables -t nat -D|g")
kill -9 $(ps -ef | grep "$wp" | grep -v "grep" | grep -v "\.sh" | awk '{print $2}')

if [ "$1" = "start" ];then
    iptables -t nat -I OUTPUT -p tcp --dport 80 -m comment --comment "$wp" -j REDIRECT --to 3000
    iptables -t nat -I OUTPUT -p tcp -m ttl --ttl-eq 160 -m comment --comment "$wp" -j ACCEPT
    $wp/koolproxy --ttl 160 -d
fi
