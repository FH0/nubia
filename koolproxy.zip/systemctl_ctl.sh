#!/bin/bash
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
wp="/usr/local/koolproxy"

if [ "$1" = "koolproxy" -a "$2" = "start" ];then
    bash <(iptables -t nat -S | grep "$wp/koolproxy" | sed "s|^..|iptables -t nat -D|g")
    kill -9 $(ps -ef | grep "${wp}/nginx" | grep -v "grep" | awk '{print $2}')
    iptables -t nat -I OUTPUT -p tcp --dport 80 -m comment --comment "$wp/koolproxy" -j REDIRECT --to 3000
    iptables -t nat -I OUTPUT -p tcp -m ttl --ttl-eq 160 -m comment --comment "$wp/koolproxy" -j ACCEPT
    $wp/koolproxy --ttl 160
elif [ "$1" = "koolproxy" -a "$2" = "stop" ];then
    bash <(iptables -t nat -S | grep "$wp/koolproxy" | sed "s|^..|iptables -t nat -D|g")
    kill -9 $(ps -ef | grep "${wp}/nginx" | grep -v "grep" | awk '{print $2}')
elif [ "$1" = "nginx" -a "$2" = "stop" ];then
    bash <(iptables -S | grep "${wp}/nginx" | sed "s|^..|iptables -D|g")
    kill -9 $(ps -ef | grep "${wp}/nginx" | grep -v "grep" | awk '{print $2}')
else
    bash <(iptables -S | grep "${wp}/nginx" | sed "s|^..|iptables -D|g")
    kill -9 $(ps -ef | grep "${wp}/nginx" | grep -v "grep" | awk '{print $2}')
    iptables -I INPUT -p tcp --dport $(grep "listen" $wp/nginx.conf | grep -Eo "[0-9]*") -m comment --comment "${wp}/nginx" -j ACCEPT
    $wp/nginx -c $wp/nginx.conf
fi
